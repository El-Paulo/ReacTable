# ReacTable 3D Emulator

## Project Overview
- **Name**: ReacTable 3D Emulator
- **Goal**: Emulador 3D del famoso instrumento musical ReacTable usando Three.js y Web Audio API
- **Features**: Síntesis de audio interactiva, manipulación de cubos 3D, conexiones automáticas, grabación de audio

## URLs
- **Desarrollo**: https://3000-i7zd0uuor0lie7905e8cy-6532622b.e2b.dev
- **GitHub**: [Próximamente]

## Características Principales

### ✅ Funcionalidades Implementadas
- **Motor 3D interactivo** con Three.js
- **Sistema de audio en tiempo real** con Web Audio API
- **Gestión de cubos** (Oscillator, Filter, Gain, Output)
- **Sistema de conexiones automáticas** basado en proximidad
- **Interfaz de usuario completa** con paleta de cubos y controles
- **Grabación y exportación de audio** en formato WebM
- **Persistencia de proyectos** con localStorage y exportación JSON
- **Monitoreo de rendimiento** y optimización automática
- **Manejo de errores** robusto con fallback graceful

### 🎛️ Tipos de Cubos
1. **Oscillator (♪)** - Generador de ondas base (frecuencia, detune)
2. **Filter (⚡)** - Filtro de audio (cutoff, resonance)  
3. **Gain (🔊)** - Control de volumen y ganancia
4. **Output (📤)** - Salida de audio final

### 🎮 Controles
- **Click**: Seleccionar tipo de cubo y hacer click en mesa para colocar
- **Drag**: Mover cubo seleccionado
- **R + Drag**: Rotar cubo (modifica parámetros de audio)
- **Delete**: Eliminar cubo seleccionado
- **Mouse Wheel**: Orbitar cámara
- **Escape**: Cancelar modo de colocación

## Data Architecture
- **Motor de Renderizado**: Three.js con OrbitControls
- **Motor de Audio**: Web Audio API nativa con MediaRecorder
- **Gestión de Estado**: AppState centralizado con Map<string, CubeInstance>
- **Persistencia**: LocalStorage para auto-guardado + exportación JSON
- **Conexiones**: Sistema automático basado en distancia 3D
- **Parámetros**: Mapeo directo de transformaciones 3D a parámetros de audio

## User Guide

### Inicio Rápido
1. Abrir la aplicación en navegador moderno
2. Hacer click en "Start ReacTable" para inicializar la escena 3D
3. Hacer click en "Start Audio" para habilitar la síntesis de audio
4. Seleccionar un tipo de cubo de la paleta izquierda
5. Hacer click en la superficie de la mesa para colocar el cubo
6. Los cubos se conectan automáticamente cuando están cerca
7. Arrastrar y rotar cubos para modificar parámetros de audio

### Flujo de Audio Típico
```
Oscillator → Filter → Gain → Output
    ♪    →    ⚡   →  🔊  →   📤
```

### Grabación
1. Asegurarse de que el audio esté iniciado
2. Hacer click en "Start Recording"
3. Crear música manipulando los cubos
4. Hacer click en "Stop Recording" para descargar archivo .webm

### Proyectos
- **Auto-guardado**: El proyecto se guarda automáticamente cada 30 segundos
- **Exportar**: Usa el botón para descargar archivo JSON
- **Importar**: Arrastra archivo JSON a la ventana del navegador
- **Limpiar**: "Clear All" elimina todos los cubos

## Deployment
- **Platform**: Aplicación web estática
- **Status**: ✅ Activo (Desarrollo)
- **Tech Stack**: TypeScript + Three.js + Web Audio API + Vite
- **Compatibilidad**: Chrome 88+, Firefox 85+, Edge 88+
- **Last Updated**: 03/09/2025

## Arquitectura Técnica

### Componentes Principales
```
ReactableApp (Core)
├── RenderEngine (Three.js)
├── AudioEngine (Web Audio API)  
├── CubeManager (Lógica de cubos)
├── ConnectionManager (Conexiones automáticas)
├── InteractionManager (Mouse/teclado)
├── UIManager (Interfaz de usuario)
└── ProjectManager (Persistencia)
```

### Flujo de Datos
1. **Interacción** → InteractionManager captura eventos
2. **Transformación 3D** → RenderEngine actualiza posición/rotación
3. **Mapeo Audio** → CubeManager convierte transform a parámetros
4. **Síntesis** → AudioEngine actualiza nodos de audio
5. **Conexiones** → ConnectionManager detecta proximidad
6. **Renderizado** → Loop de animación actualiza visualización

### Seguridad y Rendimiento
- **Límites de audio**: Volumen máximo para protección auditiva
- **Gestión de memoria**: Cleanup automático de recursos
- **Optimización**: Degradación automática con > 20 cubos
- **Error handling**: Fallback graceful para navegadores incompatibles

## Requisitos del Sistema
- **Navegador**: Moderno con Web Audio API y WebGL
- **Audio**: Tarjeta de sonido/audífonos para escuchar síntesis
- **Interacción**: Mouse para manipulación de cubos
- **Micrófono**: No requerido (síntesis interna)

## Limitaciones Conocidas
- Máximo 20 cubos recomendado para rendimiento óptimo
- Grabación en formato WebM (depende del navegador)
- Conexiones automáticas solo por proximidad (no manual)
- Sin MIDI input/output (Web Audio API únicamente)

---

**ReacTable 3D Emulator** - Una experiencia musical interactiva en el navegador