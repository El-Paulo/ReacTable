import {
  Group,
  Mesh,
  LineSegments,
  MeshPhongMaterial,
  LineBasicMaterial,
  Color,
  Vector3,
  Clock
} from 'three'
import { CubeType, CubeInstance, AudioParams } from '@/types'
import { CUBE_TYPES } from '@/config/cubeTypes'

export interface CubeVisualState {
  isSelected: boolean
  isActive: boolean
  isHovered: boolean
  parameterIntensity: number // 0-1 based on parameter values
  connectionStrength: number // 0-1 based on audio connections
}

export class CubeVisualManager {
  private clock: Clock = new Clock()
  private cubeStates: Map<string, CubeVisualState> = new Map()
  private animationCallbacks: Map<string, () => void> = new Map()

  constructor() {
    this.clock.start()
  }

  /**
   * Updates the visual appearance of a cube based on its state and parameters
   */
  updateCubeVisuals(cubeGroup: Group, cube: CubeInstance, state: CubeVisualState): void {
    const cubeId = cube.id
    this.cubeStates.set(cubeId, { ...state })

    // Get cube components
    const cubeMesh = cubeGroup.getObjectByName('cube-mesh') as Mesh
    const outline = cubeGroup.getObjectByName('cube-outline') as LineSegments

    if (!cubeMesh || !outline) {
      console.warn(`Cube components not found for cube ${cubeId}`)
      return
    }

    // Update base color and material properties
    this.updateCubeColor(cubeMesh, cube.type, state)
    
    // Update outline for selection and hover states
    this.updateCubeOutline(outline, state)
    
    // Update visual parameter feedback
    this.updateParameterFeedback(cubeGroup, cube, state)
    
    // Set up animations if needed
    this.setupCubeAnimations(cubeGroup, cube, state)
  }

  /**
   * Updates the base color and material properties of a cube
   */
  private updateCubeColor(cubeMesh: Mesh, cubeType: CubeType, state: CubeVisualState): void {
    const material = cubeMesh.material as MeshPhongMaterial
    const typeDefinition = CUBE_TYPES[cubeType]
    const baseColor = new Color(typeDefinition.color)

    // Adjust color based on state
    if (state.isSelected) {
      // Brighten selected cubes
      material.color.copy(baseColor.clone().multiplyScalar(1.3))
      material.emissive.setHex(0x333333)
      material.opacity = 1.0
    } else if (state.isHovered) {
      // Slightly brighten hovered cubes
      material.color.copy(baseColor.clone().multiplyScalar(1.1))
      material.emissive.setHex(0x111111)
      material.opacity = 0.95
    } else {
      // Base color
      material.color.copy(baseColor)
      material.emissive.setHex(0x000000)
      material.opacity = 0.9
    }

    // Adjust opacity based on activity
    if (state.isActive) {
      material.opacity = Math.max(material.opacity, 0.95)
    }

    // Add subtle color shift based on parameter intensity
    if (state.parameterIntensity > 0) {
      const intensityColor = new Color(0xffffff)
      material.color.lerp(intensityColor, state.parameterIntensity * 0.2)
    }
  }

  /**
   * Updates the outline appearance for selection and hover feedback
   */
  private updateCubeOutline(outline: LineSegments, state: CubeVisualState): void {
    const material = outline.material as LineBasicMaterial

    if (state.isSelected) {
      // Bright white outline for selected cubes
      material.color.setHex(0xffffff)
      material.opacity = 0.8
    } else if (state.isHovered) {
      // Dimmer outline for hovered cubes
      material.color.setHex(0xcccccc)
      material.opacity = 0.5
    } else if (state.isActive) {
      // Subtle outline for active cubes
      material.color.setHex(0x888888)
      material.opacity = 0.3
    } else {
      // No outline for inactive cubes
      material.opacity = 0
    }
  }

  /**
   * Updates visual feedback based on cube parameters
   */
  private updateParameterFeedback(cubeGroup: Group, cube: CubeInstance, state: CubeVisualState): void {
    const typeDefinition = CUBE_TYPES[cube.type]
    
    // Calculate parameter intensity (0-1) based on parameter values
    let totalIntensity = 0
    let paramCount = 0

    for (const paramDef of typeDefinition.parameters) {
      const value = cube.parameters[paramDef.name]
      if (value !== undefined) {
        // Normalize parameter value to 0-1 range
        const normalizedValue = (value - paramDef.min) / (paramDef.max - paramDef.min)
        totalIntensity += normalizedValue
        paramCount++
      }
    }

    const avgIntensity = paramCount > 0 ? totalIntensity / paramCount : 0

    // Update scale based on parameter intensity
    const baseScale = 1.0
    const scaleVariation = 0.2 * avgIntensity
    const targetScale = baseScale + scaleVariation
    
    // Smooth scale transition
    cubeGroup.scale.lerp(new Vector3(targetScale, targetScale, targetScale), 0.1)

    // Update brightness based on parameter activity
    const cubeMesh = cubeGroup.getObjectByName('cube-mesh') as Mesh
    if (cubeMesh && cubeMesh.material instanceof MeshPhongMaterial) {
      const emissiveIntensity = avgIntensity * 0.1
      const emissiveColor = new Color(typeDefinition.color).multiplyScalar(emissiveIntensity)
      
      if (!state.isSelected && !state.isHovered) {
        cubeMesh.material.emissive.copy(emissiveColor)
      }
    }

    // Store intensity for external use
    state.parameterIntensity = avgIntensity
  }

  /**
   * Sets up animations for active cubes
   */
  private setupCubeAnimations(cubeGroup: Group, cube: CubeInstance, state: CubeVisualState): void {
    const cubeId = cube.id

    // Remove existing animation callback
    this.animationCallbacks.delete(cubeId)

    if (state.isActive) {
      // Create pulsing animation for active cubes
      const animationCallback = () => {
        const time = this.clock.getElapsedTime()
        const pulseSpeed = 2.0 + state.parameterIntensity * 2.0 // Faster pulse with higher intensity
        const pulseIntensity = 0.1 + state.parameterIntensity * 0.2
        
        const pulse = Math.sin(time * pulseSpeed) * pulseIntensity
        const cubeMesh = cubeGroup.getObjectByName('cube-mesh') as Mesh
        
        if (cubeMesh && cubeMesh.material instanceof MeshPhongMaterial) {
          const typeDefinition = CUBE_TYPES[cube.type]
          const baseEmissive = new Color(typeDefinition.color).multiplyScalar(state.parameterIntensity * 0.1)
          const pulseEmissive = baseEmissive.clone().multiplyScalar(1 + pulse)
          
          if (!state.isSelected && !state.isHovered) {
            cubeMesh.material.emissive.copy(pulseEmissive)
          }
        }
      }

      this.animationCallbacks.set(cubeId, animationCallback)
    }
  }

  /**
   * Updates all cube animations - should be called in render loop
   */
  updateAnimations(): void {
    this.animationCallbacks.forEach(callback => callback())
  }

  /**
   * Gets the visual state for a cube
   */
  getCubeVisualState(cubeId: string): CubeVisualState | null {
    return this.cubeStates.get(cubeId) || null
  }

  /**
   * Sets hover state for a cube
   */
  setCubeHovered(cubeId: string, hovered: boolean): void {
    const state = this.cubeStates.get(cubeId)
    if (state) {
      state.isHovered = hovered
    }
  }

  /**
   * Sets selection state for a cube
   */
  setCubeSelected(cubeId: string, selected: boolean): void {
    const state = this.cubeStates.get(cubeId)
    if (state) {
      state.isSelected = selected
    }
  }

  /**
   * Sets active state for a cube
   */
  setCubeActive(cubeId: string, active: boolean): void {
    const state = this.cubeStates.get(cubeId)
    if (state) {
      state.isActive = active
    }
  }

  /**
   * Sets connection strength for visual feedback
   */
  setCubeConnectionStrength(cubeId: string, strength: number): void {
    const state = this.cubeStates.get(cubeId)
    if (state) {
      state.connectionStrength = Math.max(0, Math.min(1, strength))
    }
  }

  /**
   * Creates initial visual state for a new cube
   */
  createCubeVisualState(cubeId: string): CubeVisualState {
    const state: CubeVisualState = {
      isSelected: false,
      isActive: false,
      isHovered: false,
      parameterIntensity: 0,
      connectionStrength: 0
    }
    
    this.cubeStates.set(cubeId, state)
    return state
  }

  /**
   * Removes visual state for a cube
   */
  removeCubeVisualState(cubeId: string): void {
    this.cubeStates.delete(cubeId)
    this.animationCallbacks.delete(cubeId)
  }

  /**
   * Gets color for a cube type
   */
  getCubeTypeColor(cubeType: CubeType): string {
    return CUBE_TYPES[cubeType].color
  }

  /**
   * Gets all available cube type colors for UI
   */
  getAllCubeTypeColors(): Record<CubeType, string> {
    const colors: Record<CubeType, string> = {} as Record<CubeType, string>
    
    Object.values(CubeType).forEach(type => {
      colors[type] = CUBE_TYPES[type].color
    })
    
    return colors
  }

  /**
   * Applies visual theme to a cube based on its type
   */
  applyCubeTypeTheme(cubeGroup: Group, cubeType: CubeType): void {
    const cubeMesh = cubeGroup.getObjectByName('cube-mesh') as Mesh
    if (cubeMesh && cubeMesh.material instanceof MeshPhongMaterial) {
      const typeDefinition = CUBE_TYPES[cubeType]
      cubeMesh.material.color.setHex(parseInt(typeDefinition.color.replace('#', '0x')))
      
      // Set type-specific material properties
      switch (cubeType) {
        case CubeType.OSCILLATOR:
          cubeMesh.material.shininess = 50
          break
        case CubeType.FILTER:
          cubeMesh.material.shininess = 30
          break
        case CubeType.GAIN:
          cubeMesh.material.shininess = 20
          break
        case CubeType.OUTPUT:
          cubeMesh.material.shininess = 80
          break
      }
    }
  }

  /**
   * Cleanup method
   */
  destroy(): void {
    this.cubeStates.clear()
    this.animationCallbacks.clear()
    this.clock.stop()
  }
}