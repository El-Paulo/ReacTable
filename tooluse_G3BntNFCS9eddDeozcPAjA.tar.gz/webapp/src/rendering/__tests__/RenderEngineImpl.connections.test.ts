import { Vector3, Group, Mesh, BoxGeometry, MeshPhongMaterial } from 'three'
import { vi } from 'vitest'
import { CubeInstance, CubeType } from '@/types'

// Create a mock RenderEngine class that focuses on connection logic
class MockRenderEngineForConnections {
  private cubes: Map<string, Group> = new Map()
  private connections: Map<string, Mesh> = new Map()

  addCube(cube: CubeInstance): void {
    const cubeGroup = new Group()
    cubeGroup.position.copy(cube.transform.position)
    this.cubes.set(cube.id, cubeGroup)
  }

  showConnection(from: string, to: string, intensity: number): void {
    const connectionId = `${from}->${to}`
    
    // Remove existing connection if it exists
    this.hideConnection(from, to)
    
    const fromCube = this.cubes.get(from)
    const toCube = this.cubes.get(to)
    
    if (!fromCube || !toCube) {
      console.warn(`Cannot show connection: cube not found (from: ${from}, to: ${to})`)
      return
    }
    
    // Create connection visual
    const connectionVisual = this.createConnectionVisual(fromCube, toCube, intensity)
    if (connectionVisual) {
      this.connections.set(connectionId, connectionVisual)
    }
  }

  hideConnection(from: string, to: string): void {
    const connectionId = `${from}->${to}`
    const connection = this.connections.get(connectionId)
    
    if (connection) {
      this.connections.delete(connectionId)
    }
  }

  getConnections(): Mesh[] {
    return Array.from(this.connections.values())
  }

  updateCube(cubeId: string, position: Vector3): void {
    const cubeGroup = this.cubes.get(cubeId)
    if (cubeGroup) {
      cubeGroup.position.copy(position)
      this.updateConnectionPositions()
    }
  }

  private createConnectionVisual(fromCube: Group, toCube: Group, intensity: number): Mesh | null {
    const fromPosition = fromCube.position.clone()
    const toPosition = toCube.position.clone()
    
    const direction = new Vector3().subVectors(toPosition, fromPosition)
    const distance = direction.length()
    
    if (distance < 0.1) {
      return null // Too close to create meaningful connection
    }
    
    const geometry = new BoxGeometry(0.05, distance, 0.05)
    const material = new MeshPhongMaterial({
      color: this.getConnectionColor(intensity),
      transparent: true,
      opacity: Math.max(0.3, intensity)
    })
    
    const connectionMesh = new Mesh(geometry, material)
    
    // Position the connection at the midpoint
    const midpoint = new Vector3().addVectors(fromPosition, toPosition).multiplyScalar(0.5)
    connectionMesh.position.copy(midpoint)
    
    // Add animation data
    this.animateConnection(connectionMesh, intensity)
    
    return connectionMesh
  }

  private getConnectionColor(intensity: number): number {
    const r = Math.floor(intensity * 255)
    const g = Math.floor((1 - intensity) * 100)
    const b = Math.floor((1 - intensity) * 255)
    
    return (r << 16) | (g << 8) | b
  }

  private animateConnection(connectionMesh: Mesh, intensity: number): void {
    ;(connectionMesh as any).animationData = {
      baseOpacity: Math.max(0.3, intensity),
      pulseSpeed: 2 + intensity * 3,
      time: 0
    }
  }

  private updateConnectionPositions(): void {
    this.connections.forEach((connection, connectionId) => {
      const [fromId, toId] = connectionId.split('->')
      const fromCube = this.cubes.get(fromId)
      const toCube = this.cubes.get(toId)
      
      if (fromCube && toCube) {
        const fromPosition = fromCube.position.clone()
        const toPosition = toCube.position.clone()
        
        const midpoint = new Vector3().addVectors(fromPosition, toPosition).multiplyScalar(0.5)
        connection.position.copy(midpoint)
      }
    })
  }
}

// Helper function to create test cube instances
const createTestCube = (
  id: string,
  type: CubeType,
  position: Vector3
): CubeInstance => ({
  id,
  type,
  transform: {
    position: position.clone(),
    rotation: new Vector3(),
    scale: new Vector3(1, 1, 1)
  },
  audioNodeId: `audio-${id}`,
  isActive: true,
  parameters: {}
})

describe('RenderEngineImpl - Connection Visualization', () => {
  let renderEngine: MockRenderEngineForConnections

  beforeEach(() => {
    renderEngine = new MockRenderEngineForConnections()
  })

  describe('Connection Creation and Removal', () => {
    it('should create visual connection between two cubes', () => {
      const cube1 = createTestCube('cube1', CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      const cube2 = createTestCube('cube2', CubeType.FILTER, new Vector3(2, 0, 0))

      // Add cubes to scene
      renderEngine.addCube(cube1)
      renderEngine.addCube(cube2)

      // Show connection
      renderEngine.showConnection('cube1', 'cube2', 0.8)

      // Verify connection was created
      const connections = renderEngine.getConnections()
      expect(connections.length).toBe(1)
    })

    it('should remove visual connection', () => {
      const cube1 = createTestCube('cube1', CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      const cube2 = createTestCube('cube2', CubeType.FILTER, new Vector3(2, 0, 0))

      renderEngine.addCube(cube1)
      renderEngine.addCube(cube2)

      // Show and then hide connection
      renderEngine.showConnection('cube1', 'cube2', 0.8)
      renderEngine.hideConnection('cube1', 'cube2')

      // Verify connection was removed
      const connections = renderEngine.getConnections()
      expect(connections.length).toBe(0)
    })

    it('should handle multiple connections', () => {
      const cube1 = createTestCube('cube1', CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      const cube2 = createTestCube('cube2', CubeType.FILTER, new Vector3(2, 0, 0))
      const cube3 = createTestCube('cube3', CubeType.GAIN, new Vector3(4, 0, 0))

      renderEngine.addCube(cube1)
      renderEngine.addCube(cube2)
      renderEngine.addCube(cube3)

      // Create multiple connections
      renderEngine.showConnection('cube1', 'cube2', 0.7)
      renderEngine.showConnection('cube2', 'cube3', 0.9)

      const connections = renderEngine.getConnections()
      expect(connections.length).toBe(2)
    })

    it('should replace existing connection when showing same connection again', () => {
      const cube1 = createTestCube('cube1', CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      const cube2 = createTestCube('cube2', CubeType.FILTER, new Vector3(2, 0, 0))

      renderEngine.addCube(cube1)
      renderEngine.addCube(cube2)

      // Show connection twice with different intensities
      renderEngine.showConnection('cube1', 'cube2', 0.5)
      renderEngine.showConnection('cube1', 'cube2', 0.9)

      const connections = renderEngine.getConnections()
      // Should still only have one connection
      expect(connections.length).toBe(1)
    })
  })

  describe('Connection Visual Properties', () => {
    it('should create connection with appropriate intensity-based properties', () => {
      const cube1 = createTestCube('cube1', CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      const cube2 = createTestCube('cube2', CubeType.FILTER, new Vector3(2, 0, 0))

      renderEngine.addCube(cube1)
      renderEngine.addCube(cube2)

      // Test high intensity connection
      renderEngine.showConnection('cube1', 'cube2', 0.9)

      const connections = renderEngine.getConnections()
      expect(connections.length).toBe(1)
      
      const connection = connections[0] as any
      expect(connection.material.transparent).toBe(true)
      expect(connection.material.opacity).toBeGreaterThan(0.3)
    })

    it('should position connection at midpoint between cubes', () => {
      const cube1 = createTestCube('cube1', CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      const cube2 = createTestCube('cube2', CubeType.FILTER, new Vector3(4, 0, 0))

      renderEngine.addCube(cube1)
      renderEngine.addCube(cube2)
      renderEngine.showConnection('cube1', 'cube2', 0.8)

      const connections = renderEngine.getConnections()
      const connection = connections[0] as any
      
      // Connection should be positioned at midpoint (2, 0, 0)
      expect(connection.position.x).toBeCloseTo(2, 1)
      expect(connection.position.y).toBeCloseTo(0, 1)
      expect(connection.position.z).toBeCloseTo(0, 1)
    })

    it('should update connection position when cubes move', () => {
      const cube1 = createTestCube('cube1', CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      const cube2 = createTestCube('cube2', CubeType.FILTER, new Vector3(2, 0, 0))

      renderEngine.addCube(cube1)
      renderEngine.addCube(cube2)
      renderEngine.showConnection('cube1', 'cube2', 0.8)

      // Move cube2
      const newPosition = new Vector3(4, 0, 0)
      renderEngine.updateCube('cube2', newPosition)

      const connections = renderEngine.getConnections()
      const connection = connections[0] as any
      
      // Connection should now be at new midpoint (2, 0, 0)
      expect(connection.position.x).toBeCloseTo(2, 1)
    })
  })

  describe('Connection Animation', () => {
    it('should add animation data to connection meshes', () => {
      const cube1 = createTestCube('cube1', CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      const cube2 = createTestCube('cube2', CubeType.FILTER, new Vector3(2, 0, 0))

      renderEngine.addCube(cube1)
      renderEngine.addCube(cube2)
      renderEngine.showConnection('cube1', 'cube2', 0.8)

      const connections = renderEngine.getConnections()
      const connection = connections[0] as any
      
      expect(connection.animationData).toBeDefined()
      expect(connection.animationData.baseOpacity).toBeGreaterThan(0)
      expect(connection.animationData.pulseSpeed).toBeGreaterThan(0)
      expect(connection.animationData.time).toBeDefined()
    })

    it('should have higher pulse speed for higher intensity connections', () => {
      const cube1 = createTestCube('cube1', CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      const cube2 = createTestCube('cube2', CubeType.FILTER, new Vector3(2, 0, 0))
      const cube3 = createTestCube('cube3', CubeType.GAIN, new Vector3(4, 0, 0))

      renderEngine.addCube(cube1)
      renderEngine.addCube(cube2)
      renderEngine.addCube(cube3)

      // Create connections with different intensities
      renderEngine.showConnection('cube1', 'cube2', 0.3) // Low intensity
      renderEngine.showConnection('cube2', 'cube3', 0.9) // High intensity

      const connections = renderEngine.getConnections()
      expect(connections.length).toBe(2)
      
      const lowIntensityConnection = connections[0] as any
      const highIntensityConnection = connections[1] as any
      
      expect(highIntensityConnection.animationData.pulseSpeed)
        .toBeGreaterThan(lowIntensityConnection.animationData.pulseSpeed)
    })
  })

  describe('Error Handling', () => {
    it('should handle connection between non-existent cubes gracefully', () => {
      // Try to show connection between cubes that don't exist
      expect(() => {
        renderEngine.showConnection('nonexistent1', 'nonexistent2', 0.8)
      }).not.toThrow()

      const connections = renderEngine.getConnections()
      expect(connections.length).toBe(0)
    })

    it('should handle hiding non-existent connection gracefully', () => {
      expect(() => {
        renderEngine.hideConnection('nonexistent1', 'nonexistent2')
      }).not.toThrow()
    })

    it('should handle connection between cubes at same position', () => {
      const cube1 = createTestCube('cube1', CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      const cube2 = createTestCube('cube2', CubeType.FILTER, new Vector3(0, 0, 0))

      renderEngine.addCube(cube1)
      renderEngine.addCube(cube2)

      // Try to create connection between cubes at same position
      renderEngine.showConnection('cube1', 'cube2', 0.8)

      const connections = renderEngine.getConnections()
      // Should not create connection for cubes too close together
      expect(connections.length).toBe(0)
    })
  })

  describe('Connection Management', () => {
    it('should track connections correctly', () => {
      const cube1 = createTestCube('cube1', CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      const cube2 = createTestCube('cube2', CubeType.FILTER, new Vector3(2, 0, 0))

      renderEngine.addCube(cube1)
      renderEngine.addCube(cube2)
      renderEngine.showConnection('cube1', 'cube2', 0.8)

      const connections = renderEngine.getConnections()
      expect(connections.length).toBe(1)
      
      const connection = connections[0] as any
      expect(connection.animationData).toBeDefined()
      expect(connection.animationData.time).toBe(0)
    })

    it('should handle connection lifecycle correctly', () => {
      const cube1 = createTestCube('cube1', CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      const cube2 = createTestCube('cube2', CubeType.FILTER, new Vector3(2, 0, 0))

      renderEngine.addCube(cube1)
      renderEngine.addCube(cube2)
      
      // Create connection
      renderEngine.showConnection('cube1', 'cube2', 0.8)
      expect(renderEngine.getConnections().length).toBe(1)
      
      // Remove connection
      renderEngine.hideConnection('cube1', 'cube2')
      expect(renderEngine.getConnections().length).toBe(0)
    })
  })
})