import { Group, Mesh, LineSegments, MeshPhongMaterial, LineBasicMaterial, BoxGeometry, EdgesGeometry, Vector3 } from 'three'
import { vi } from 'vitest'
import { CubeVisualManager, CubeVisualState } from '../CubeVisualManager'
import { CubeType, CubeInstance } from '@/types'
import { CubeFactory } from '@/core/CubeFactory'

// Mock Three.js Clock
vi.mock('three', async () => {
  const actual = await vi.importActual('three')
  return {
    ...actual,
    Clock: vi.fn().mockImplementation(() => ({
      start: vi.fn(),
      stop: vi.fn(),
      getElapsedTime: vi.fn(() => 0)
    }))
  }
})

describe('CubeVisualManager', () => {
  let visualManager: CubeVisualManager
  let mockCubeGroup: Group
  let mockCubeMesh: Mesh
  let mockOutline: LineSegments
  let testCube: CubeInstance

  beforeEach(() => {
    visualManager = new CubeVisualManager()
    
    // Create mock cube group with mesh and outline
    mockCubeGroup = new Group()
    
    // Create mock cube mesh
    const geometry = new BoxGeometry(1, 1, 1)
    const material = new MeshPhongMaterial({ color: 0xff6b6b })
    mockCubeMesh = new Mesh(geometry, material)
    mockCubeMesh.name = 'cube-mesh'
    
    // Create mock outline
    const edgesGeometry = new EdgesGeometry(geometry)
    const outlineMaterial = new LineBasicMaterial({ color: 0xffffff })
    mockOutline = new LineSegments(edgesGeometry, outlineMaterial)
    mockOutline.name = 'cube-outline'
    
    // Add to group
    mockCubeGroup.add(mockCubeMesh)
    mockCubeGroup.add(mockOutline)
    
    // Create test cube
    testCube = CubeFactory.createCube(CubeType.OSCILLATOR, new Vector3(0, 0, 0))
  })

  afterEach(() => {
    visualManager.destroy()
  })

  describe('visual state management', () => {
    it('should create initial visual state for a cube', () => {
      const state = visualManager.createCubeVisualState(testCube.id)

      expect(state).toEqual({
        isSelected: false,
        isActive: false,
        isHovered: false,
        parameterIntensity: 0,
        connectionStrength: 0
      })
      
      expect(visualManager.getCubeVisualState(testCube.id)).toBe(state)
    })

    it('should remove visual state for a cube', () => {
      visualManager.createCubeVisualState(testCube.id)
      expect(visualManager.getCubeVisualState(testCube.id)).toBeDefined()

      visualManager.removeCubeVisualState(testCube.id)
      expect(visualManager.getCubeVisualState(testCube.id)).toBeNull()
    })

    it('should update selection state', () => {
      const state = visualManager.createCubeVisualState(testCube.id)
      
      visualManager.setCubeSelected(testCube.id, true)
      expect(state.isSelected).toBe(true)
      
      visualManager.setCubeSelected(testCube.id, false)
      expect(state.isSelected).toBe(false)
    })

    it('should update hover state', () => {
      const state = visualManager.createCubeVisualState(testCube.id)
      
      visualManager.setCubeHovered(testCube.id, true)
      expect(state.isHovered).toBe(true)
      
      visualManager.setCubeHovered(testCube.id, false)
      expect(state.isHovered).toBe(false)
    })

    it('should update active state', () => {
      const state = visualManager.createCubeVisualState(testCube.id)
      
      visualManager.setCubeActive(testCube.id, true)
      expect(state.isActive).toBe(true)
      
      visualManager.setCubeActive(testCube.id, false)
      expect(state.isActive).toBe(false)
    })

    it('should update connection strength', () => {
      const state = visualManager.createCubeVisualState(testCube.id)
      
      visualManager.setCubeConnectionStrength(testCube.id, 0.7)
      expect(state.connectionStrength).toBe(0.7)
      
      // Should clamp values to [0, 1]
      visualManager.setCubeConnectionStrength(testCube.id, 1.5)
      expect(state.connectionStrength).toBe(1)
      
      visualManager.setCubeConnectionStrength(testCube.id, -0.5)
      expect(state.connectionStrength).toBe(0)
    })
  })

  describe('visual updates', () => {
    it('should update cube visuals based on state', () => {
      const state = visualManager.createCubeVisualState(testCube.id)
      state.isSelected = true
      state.isActive = true
      
      visualManager.updateCubeVisuals(mockCubeGroup, testCube, state)
      
      // Check that material properties were updated
      const material = mockCubeMesh.material as MeshPhongMaterial
      expect(material.opacity).toBeGreaterThan(0.9) // Should be more opaque when selected
      
      const outlineMaterial = mockOutline.material as LineBasicMaterial
      expect(outlineMaterial.opacity).toBeGreaterThan(0) // Should have visible outline when selected
    })

    it('should apply different colors for different cube types', () => {
      visualManager.applyCubeTypeTheme(mockCubeGroup, CubeType.OSCILLATOR)
      let material = mockCubeMesh.material as MeshPhongMaterial
      const oscillatorColor = material.color.getHex()
      
      visualManager.applyCubeTypeTheme(mockCubeGroup, CubeType.FILTER)
      material = mockCubeMesh.material as MeshPhongMaterial
      const filterColor = material.color.getHex()
      
      expect(oscillatorColor).not.toBe(filterColor)
    })

    it('should update parameter feedback based on cube parameters', () => {
      const state = visualManager.createCubeVisualState(testCube.id)
      
      // Set high parameter values to test intensity calculation
      testCube.parameters.frequency = 1500 // High frequency
      testCube.parameters.detune = 80 // High detune
      
      visualManager.updateCubeVisuals(mockCubeGroup, testCube, state)
      
      // Parameter intensity should be calculated and stored
      expect(state.parameterIntensity).toBeGreaterThan(0)
      expect(state.parameterIntensity).toBeLessThanOrEqual(1)
    })

    it('should handle cubes with no parameters', () => {
      const outputCube = CubeFactory.createCube(CubeType.OUTPUT, new Vector3(0, 0, 0))
      const state = visualManager.createCubeVisualState(outputCube.id)
      
      // Should not throw error for cube with no parameters
      expect(() => {
        visualManager.updateCubeVisuals(mockCubeGroup, outputCube, state)
      }).not.toThrow()
      
      expect(state.parameterIntensity).toBe(0)
    })

    it('should warn when cube components are missing', () => {
      const consoleSpy = vi.spyOn(console, 'warn').mockImplementation(() => {})
      
      // Create group without proper cube components
      const emptyGroup = new Group()
      const state = visualManager.createCubeVisualState(testCube.id)
      
      visualManager.updateCubeVisuals(emptyGroup, testCube, state)
      
      expect(consoleSpy).toHaveBeenCalledWith(expect.stringContaining('Cube components not found'))
      
      consoleSpy.mockRestore()
    })
  })

  describe('cube type colors', () => {
    it('should return correct color for each cube type', () => {
      expect(visualManager.getCubeTypeColor(CubeType.OSCILLATOR)).toBe('#ff6b6b')
      expect(visualManager.getCubeTypeColor(CubeType.FILTER)).toBe('#4ecdc4')
      expect(visualManager.getCubeTypeColor(CubeType.GAIN)).toBe('#45b7d1')
      expect(visualManager.getCubeTypeColor(CubeType.OUTPUT)).toBe('#f9ca24')
    })

    it('should return all cube type colors', () => {
      const colors = visualManager.getAllCubeTypeColors()
      
      expect(colors[CubeType.OSCILLATOR]).toBe('#ff6b6b')
      expect(colors[CubeType.FILTER]).toBe('#4ecdc4')
      expect(colors[CubeType.GAIN]).toBe('#45b7d1')
      expect(colors[CubeType.OUTPUT]).toBe('#f9ca24')
      expect(Object.keys(colors)).toHaveLength(4)
    })
  })

  describe('animations', () => {
    it('should set up animations for active cubes', () => {
      const state = visualManager.createCubeVisualState(testCube.id)
      state.isActive = true
      state.parameterIntensity = 0.5
      
      visualManager.updateCubeVisuals(mockCubeGroup, testCube, state)
      
      // Should not throw when updating animations
      expect(() => {
        visualManager.updateAnimations()
      }).not.toThrow()
    })

    it('should not set up animations for inactive cubes', () => {
      const state = visualManager.createCubeVisualState(testCube.id)
      state.isActive = false
      
      visualManager.updateCubeVisuals(mockCubeGroup, testCube, state)
      
      // Should not throw when updating animations
      expect(() => {
        visualManager.updateAnimations()
      }).not.toThrow()
    })

    it('should remove animation callbacks when cube is removed', () => {
      const state = visualManager.createCubeVisualState(testCube.id)
      state.isActive = true
      
      visualManager.updateCubeVisuals(mockCubeGroup, testCube, state)
      visualManager.removeCubeVisualState(testCube.id)
      
      // Should not throw when updating animations after removal
      expect(() => {
        visualManager.updateAnimations()
      }).not.toThrow()
    })
  })

  describe('visual state combinations', () => {
    it('should handle selected and hovered state combination', () => {
      const state = visualManager.createCubeVisualState(testCube.id)
      state.isSelected = true
      state.isHovered = true
      
      expect(() => {
        visualManager.updateCubeVisuals(mockCubeGroup, testCube, state)
      }).not.toThrow()
    })

    it('should handle active and selected state combination', () => {
      const state = visualManager.createCubeVisualState(testCube.id)
      state.isActive = true
      state.isSelected = true
      
      expect(() => {
        visualManager.updateCubeVisuals(mockCubeGroup, testCube, state)
      }).not.toThrow()
    })

    it('should handle all states active simultaneously', () => {
      const state = visualManager.createCubeVisualState(testCube.id)
      state.isSelected = true
      state.isActive = true
      state.isHovered = true
      state.parameterIntensity = 0.8
      state.connectionStrength = 0.6
      
      expect(() => {
        visualManager.updateCubeVisuals(mockCubeGroup, testCube, state)
      }).not.toThrow()
    })
  })

  describe('parameter intensity calculation', () => {
    it('should calculate intensity correctly for oscillator parameters', () => {
      const state = visualManager.createCubeVisualState(testCube.id)
      
      // Set parameters to middle values
      testCube.parameters.frequency = 1000 // Middle of 20-2000 range
      testCube.parameters.detune = 0 // Middle of -100 to 100 range
      
      visualManager.updateCubeVisuals(mockCubeGroup, testCube, state)
      
      // Should calculate reasonable intensity
      expect(state.parameterIntensity).toBeGreaterThan(0.3)
      expect(state.parameterIntensity).toBeLessThan(0.7)
    })

    it('should calculate intensity correctly for filter parameters', () => {
      const filterCube = CubeFactory.createCube(CubeType.FILTER, new Vector3(0, 0, 0))
      const state = visualManager.createCubeVisualState(filterCube.id)
      
      // Set parameters to maximum values
      filterCube.parameters.cutoff = 20000 // Maximum
      filterCube.parameters.resonance = 30 // Maximum
      
      visualManager.updateCubeVisuals(mockCubeGroup, filterCube, state)
      
      // Should be high intensity
      expect(state.parameterIntensity).toBeGreaterThan(0.8)
    })

    it('should handle gain parameters correctly', () => {
      const gainCube = CubeFactory.createCube(CubeType.GAIN, new Vector3(0, 0, 0))
      const state = visualManager.createCubeVisualState(gainCube.id)
      
      // Set gain to minimum
      gainCube.parameters.gain = 0
      
      visualManager.updateCubeVisuals(mockCubeGroup, gainCube, state)
      
      // Should be low intensity
      expect(state.parameterIntensity).toBeLessThan(0.2)
    })
  })

  describe('cleanup', () => {
    it('should clean up properly on destroy', () => {
      visualManager.createCubeVisualState(testCube.id)
      
      expect(() => {
        visualManager.destroy()
      }).not.toThrow()
      
      // Should clear all state
      expect(visualManager.getCubeVisualState(testCube.id)).toBeNull()
    })
  })
})