import {
  Scene,
  PerspectiveCamera,
  WebGLRenderer,
  DirectionalLight,
  AmbientLight,
  PlaneGeometry,
  MeshLambertMaterial,
  Mesh,
  Vector2,
  Vector3,
  Raycaster,
  Color,
  GridHelper,
  AxesHelper,
  BoxGeometry,
  MeshPhongMaterial,
  EdgesGeometry,
  LineBasicMaterial,
  LineSegments,
  Group,
  DoubleSide
} from 'three'
import { OrbitControls } from 'three-stdlib'
import { RenderEngine, CameraController } from '@/interfaces/RenderEngine'
import { ErrorHandler } from '@/interfaces/ErrorHandler'
import { CubeInstance, Transform3D, RaycastResult, CubeType, ErrorType } from '@/types'
import { SCENE_CONFIG } from '@/config/constants'
import { CUBE_TYPES } from '@/config/cubeTypes'
import { CubeVisualManager, CubeVisualState } from './CubeVisualManager'

export class RenderEngineImpl implements RenderEngine {
  private scene: Scene
  private camera: PerspectiveCamera
  private renderer: WebGLRenderer
  private cameraController: OrbitControlsController | null = null
  private raycaster: Raycaster
  private mouse: Vector2
  private cubes: Map<string, Group> = new Map()
  private connections: Map<string, Mesh> = new Map() // Will be used in task 5.3
  private table: Mesh | null = null
  private selectedCubeId: string | null = null
  private hoveredCubeId: string | null = null
  private visualManager: CubeVisualManager
  private errorHandler: ErrorHandler | null = null
  private isWebGLSupported = true
  private isDegradedMode = false

  // Manipulation state
  private dragState: {
    isDragging: boolean
    cubeId: string | null
    startPosition: Vector2
    cubeStartPosition: Vector3
    dragPlane: Mesh | null
  } = {
    isDragging: false,
    cubeId: null,
    startPosition: new Vector2(),
    cubeStartPosition: new Vector3(),
    dragPlane: null
  }

  private rotateState: {
    isRotating: boolean
    cubeId: string | null
    startPosition: Vector2
    cubeStartRotation: Vector3
  } = {
    isRotating: false,
    cubeId: null,
    startPosition: new Vector2(),
    cubeStartRotation: new Vector3()
  }

  constructor(container: HTMLElement, errorHandler?: ErrorHandler) {
    this.errorHandler = errorHandler || null

    // Check WebGL support before initializing
    this.checkWebGLSupport()

    // Initialize Three.js components
    this.scene = new Scene()
    this.camera = new PerspectiveCamera(
      75,
      container.clientWidth / container.clientHeight,
      0.1,
      1000
    )

    try {
      // Try to create WebGL renderer
      this.renderer = new WebGLRenderer({ 
        antialias: this.isWebGLSupported && !this.isDegradedMode, 
        alpha: true,
        powerPreference: 'high-performance',
        failIfMajorPerformanceCaveat: false
      })
    } catch (error) {
      this.handleWebGLError(error)
      // Fallback to basic renderer
      this.renderer = new WebGLRenderer({ 
        antialias: false, 
        alpha: true,
        powerPreference: 'low-power',
        failIfMajorPerformanceCaveat: false
      })
      this.isDegradedMode = true
    }

    this.raycaster = new Raycaster()
    this.mouse = new Vector2()

    // Initialize visual manager
    this.visualManager = new CubeVisualManager()

    // Configure renderer with error handling
    this.configureRenderer(container)

    // Add renderer to container
    container.appendChild(this.renderer.domElement)

    // Initialize scene
    this.initializeScene()

    // Set up camera controller
    this.cameraController = new OrbitControlsController(this.camera, this.renderer.domElement)
    
    // Handle window resize
    window.addEventListener('resize', this.handleResize.bind(this))
  }

  initializeScene(): void {
    // Set scene background
    this.scene.background = new Color(0x1a1a1a)

    // Add lighting
    const ambientLight = new AmbientLight(0x404040, 0.6)
    this.scene.add(ambientLight)

    const directionalLight = new DirectionalLight(0xffffff, 0.8)
    directionalLight.position.set(10, 10, 5)
    directionalLight.castShadow = true
    directionalLight.shadow.mapSize.width = 2048
    directionalLight.shadow.mapSize.height = 2048
    directionalLight.shadow.camera.near = 0.5
    directionalLight.shadow.camera.far = 50
    this.scene.add(directionalLight)

    // Create table surface
    this.createTable()

    // Add grid helper for reference
    const gridHelper = new GridHelper(SCENE_CONFIG.TABLE_SIZE, 20, 0x444444, 0x222222)
    this.scene.add(gridHelper)

    // Add axes helper for debugging
    const axesHelper = new AxesHelper(2)
    this.scene.add(axesHelper)

    // Position camera
    this.camera.position.set(
      SCENE_CONFIG.CAMERA_DISTANCE,
      SCENE_CONFIG.CAMERA_HEIGHT,
      SCENE_CONFIG.CAMERA_DISTANCE
    )
    this.camera.lookAt(0, 0, 0)
  }

  private createTable(): void {
    const tableGeometry = new PlaneGeometry(
      SCENE_CONFIG.TABLE_SIZE,
      SCENE_CONFIG.TABLE_SIZE
    )
    const tableMaterial = new MeshLambertMaterial({
      color: 0x333333,
      transparent: true,
      opacity: 0.8
    })
    
    this.table = new Mesh(tableGeometry, tableMaterial)
    this.table.rotation.x = -Math.PI / 2
    this.table.receiveShadow = true
    this.table.name = 'table'
    
    this.scene.add(this.table)
  }

  addCube(cube: CubeInstance): void {
    // Create cube group to hold mesh and outline
    const cubeGroup = new Group()
    cubeGroup.name = `cube-${cube.id}`
    cubeGroup.userData = { cubeId: cube.id, cubeType: cube.type }

    // Get cube type definition for color and properties
    const cubeTypeDef = CUBE_TYPES[cube.type]
    
    // Create cube geometry
    const geometry = new BoxGeometry(
      SCENE_CONFIG.CUBE_SIZE,
      SCENE_CONFIG.CUBE_SIZE,
      SCENE_CONFIG.CUBE_SIZE
    )

    // Create material with cube type color
    const material = new MeshPhongMaterial({
      color: new Color(cubeTypeDef.color),
      shininess: 30,
      transparent: true,
      opacity: 0.9
    })

    // Create cube mesh
    const cubeMesh = new Mesh(geometry, material)
    cubeMesh.castShadow = true
    cubeMesh.receiveShadow = true
    cubeMesh.name = 'cube-mesh'

    // Create outline geometry for selection feedback
    const edgesGeometry = new EdgesGeometry(geometry)
    const outlineMaterial = new LineBasicMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0
    })
    const outline = new LineSegments(edgesGeometry, outlineMaterial)
    outline.name = 'cube-outline'

    // Add mesh and outline to group
    cubeGroup.add(cubeMesh)
    cubeGroup.add(outline)

    // Set initial transform
    cubeGroup.position.copy(cube.transform.position)
    cubeGroup.rotation.setFromVector3(cube.transform.rotation)
    cubeGroup.scale.copy(cube.transform.scale)

    // Initialize visual state
    const visualState = this.visualManager.createCubeVisualState(cube.id)
    
    // Apply cube type theme
    this.visualManager.applyCubeTypeTheme(cubeGroup, cube.type)
    
    // Update initial visuals
    this.visualManager.updateCubeVisuals(cubeGroup, cube, visualState)

    // Add to scene and store reference
    this.scene.add(cubeGroup)
    this.cubes.set(cube.id, cubeGroup)
  }

  removeCube(cubeId: string): void {
    const cubeGroup = this.cubes.get(cubeId)
    if (cubeGroup) {
      // Clear selection if this cube was selected
      if (this.selectedCubeId === cubeId) {
        this.selectedCubeId = null
      }

      // Clear hover if this cube was hovered
      if (this.hoveredCubeId === cubeId) {
        this.hoveredCubeId = null
      }

      // Remove visual state
      this.visualManager.removeCubeVisualState(cubeId)

      // Dispose of geometries and materials
      cubeGroup.traverse((child) => {
        if (child instanceof Mesh || child instanceof LineSegments) {
          child.geometry.dispose()
          if (Array.isArray(child.material)) {
            child.material.forEach(material => material.dispose())
          } else {
            child.material.dispose()
          }
        }
      })

      this.scene.remove(cubeGroup)
      this.cubes.delete(cubeId)
    }
  }

  updateCube(cubeId: string, transform: Transform3D): void {
    const cubeGroup = this.cubes.get(cubeId)
    if (cubeGroup) {
      cubeGroup.position.copy(transform.position)
      cubeGroup.rotation.setFromVector3(transform.rotation)
      cubeGroup.scale.copy(transform.scale)
      
      // Update connection positions when cube moves
      this.updateConnectionPositions()
    }
  }

  /**
   * Updates cube visuals based on its current state and parameters
   */
  updateCubeVisuals(cube: CubeInstance): void {
    const cubeGroup = this.cubes.get(cube.id)
    if (cubeGroup) {
      const visualState = this.visualManager.getCubeVisualState(cube.id)
      if (visualState) {
        this.visualManager.updateCubeVisuals(cubeGroup, cube, visualState)
      }
    }
  }

  setCameraController(controller: CameraController): void {
    this.cameraController = controller as OrbitControlsController
  }

  showConnection(from: string, to: string, intensity: number): void {
    const connectionId = `${from}->${to}`
    
    // Remove existing connection if it exists
    this.hideConnection(from, to)
    
    const fromCube = this.cubes.get(from)
    const toCube = this.cubes.get(to)
    
    if (!fromCube || !toCube) {
      console.warn(`Cannot show connection: cube not found (from: ${from}, to: ${to})`)
      return
    }
    
    // Create connection visual
    const connectionVisual = this.createConnectionVisual(fromCube, toCube, intensity)
    if (connectionVisual) {
      this.scene.add(connectionVisual)
      this.connections.set(connectionId, connectionVisual)
    }
  }

  hideConnection(from: string, to: string): void {
    const connectionId = `${from}->${to}`
    const connection = this.connections.get(connectionId)
    
    if (connection) {
      // Dispose of geometry and material
      connection.geometry.dispose()
      if (Array.isArray(connection.material)) {
        connection.material.forEach(material => material.dispose())
      } else {
        connection.material.dispose()
      }
      
      this.scene.remove(connection)
      this.connections.delete(connectionId)
    }
  }

  raycast(screenPosition: Vector2): RaycastResult[] {
    // Convert screen coordinates to normalized device coordinates
    this.mouse.x = (screenPosition.x / this.renderer.domElement.clientWidth) * 2 - 1
    this.mouse.y = -(screenPosition.y / this.renderer.domElement.clientHeight) * 2 + 1

    // Update raycaster
    this.raycaster.setFromCamera(this.mouse, this.camera)

    // Get all intersectable objects (cubes and table)
    const intersectableObjects: any[] = []
    
    // Add cube meshes (not the groups, but the actual meshes inside them)
    this.cubes.forEach(cubeGroup => {
      const cubeMesh = cubeGroup.getObjectByName('cube-mesh')
      if (cubeMesh) {
        intersectableObjects.push(cubeMesh)
      }
    })

    // Add table if it exists
    if (this.table) {
      intersectableObjects.push(this.table)
    }

    // Perform raycast
    const intersects = this.raycaster.intersectObjects(intersectableObjects)

    // Convert to our RaycastResult format and add cube metadata
    return intersects.map(intersect => {
      let cubeId: string | null = null
      let cubeType: CubeType | null = null

      // Check if the intersected object is a cube mesh
      if (intersect.object.name === 'cube-mesh' && intersect.object.parent) {
        const cubeGroup = intersect.object.parent
        cubeId = cubeGroup.userData.cubeId
        cubeType = cubeGroup.userData.cubeType
      }

      return {
        object: intersect.object,
        point: intersect.point,
        distance: intersect.distance,
        screenPosition: screenPosition.clone(),
        cubeId,
        cubeType
      }
    })
  }

  render(): void {
    // Update camera controls
    if (this.cameraController) {
      this.cameraController.update()
    }

    // Update cube animations
    this.visualManager.updateAnimations()

    // Render the scene
    this.renderer.render(this.scene, this.camera)
  }

  setSize(width: number, height: number): void {
    this.camera.aspect = width / height
    this.camera.updateProjectionMatrix()
    this.renderer.setSize(width, height)
  }

  // Cube selection methods
  selectCube(cubeId: string): void {
    // Clear previous selection
    this.clearSelection()

    // Set new selection
    this.selectedCubeId = cubeId
    this.visualManager.setCubeSelected(cubeId, true)
  }

  clearSelection(): void {
    if (this.selectedCubeId) {
      this.visualManager.setCubeSelected(this.selectedCubeId, false)
      this.selectedCubeId = null
    }
  }

  getSelectedCubeId(): string | null {
    return this.selectedCubeId
  }

  // Method to set cube hover state
  setCubeHovered(cubeId: string, hovered: boolean): void {
    if (hovered && this.hoveredCubeId !== cubeId) {
      // Clear previous hover
      if (this.hoveredCubeId) {
        this.visualManager.setCubeHovered(this.hoveredCubeId, false)
      }
      this.hoveredCubeId = cubeId
      this.visualManager.setCubeHovered(cubeId, true)
    } else if (!hovered && this.hoveredCubeId === cubeId) {
      this.visualManager.setCubeHovered(cubeId, false)
      this.hoveredCubeId = null
    }
  }

  // Method to update cube visual state based on activity
  setCubeActive(cubeId: string, active: boolean): void {
    this.visualManager.setCubeActive(cubeId, active)
  }

  // Method to update cube connection strength for visual feedback
  setCubeConnectionStrength(cubeId: string, strength: number): void {
    this.visualManager.setCubeConnectionStrength(cubeId, strength)
  }

  // Get visual manager for external access
  getVisualManager(): CubeVisualManager {
    return this.visualManager
  }

  private handleResize(): void {
    const container = this.renderer.domElement.parentElement
    if (container) {
      this.setSize(container.clientWidth, container.clientHeight)
    }
  }

  destroy(): void {
    // Remove event listeners
    window.removeEventListener('resize', this.handleResize.bind(this))

    // Dispose of visual manager
    this.visualManager.destroy()

    // Dispose of camera controls
    if (this.cameraController) {
      this.cameraController.destroy()
    }

    // Dispose of geometries and materials
    this.scene.traverse((object) => {
      if (object instanceof Mesh) {
        object.geometry.dispose()
        if (Array.isArray(object.material)) {
          object.material.forEach(material => material.dispose())
        } else {
          object.material.dispose()
        }
      }
    })

    // Dispose of renderer
    this.renderer.dispose()

    // Remove canvas from DOM
    if (this.renderer.domElement.parentElement) {
      this.renderer.domElement.parentElement.removeChild(this.renderer.domElement)
    }
  }

  // Cube manipulation methods
  startDragCube(cubeId: string, screenPosition: Vector2): void {
    if (this.dragState.isDragging || this.rotateState.isRotating) {
      return // Already in manipulation mode
    }

    const cubeGroup = this.cubes.get(cubeId)
    if (!cubeGroup) {
      return
    }

    // Disable camera controls during drag
    if (this.cameraController) {
      this.cameraController.disableControls()
    }

    // Create invisible drag plane at cube height for intersection calculations
    const dragPlaneGeometry = new PlaneGeometry(SCENE_CONFIG.TABLE_SIZE * 2, SCENE_CONFIG.TABLE_SIZE * 2)
    const dragPlaneMaterial = new MeshLambertMaterial({ 
      color: 0x000000, 
      transparent: true, 
      opacity: 0,
      side: DoubleSide
    })
    this.dragState.dragPlane = new Mesh(dragPlaneGeometry, dragPlaneMaterial)
    this.dragState.dragPlane.rotation.x = -Math.PI / 2
    this.dragState.dragPlane.position.y = cubeGroup.position.y
    this.dragState.dragPlane.name = 'drag-plane'
    this.scene.add(this.dragState.dragPlane)

    // Set drag state
    this.dragState.isDragging = true
    this.dragState.cubeId = cubeId
    this.dragState.startPosition.copy(screenPosition)
    this.dragState.cubeStartPosition.copy(cubeGroup.position)

    // Select the cube being dragged
    this.selectCube(cubeId)
  }

  updateDragCube(screenPosition: Vector2): void {
    if (!this.dragState.isDragging || !this.dragState.cubeId || !this.dragState.dragPlane) {
      return
    }

    const cubeGroup = this.cubes.get(this.dragState.cubeId)
    if (!cubeGroup) {
      return
    }

    // Convert screen coordinates to world position using the drag plane
    this.mouse.x = (screenPosition.x / this.renderer.domElement.clientWidth) * 2 - 1
    this.mouse.y = -(screenPosition.y / this.renderer.domElement.clientHeight) * 2 + 1

    this.raycaster.setFromCamera(this.mouse, this.camera)
    const intersects = this.raycaster.intersectObject(this.dragState.dragPlane)

    if (intersects.length > 0) {
      const intersectionPoint = intersects[0].point
      
      // Constrain to table bounds
      const halfTableSize = SCENE_CONFIG.TABLE_SIZE / 2 - SCENE_CONFIG.CUBE_SIZE / 2
      intersectionPoint.x = Math.max(-halfTableSize, Math.min(halfTableSize, intersectionPoint.x))
      intersectionPoint.z = Math.max(-halfTableSize, Math.min(halfTableSize, intersectionPoint.z))
      
      // Update cube position
      cubeGroup.position.x = intersectionPoint.x
      cubeGroup.position.z = intersectionPoint.z
    }
  }

  endDragCube(): void {
    if (!this.dragState.isDragging) {
      return
    }

    // Clean up drag plane
    if (this.dragState.dragPlane) {
      this.scene.remove(this.dragState.dragPlane)
      this.dragState.dragPlane.geometry.dispose()
      if (this.dragState.dragPlane.material instanceof MeshLambertMaterial) {
        this.dragState.dragPlane.material.dispose()
      }
      this.dragState.dragPlane = null
    }

    // Re-enable camera controls
    if (this.cameraController) {
      this.cameraController.enableControls()
    }

    // Reset drag state
    this.dragState.isDragging = false
    this.dragState.cubeId = null
    this.dragState.startPosition.set(0, 0)
    this.dragState.cubeStartPosition.set(0, 0, 0)
  }

  startRotateCube(cubeId: string, screenPosition: Vector2): void {
    if (this.dragState.isDragging || this.rotateState.isRotating) {
      return // Already in manipulation mode
    }

    const cubeGroup = this.cubes.get(cubeId)
    if (!cubeGroup) {
      return
    }

    // Disable camera controls during rotation
    if (this.cameraController) {
      this.cameraController.disableControls()
    }

    // Set rotation state
    this.rotateState.isRotating = true
    this.rotateState.cubeId = cubeId
    this.rotateState.startPosition.copy(screenPosition)
    this.rotateState.cubeStartRotation.set(cubeGroup.rotation.x, cubeGroup.rotation.y, cubeGroup.rotation.z)

    // Select the cube being rotated
    this.selectCube(cubeId)
  }

  updateRotateCube(screenPosition: Vector2): void {
    if (!this.rotateState.isRotating || !this.rotateState.cubeId) {
      return
    }

    const cubeGroup = this.cubes.get(this.rotateState.cubeId)
    if (!cubeGroup) {
      return
    }

    // Calculate rotation delta based on mouse movement
    const deltaX = screenPosition.x - this.rotateState.startPosition.x
    const deltaY = screenPosition.y - this.rotateState.startPosition.y

    // Convert mouse movement to rotation (with sensitivity scaling)
    const rotationSensitivity = 0.01
    const deltaRotationY = deltaX * rotationSensitivity // Horizontal mouse movement -> Y axis rotation
    const deltaRotationX = deltaY * rotationSensitivity // Vertical mouse movement -> X axis rotation

    // Apply rotation relative to starting rotation
    cubeGroup.rotation.x = this.rotateState.cubeStartRotation.x + deltaRotationX
    cubeGroup.rotation.y = this.rotateState.cubeStartRotation.y + deltaRotationY
    // Keep Z rotation unchanged for now (could be added with modifier keys later)
    cubeGroup.rotation.z = this.rotateState.cubeStartRotation.z
  }

  endRotateCube(): void {
    if (!this.rotateState.isRotating) {
      return
    }

    // Re-enable camera controls
    if (this.cameraController) {
      this.cameraController.enableControls()
    }

    // Reset rotation state
    this.rotateState.isRotating = false
    this.rotateState.cubeId = null
    this.rotateState.startPosition.set(0, 0)
    this.rotateState.cubeStartRotation.set(0, 0, 0)
  }

  isDragging(): boolean {
    return this.dragState.isDragging
  }

  isRotating(): boolean {
    return this.rotateState.isRotating
  }

  // Getters for testing and debugging
  getScene(): Scene {
    return this.scene
  }

  getCamera(): PerspectiveCamera {
    return this.camera
  }

  getRenderer(): WebGLRenderer {
    return this.renderer
  }

  // Additional getters for testing manipulation state
  getDragState() {
    return { ...this.dragState }
  }

  getRotateState() {
    return { ...this.rotateState }
  }

  /**
   * Creates a visual representation of a connection between two cubes
   */
  private createConnectionVisual(fromCube: Group, toCube: Group, intensity: number): Mesh | null {
    const fromPosition = fromCube.position.clone()
    const toPosition = toCube.position.clone()
    
    // Create a tube geometry for the connection line
    const direction = new Vector3().subVectors(toPosition, fromPosition)
    const distance = direction.length()
    
    if (distance < 0.1) {
      return null // Too close to create meaningful connection
    }
    
    // Create a cylinder geometry oriented along the connection
    const geometry = new BoxGeometry(0.05, distance, 0.05)
    
    // Create material with intensity-based properties
    const material = new MeshPhongMaterial({
      color: this.getConnectionColor(intensity),
      transparent: true,
      opacity: Math.max(0.3, intensity),
      emissive: new Color(this.getConnectionColor(intensity)).multiplyScalar(0.2)
    })
    
    const connectionMesh = new Mesh(geometry, material)
    
    // Position the connection at the midpoint
    const midpoint = new Vector3().addVectors(fromPosition, toPosition).multiplyScalar(0.5)
    connectionMesh.position.copy(midpoint)
    
    // Orient the connection to point from source to target
    connectionMesh.lookAt(toPosition)
    connectionMesh.rotateX(Math.PI / 2) // Adjust for cylinder orientation
    
    // Add pulsing animation based on intensity
    this.animateConnection(connectionMesh, intensity)
    
    return connectionMesh
  }

  /**
   * Gets connection color based on intensity
   */
  private getConnectionColor(intensity: number): number {
    // Interpolate between blue (low intensity) and red (high intensity)
    const r = Math.floor(intensity * 255)
    const g = Math.floor((1 - intensity) * 100)
    const b = Math.floor((1 - intensity) * 255)
    
    return (r << 16) | (g << 8) | b
  }

  /**
   * Animates a connection mesh based on intensity
   */
  private animateConnection(connectionMesh: Mesh, intensity: number): void {
    // Store animation properties on the mesh for later updates
    ;(connectionMesh as any).animationData = {
      baseOpacity: Math.max(0.3, intensity),
      pulseSpeed: 2 + intensity * 3, // Faster pulse for higher intensity
      time: 0
    }
  }

  /**
   * Updates all connection animations
   */
  private updateConnectionAnimations(deltaTime: number): void {
    this.connections.forEach((connection) => {
      const animData = (connection as any).animationData
      if (animData) {
        animData.time += deltaTime * animData.pulseSpeed
        
        // Create pulsing effect
        const pulse = Math.sin(animData.time) * 0.3 + 0.7
        const material = connection.material as MeshPhongMaterial
        material.opacity = animData.baseOpacity * pulse
        
        // Add slight scale pulsing
        const scale = 1 + Math.sin(animData.time * 2) * 0.1
        connection.scale.setScalar(scale)
      }
    })
  }

  /**
   * Updates connection positions when cubes move
   */
  updateConnectionPositions(): void {
    this.connections.forEach((connection, connectionId) => {
      const [fromId, toId] = connectionId.split('->')
      const fromCube = this.cubes.get(fromId)
      const toCube = this.cubes.get(toId)
      
      if (fromCube && toCube) {
        const fromPosition = fromCube.position.clone()
        const toPosition = toCube.position.clone()
        
        // Update connection position and orientation
        const midpoint = new Vector3().addVectors(fromPosition, toPosition).multiplyScalar(0.5)
        connection.position.copy(midpoint)
        
        // Update length
        const distance = fromPosition.distanceTo(toPosition)
        connection.scale.y = distance / 1 // Assuming original geometry has height 1
        
        // Update orientation
        connection.lookAt(toPosition)
        connection.rotateX(Math.PI / 2)
      }
    })
  }

  // Error handling and WebGL support methods

  private checkWebGLSupport(): void {
    try {
      const canvas = document.createElement('canvas')
      const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl') as WebGLRenderingContext | null
      
      if (!gl) {
        this.isWebGLSupported = false
        this.errorHandler?.handleError(ErrorType.WEBGL_NOT_SUPPORTED, {
          reason: 'WebGL context creation failed'
        })
        return
      }

      // Check for required WebGL extensions
      const requiredExtensions = ['OES_element_index_uint']
      const missingExtensions: string[] = []

      requiredExtensions.forEach(ext => {
        if (!gl.getExtension(ext)) {
          missingExtensions.push(ext)
        }
      })

      if (missingExtensions.length > 0) {
        console.warn('Missing WebGL extensions:', missingExtensions)
        this.errorHandler?.showUserMessage(
          `Some WebGL features not supported: ${missingExtensions.join(', ')}`,
          'warning'
        )
      }

      // Check WebGL capabilities
      const maxTextureSize = gl.getParameter(gl.MAX_TEXTURE_SIZE)
      const maxVertexUniforms = gl.getParameter(gl.MAX_VERTEX_UNIFORM_VECTORS)
      
      if (maxTextureSize < 1024 || maxVertexUniforms < 128) {
        console.warn('Limited WebGL capabilities detected')
        this.isDegradedMode = true
        this.errorHandler?.showUserMessage(
          'Limited graphics capabilities detected. Some visual effects may be reduced.',
          'warning'
        )
      }

    } catch (error) {
      this.isWebGLSupported = false
      this.errorHandler?.handleError(ErrorType.WEBGL_NOT_SUPPORTED, error)
    }
  }

  private handleWebGLError(error: any): void {
    console.error('WebGL initialization error:', error)
    this.isWebGLSupported = false
    this.isDegradedMode = true
    
    this.errorHandler?.handleError(ErrorType.WEBGL_NOT_SUPPORTED, {
      reason: 'WebGL renderer creation failed',
      error: error.message || error
    })
  }

  private configureRenderer(container: HTMLElement): void {
    try {
      // Configure renderer with error handling
      this.renderer.setSize(container.clientWidth, container.clientHeight)
      
      // Adjust pixel ratio based on performance mode
      const pixelRatio = this.isDegradedMode 
        ? Math.min(window.devicePixelRatio, 1.5)
        : Math.min(window.devicePixelRatio, 2)
      this.renderer.setPixelRatio(pixelRatio)
      
      this.renderer.setClearColor(0x1a1a1a, 1)
      
      // Enable shadows only if not in degraded mode
      if (!this.isDegradedMode) {
        this.renderer.shadowMap.enabled = true
        this.renderer.shadowMap.type = 2 // PCFSoftShadowMap
      } else {
        this.renderer.shadowMap.enabled = false
        console.log('Shadows disabled due to performance constraints')
      }

      // Set up error handling for WebGL context loss
      this.renderer.domElement.addEventListener('webglcontextlost', this.handleContextLost.bind(this))
      this.renderer.domElement.addEventListener('webglcontextrestored', this.handleContextRestored.bind(this))

    } catch (error) {
      this.handleWebGLError(error)
    }
  }

  private handleContextLost(event: Event): void {
    event.preventDefault()
    console.warn('WebGL context lost')
    
    this.errorHandler?.handleError(ErrorType.WEBGL_NOT_SUPPORTED, {
      reason: 'WebGL context lost',
      event
    })
    
    this.errorHandler?.showUserMessage(
      'Graphics context lost. The page will attempt to recover automatically.',
      'warning'
    )
  }

  private handleContextRestored(event: Event): void {
    console.log('WebGL context restored')
    
    this.errorHandler?.showUserMessage(
      'Graphics context restored successfully.',
      'info'
    )
    
    // Reinitialize scene if needed
    try {
      this.initializeScene()
    } catch (error) {
      this.errorHandler?.handleError(ErrorType.WEBGL_NOT_SUPPORTED, {
        reason: 'Failed to restore WebGL context',
        error
      })
    }
  }

  enableDegradedMode(): void {
    if (this.isDegradedMode) return

    this.isDegradedMode = true
    console.log('Enabling degraded rendering mode')
    
    // Disable expensive features
    this.renderer.shadowMap.enabled = false
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1))
    
    // Reduce visual effects
    this.cubes.forEach(cube => {
      // Simplify cube materials
      cube.traverse(child => {
        if (child instanceof Mesh && child.material instanceof MeshPhongMaterial) {
          child.material.shininess = 0
          child.material.specular.setHex(0x000000)
        }
      })
    })
    
    this.errorHandler?.showUserMessage(
      'Performance mode enabled. Some visual effects have been reduced.',
      'info'
    )
  }

  disableDegradedMode(): void {
    if (!this.isDegradedMode) return

    this.isDegradedMode = false
    console.log('Disabling degraded rendering mode')
    
    // Re-enable features if WebGL supports them
    if (this.isWebGLSupported) {
      this.renderer.shadowMap.enabled = true
      this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
      
      // Restore visual effects
      this.cubes.forEach(cube => {
        cube.traverse(child => {
          if (child instanceof Mesh && child.material instanceof MeshPhongMaterial) {
            child.material.shininess = 100
            child.material.specular.setHex(0x111111)
          }
        })
      })
    }
    
    this.errorHandler?.showUserMessage(
      'Full quality rendering restored.',
      'info'
    )
  }

  getWebGLInfo(): {
    isSupported: boolean
    isDegraded: boolean
    renderer: string
    version: string
  } {
    const gl = this.renderer.getContext()
    
    return {
      isSupported: this.isWebGLSupported,
      isDegraded: this.isDegradedMode,
      renderer: gl.getParameter(gl.RENDERER) || 'Unknown',
      version: gl.getParameter(gl.VERSION) || 'Unknown'
    }
  }

}

class OrbitControlsController implements CameraController {
  private controls: OrbitControls

  constructor(camera: PerspectiveCamera, domElement: HTMLElement) {
    this.controls = new OrbitControls(camera, domElement)
    
    // Configure controls
    this.controls.enableDamping = true
    this.controls.dampingFactor = 0.05
    this.controls.screenSpacePanning = false
    this.controls.minDistance = 5
    this.controls.maxDistance = 50
    this.controls.maxPolarAngle = Math.PI / 2.2 // Prevent going below the table
    this.controls.target.set(0, 0, 0)
  }

  update(): void {
    this.controls.update()
  }

  enableControls(): void {
    this.controls.enabled = true
  }

  disableControls(): void {
    this.controls.enabled = false
  }

  destroy(): void {
    this.controls.dispose()
  }

  // Additional methods for camera control
  setTarget(target: Vector3): void {
    this.controls.target.copy(target)
    this.controls.update()
  }

  getTarget(): Vector3 {
    return this.controls.target.clone()
  }
}