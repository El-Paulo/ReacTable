import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest'
import { Vector2, Vector3 } from 'three'
import { CubeInstance, CubeType, Transform3D } from '@/types'

// Mock the entire RenderEngineImpl to avoid WebGL issues in tests
vi.mock('./RenderEngineImpl', () => ({
  RenderEngineImpl: vi.fn().mockImplementation((container: HTMLElement) => {
    const mockCanvas = document.createElement('canvas')
    container.appendChild(mockCanvas)
    
    // Mock cube storage
    const cubes = new Map()
    let selectedCubeId: string | null = null
    
    return {
      getScene: vi.fn(() => ({ 
        children: [{ name: 'table' }],
        getObjectByName: vi.fn((name: string) => {
          if (name === 'table') return { name: 'table' }
          if (name.startsWith('cube-')) {
            const cubeId = name.replace('cube-', '')
            return cubes.has(cubeId) ? {
              name,
              userData: { cubeId, cubeType: cubes.get(cubeId)?.type },
              getObjectByName: vi.fn((childName: string) => {
                if (childName === 'cube-mesh') return { name: 'cube-mesh' }
                if (childName === 'cube-outline') return { name: 'cube-outline' }
                return null
              })
            } : null
          }
          return null
        }),
        add: vi.fn(),
        remove: vi.fn()
      })),
      getCamera: vi.fn(() => ({ 
        position: { x: 15, y: 10, z: 15 },
        aspect: 800 / 600,
        updateProjectionMatrix: vi.fn()
      })),
      getRenderer: vi.fn(() => ({ 
        domElement: mockCanvas,
        setSize: vi.fn(),
        render: vi.fn()
      })),
      initializeScene: vi.fn(),
      addCube: vi.fn((cube: CubeInstance) => {
        cubes.set(cube.id, cube)
      }),
      removeCube: vi.fn((cubeId: string) => {
        cubes.delete(cubeId)
        if (selectedCubeId === cubeId) {
          selectedCubeId = null
        }
      }),
      updateCube: vi.fn(),
      selectCube: vi.fn((cubeId: string) => {
        selectedCubeId = cubeId
      }),
      clearSelection: vi.fn(() => {
        selectedCubeId = null
      }),
      getSelectedCubeId: vi.fn(() => selectedCubeId),
      setCubeActive: vi.fn(),
      raycast: vi.fn((screenPos: Vector2) => {
        // Mock raycast results - return cube if one exists at center
        const cubeArray = Array.from(cubes.values())
        if (cubeArray.length > 0 && screenPos.x === 400 && screenPos.y === 300) {
          const cube = cubeArray[0]
          return [{
            object: { name: 'cube-mesh' },
            point: new Vector3(0, 0.5, 0),
            distance: 10,
            screenPosition: screenPos,
            cubeId: cube.id,
            cubeType: cube.type
          }]
        }
        return []
      }),
      setSize: vi.fn(),
      showConnection: vi.fn(),
      hideConnection: vi.fn(),
      render: vi.fn(),
      destroy: vi.fn(() => {
        if (mockCanvas.parentElement) {
          mockCanvas.parentElement.removeChild(mockCanvas)
        }
      })
    }
  })
}))

import { RenderEngineImpl } from './RenderEngineImpl'

describe('RenderEngineImpl - Cube Rendering and Interaction', () => {
  let container: HTMLElement
  let renderEngine: RenderEngineImpl

  const createTestCube = (type: CubeType = CubeType.OSCILLATOR, id: string = 'test-cube-1'): CubeInstance => ({
    id,
    type,
    transform: {
      position: new Vector3(0, 0.5, 0),
      rotation: new Vector3(0, 0, 0),
      scale: new Vector3(1, 1, 1)
    },
    audioNodeId: `audio-node-${id}`,
    isActive: false,
    parameters: { frequency: 440, detune: 0 }
  })

  beforeEach(() => {
    // Create a mock container
    container = document.createElement('div')
    container.style.width = '800px'
    container.style.height = '600px'
    document.body.appendChild(container)

    renderEngine = new RenderEngineImpl(container)
  })

  afterEach(() => {
    if (renderEngine) {
      renderEngine.destroy()
    }
    if (container.parentElement) {
      document.body.removeChild(container)
    }
  })

  describe('Cube Creation and Management', () => {
    it('should add cube to scene with correct metadata', () => {
      const cube = createTestCube()
      renderEngine.addCube(cube)

      const scene = renderEngine.getScene()
      const cubeGroup = scene.getObjectByName(`cube-${cube.id}`)
      
      expect(cubeGroup).toBeDefined()
      expect(cubeGroup?.userData.cubeId).toBe(cube.id)
      expect(cubeGroup?.userData.cubeType).toBe(cube.type)
    })

    it('should create cube with proper mesh and outline components', () => {
      const cube = createTestCube()
      renderEngine.addCube(cube)

      const scene = renderEngine.getScene()
      const cubeGroup = scene.getObjectByName(`cube-${cube.id}`)
      
      expect(cubeGroup).toBeDefined()
      
      const cubeMesh = cubeGroup?.getObjectByName('cube-mesh')
      const outline = cubeGroup?.getObjectByName('cube-outline')
      
      expect(cubeMesh).toBeDefined()
      expect(outline).toBeDefined()
    })

    it('should create cubes with different types', () => {
      const cubeTypes = [
        { type: CubeType.OSCILLATOR, id: 'osc-1' },
        { type: CubeType.FILTER, id: 'filter-1' },
        { type: CubeType.GAIN, id: 'gain-1' },
        { type: CubeType.OUTPUT, id: 'output-1' }
      ]
      
      cubeTypes.forEach(({ type, id }) => {
        const cube = createTestCube(type, id)
        renderEngine.addCube(cube)
      })

      const scene = renderEngine.getScene()
      
      cubeTypes.forEach(({ id }) => {
        expect(scene.getObjectByName(`cube-${id}`)).toBeDefined()
      })
    })

    it('should remove cube from scene', () => {
      const cube = createTestCube()
      renderEngine.addCube(cube)
      
      let scene = renderEngine.getScene()
      expect(scene.getObjectByName(`cube-${cube.id}`)).toBeDefined()
      
      renderEngine.removeCube(cube.id)
      
      scene = renderEngine.getScene()
      expect(scene.getObjectByName(`cube-${cube.id}`)).toBeNull()
    })

    it('should update cube transform', () => {
      const cube = createTestCube()
      renderEngine.addCube(cube)

      const newTransform: Transform3D = {
        position: new Vector3(2, 1, 3),
        rotation: new Vector3(0.5, 1, 0),
        scale: new Vector3(1.5, 1.5, 1.5)
      }

      expect(() => renderEngine.updateCube(cube.id, newTransform)).not.toThrow()
    })

    it('should handle removing non-existent cube gracefully', () => {
      expect(() => renderEngine.removeCube('non-existent')).not.toThrow()
    })

    it('should handle updating non-existent cube gracefully', () => {
      const transform: Transform3D = {
        position: new Vector3(0, 0, 0),
        rotation: new Vector3(0, 0, 0),
        scale: new Vector3(1, 1, 1)
      }
      
      expect(() => renderEngine.updateCube('non-existent', transform)).not.toThrow()
    })
  })

  describe('Cube Selection and Visual Feedback', () => {
    it('should select cube and track selection state', () => {
      const cube = createTestCube()
      renderEngine.addCube(cube)
      
      renderEngine.selectCube(cube.id)
      
      expect(renderEngine.getSelectedCubeId()).toBe(cube.id)
    })

    it('should clear selection', () => {
      const cube = createTestCube()
      renderEngine.addCube(cube)
      
      renderEngine.selectCube(cube.id)
      expect(renderEngine.getSelectedCubeId()).toBe(cube.id)
      
      renderEngine.clearSelection()
      expect(renderEngine.getSelectedCubeId()).toBeNull()
    })

    it('should clear previous selection when selecting new cube', () => {
      const cube1 = createTestCube(CubeType.OSCILLATOR, 'cube-1')
      const cube2 = createTestCube(CubeType.FILTER, 'cube-2')
      
      renderEngine.addCube(cube1)
      renderEngine.addCube(cube2)
      
      renderEngine.selectCube(cube1.id)
      expect(renderEngine.getSelectedCubeId()).toBe(cube1.id)
      
      renderEngine.selectCube(cube2.id)
      expect(renderEngine.getSelectedCubeId()).toBe(cube2.id)
    })

    it('should set cube active state', () => {
      const cube = createTestCube()
      renderEngine.addCube(cube)
      
      expect(() => renderEngine.setCubeActive(cube.id, true)).not.toThrow()
      expect(() => renderEngine.setCubeActive(cube.id, false)).not.toThrow()
    })

    it('should handle setting active state for non-existent cube', () => {
      expect(() => renderEngine.setCubeActive('non-existent', true)).not.toThrow()
    })

    it('should clear selection when removing selected cube', () => {
      const cube = createTestCube()
      renderEngine.addCube(cube)
      
      renderEngine.selectCube(cube.id)
      expect(renderEngine.getSelectedCubeId()).toBe(cube.id)
      
      renderEngine.removeCube(cube.id)
      expect(renderEngine.getSelectedCubeId()).toBeNull()
    })
  })

  describe('Raycasting and Interaction', () => {
    it('should perform raycast and return results array', () => {
      const screenPosition = new Vector2(400, 300) // Center of 800x600 screen
      const results = renderEngine.raycast(screenPosition)
      
      expect(Array.isArray(results)).toBe(true)
    })

    it('should return empty results when no objects are hit', () => {
      const screenPosition = new Vector2(100, 100) // Off-center position
      const results = renderEngine.raycast(screenPosition)
      
      expect(Array.isArray(results)).toBe(true)
      expect(results.length).toBe(0)
    })

    it('should return cube data in raycast results when cube is hit', () => {
      const cube = createTestCube()
      renderEngine.addCube(cube)
      
      const screenPosition = new Vector2(400, 300) // Center position
      const results = renderEngine.raycast(screenPosition)
      
      expect(results.length).toBeGreaterThan(0)
      const result = results[0]
      expect(result.cubeId).toBe(cube.id)
      expect(result.cubeType).toBe(cube.type)
      expect(result.object.name).toBe('cube-mesh')
    })

    it('should include screen position in raycast results', () => {
      const cube = createTestCube()
      renderEngine.addCube(cube)
      
      const screenPosition = new Vector2(400, 300)
      const results = renderEngine.raycast(screenPosition)
      
      if (results.length > 0) {
        expect(results[0].screenPosition).toBeDefined()
        expect(results[0].screenPosition?.x).toBe(400)
        expect(results[0].screenPosition?.y).toBe(300)
      }
    })

    it('should handle raycast with multiple cubes', () => {
      const cubes = [
        createTestCube(CubeType.OSCILLATOR, 'osc-1'),
        createTestCube(CubeType.FILTER, 'filter-1'),
        createTestCube(CubeType.GAIN, 'gain-1')
      ]

      cubes.forEach(cube => renderEngine.addCube(cube))
      
      const screenPosition = new Vector2(400, 300)
      const results = renderEngine.raycast(screenPosition)
      
      // Should return at least one result (first cube in our mock)
      expect(results.length).toBeGreaterThan(0)
      expect(results[0].cubeId).toBe(cubes[0].id)
    })
  })

  describe('Visual Feedback Requirements', () => {
    it('should provide visual feedback for cube selection (highlighting)', () => {
      const cube = createTestCube()
      renderEngine.addCube(cube)
      
      // Select cube - should not throw and should track selection
      renderEngine.selectCube(cube.id)
      expect(renderEngine.getSelectedCubeId()).toBe(cube.id)
      
      // Clear selection - should not throw and should clear tracking
      renderEngine.clearSelection()
      expect(renderEngine.getSelectedCubeId()).toBeNull()
    })

    it('should provide visual feedback for cube activity state', () => {
      const cube = createTestCube()
      renderEngine.addCube(cube)
      
      // Set active state - should not throw
      expect(() => renderEngine.setCubeActive(cube.id, true)).not.toThrow()
      expect(() => renderEngine.setCubeActive(cube.id, false)).not.toThrow()
    })

    it('should handle visual feedback for different cube types', () => {
      const cubeTypes = [CubeType.OSCILLATOR, CubeType.FILTER, CubeType.GAIN, CubeType.OUTPUT]
      
      cubeTypes.forEach((type, index) => {
        const cube = createTestCube(type, `cube-${index}`)
        renderEngine.addCube(cube)
        
        // Should be able to select and set active for any cube type
        renderEngine.selectCube(cube.id)
        expect(renderEngine.getSelectedCubeId()).toBe(cube.id)
        
        renderEngine.setCubeActive(cube.id, true)
        // Should not throw for any cube type
      })
    })
  })

  describe('Integration with Requirements', () => {
    it('should support requirement 1.1 - cube placement and creation', () => {
      const cube = createTestCube()
      
      // Should be able to add cube at specific position
      expect(() => renderEngine.addCube(cube)).not.toThrow()
      
      const scene = renderEngine.getScene()
      expect(scene.getObjectByName(`cube-${cube.id}`)).toBeDefined()
    })

    it('should support requirement 12.2 - mouse interaction', () => {
      const cube = createTestCube()
      renderEngine.addCube(cube)
      
      // Should be able to raycast for mouse interaction
      const screenPos = new Vector2(400, 300)
      const results = renderEngine.raycast(screenPos)
      
      expect(Array.isArray(results)).toBe(true)
    })

    it('should support requirement 12.3 - cube selection', () => {
      const cube = createTestCube()
      renderEngine.addCube(cube)
      
      // Should be able to select cubes
      renderEngine.selectCube(cube.id)
      expect(renderEngine.getSelectedCubeId()).toBe(cube.id)
      
      // Should be able to clear selection
      renderEngine.clearSelection()
      expect(renderEngine.getSelectedCubeId()).toBeNull()
    })
  })
})