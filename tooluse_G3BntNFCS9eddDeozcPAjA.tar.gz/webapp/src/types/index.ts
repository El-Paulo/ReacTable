import { Vector3, Vector2 } from 'three'

// Core application types
export interface AppState {
  isAudioStarted: boolean
  cubes: Map<string, CubeInstance>
  connections: Connection[]
  selectedCube: string | null
  isRecording: boolean
}

// 3D Transform types
export interface Transform3D {
  position: Vector3
  rotation: Vector3
  scale: Vector3
}

// Audio types
export interface AudioParams {
  [key: string]: number
}

// Cube types
export enum CubeType {
  OSCILLATOR = 'oscillator',
  FILTER = 'filter',
  GAIN = 'gain',
  OUTPUT = 'output'
}

export interface CubeInstance {
  id: string
  type: CubeType
  transform: Transform3D
  audioNodeId: string
  isActive: boolean
  parameters: CubeParameters
}

export interface CubeParameters {
  [key: string]: number
}

export interface CubeTypeDefinition {
  type: CubeType
  name: string
  description: string
  parameters: ParameterDefinition[]
  defaultValues: AudioParams
  color: string
  canConnect: {
    input: boolean
    output: boolean
  }
}

export interface ParameterDefinition {
  name: string
  displayName: string
  min: number
  max: number
  default: number
  scale: 'linear' | 'logarithmic'
  unit: string
  mappedTo: '3d-transform' | 'ui-control'
}

// Connection types
export interface Connection {
  id: string
  fromCubeId: string
  toCubeId: string
  strength: number
  isActive: boolean
}

// Interaction types
export interface RaycastResult {
  object: any
  point: Vector3
  distance: number
  screenPosition?: Vector2
  cubeId?: string | null
  cubeType?: CubeType | null
}

// Performance types
export interface PerformanceStatus {
  fps: number
  audioLatency: number
  cpuUsage: number
  memoryUsage: number
  isDegraded: boolean
  recommendations: string[]
}

// Error types
export enum ErrorType {
  AUDIO_CONTEXT_FAILED = 'audio_context_failed',
  WEBGL_NOT_SUPPORTED = 'webgl_not_supported',
  AUDIO_PERMISSION_DENIED = 'audio_permission_denied',
  INVALID_PROJECT_FILE = 'invalid_project_file',
  RECORDING_NOT_SUPPORTED = 'recording_not_supported',
  PERFORMANCE_DEGRADATION = 'performance_degradation'
}

// Persistence types
export interface ProjectSchema {
  version: string
  metadata: {
    name: string
    created: string
    modified: string
    author?: string
  }
  cubes: SerializedCube[]
  connections: SerializedConnection[]
  settings: ProjectSettings
}

export interface SerializedCube {
  id: string
  type: CubeType
  position: [number, number, number]
  rotation: [number, number, number]
  scale: [number, number, number]
  parameters: AudioParams
}

export interface SerializedConnection {
  id: string
  fromCubeId: string
  toCubeId: string
}

export interface ProjectSettings {
  masterVolume: number
  tempo: number
  scale: string
}