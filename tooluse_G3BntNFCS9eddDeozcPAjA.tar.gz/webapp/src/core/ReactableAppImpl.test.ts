import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest'
import { ReactableAppImpl } from './ReactableAppImpl'

// Mock the RenderEngineImpl
vi.mock('@/rendering/RenderEngineImpl', () => ({
  RenderEngineImpl: vi.fn().mockImplementation(() => ({
    render: vi.fn(),
    destroy: vi.fn(),
    initializeScene: vi.fn(),
    addCube: vi.fn(),
    removeCube: vi.fn(),
    updateCube: vi.fn(),
    raycast: vi.fn(() => []),
    setSize: vi.fn(),
    showConnection: vi.fn(),
    hideConnection: vi.fn()
  }))
}))

describe('ReactableAppImpl', () => {
  let app: ReactableAppImpl
  let mockContainer: HTMLElement

  beforeEach(() => {
    // Create mock canvas container
    mockContainer = document.createElement('div')
    mockContainer.id = 'canvas-container'
    mockContainer.style.width = '800px'
    mockContainer.style.height = '600px'
    document.body.appendChild(mockContainer)
    
    app = new ReactableAppImpl()
  })

  afterEach(() => {
    app.destroy()
    if (mockContainer.parentElement) {
      document.body.removeChild(mockContainer)
    }
  })

  it('should initialize with default state', () => {
    const state = app.getState()
    
    expect(state.isAudioStarted).toBe(false)
    expect(state.cubes.size).toBe(0)
    expect(state.connections).toEqual([])
    expect(state.selectedCube).toBeNull()
    expect(state.isRecording).toBe(false)
  })

  it('should initialize successfully', async () => {
    await expect(app.initialize()).resolves.not.toThrow()
  })

  it('should throw error if canvas container is not found', async () => {
    // Remove the container
    document.body.removeChild(mockContainer)
    
    await expect(app.initialize()).rejects.toThrow('Canvas container not found')
  })

  it('should start audio successfully', async () => {
    await app.initialize()
    await app.startAudio()
    
    const state = app.getState()
    expect(state.isAudioStarted).toBe(true)
  })

  it('should update state correctly', () => {
    const newState = { isRecording: true, selectedCube: 'test-cube' }
    app.setState(newState)
    
    const state = app.getState()
    expect(state.isRecording).toBe(true)
    expect(state.selectedCube).toBe('test-cube')
    expect(state.isAudioStarted).toBe(false) // Should preserve other state
  })

  it('should handle update and render calls', () => {
    expect(() => app.update(16)).not.toThrow()
    expect(() => app.render()).not.toThrow()
  })

  it('should handle destroy call', () => {
    expect(() => app.destroy()).not.toThrow()
  })
})