import { Vector3 } from 'three'
import { CubeManager } from '@/interfaces/CubeManager'
import { CubeType, CubeInstance, AudioParams, Transform3D } from '@/types'
import { CubeFactory } from './CubeFactory'

export class CubeManagerImpl implements CubeManager {
  private cubes: Map<string, CubeInstance> = new Map()
  private selectedCubeId: string | null = null
  private onCubeStateChange?: (cubeId: string, cube: CubeInstance) => void
  private onCubeCreated?: (cube: CubeInstance) => void
  private onCubeDestroyed?: (cubeId: string) => void

  constructor() {
    // Initialize empty cube manager
  }

  /**
   * Sets callback for cube state changes
   */
  setOnCubeStateChange(callback: (cubeId: string, cube: CubeInstance) => void): void {
    this.onCubeStateChange = callback
  }

  /**
   * Sets callback for cube creation
   */
  setOnCubeCreated(callback: (cube: CubeInstance) => void): void {
    this.onCubeCreated = callback
  }

  /**
   * Sets callback for cube destruction
   */
  setOnCubeDestroyed(callback: (cubeId: string) => void): void {
    this.onCubeDestroyed = callback
  }

  // Cube lifecycle methods
  createCube(type: CubeType, position: Vector3): CubeInstance {
    const cube = CubeFactory.createCube(type, position)
    this.cubes.set(cube.id, cube)
    
    // Notify listeners
    this.onCubeCreated?.(cube)
    
    return cube
  }

  destroyCube(cubeId: string): void {
    const cube = this.cubes.get(cubeId)
    if (!cube) {
      throw new Error(`Cube with ID ${cubeId} not found`)
    }

    // Deactivate cube before destroying
    if (cube.isActive) {
      this.deactivateCube(cubeId)
    }

    // Remove from selection if selected
    if (this.selectedCubeId === cubeId) {
      this.deselectCube()
    }

    // Remove from cubes map
    this.cubes.delete(cubeId)
    
    // Notify listeners
    this.onCubeDestroyed?.(cubeId)
  }

  getCube(cubeId: string): CubeInstance | null {
    return this.cubes.get(cubeId) || null
  }

  getAllCubes(): CubeInstance[] {
    return Array.from(this.cubes.values())
  }

  // Cube manipulation methods
  moveCube(cubeId: string, position: Vector3): void {
    const cube = this.getCube(cubeId)
    if (!cube) {
      throw new Error(`Cube with ID ${cubeId} not found`)
    }

    cube.transform.position.copy(position)
    this.notifyStateChange(cubeId, cube)
  }

  rotateCube(cubeId: string, rotation: Vector3): void {
    const cube = this.getCube(cubeId)
    if (!cube) {
      throw new Error(`Cube with ID ${cubeId} not found`)
    }

    cube.transform.rotation.copy(rotation)
    
    // Update audio parameters based on rotation
    const audioParams = this.mapTransformToAudio(cube)
    cube.parameters = { ...cube.parameters, ...audioParams }
    
    this.notifyStateChange(cubeId, cube)
  }

  scaleCube(cubeId: string, scale: Vector3): void {
    const cube = this.getCube(cubeId)
    if (!cube) {
      throw new Error(`Cube with ID ${cubeId} not found`)
    }

    cube.transform.scale.copy(scale)
    this.notifyStateChange(cubeId, cube)
  }

  // Parameter mapping
  mapTransformToAudio(cube: CubeInstance): AudioParams {
    const typeDefinition = CubeFactory.getCubeTypeDefinition(cube.type)
    const audioParams: AudioParams = {}

    // Map rotation to parameters based on cube type
    for (let i = 0; i < typeDefinition.parameters.length; i++) {
      const paramDef = typeDefinition.parameters[i]
      
      if (paramDef.mappedTo === '3d-transform') {
        let normalizedValue: number
        
        // Map rotation axes to parameters (Y rotation for primary, X for secondary)
        if (i === 0) {
          // Primary parameter mapped to Y rotation (-π to π -> 0 to 1)
          normalizedValue = (cube.transform.rotation.y + Math.PI) / (2 * Math.PI)
        } else if (i === 1) {
          // Secondary parameter mapped to X rotation
          normalizedValue = (cube.transform.rotation.x + Math.PI) / (2 * Math.PI)
        } else {
          // Additional parameters mapped to Z rotation or scale
          normalizedValue = (cube.transform.rotation.z + Math.PI) / (2 * Math.PI)
        }

        // Clamp to [0, 1]
        normalizedValue = Math.max(0, Math.min(1, normalizedValue))

        // Apply scaling (linear or logarithmic)
        let paramValue: number
        if (paramDef.scale === 'logarithmic') {
          // Logarithmic scaling for frequency-like parameters
          const logMin = Math.log(paramDef.min)
          const logMax = Math.log(paramDef.max)
          paramValue = Math.exp(logMin + normalizedValue * (logMax - logMin))
        } else {
          // Linear scaling
          paramValue = paramDef.min + normalizedValue * (paramDef.max - paramDef.min)
        }

        audioParams[paramDef.name] = paramValue
      }
    }

    return audioParams
  }

  // Selection methods
  selectCube(cubeId: string): void {
    const cube = this.getCube(cubeId)
    if (!cube) {
      throw new Error(`Cube with ID ${cubeId} not found`)
    }

    this.selectedCubeId = cubeId
    this.notifyStateChange(cubeId, cube)
  }

  deselectCube(): void {
    if (this.selectedCubeId) {
      const previouslySelected = this.selectedCubeId
      this.selectedCubeId = null
      
      const cube = this.getCube(previouslySelected)
      if (cube) {
        this.notifyStateChange(previouslySelected, cube)
      }
    }
  }

  getSelectedCube(): CubeInstance | null {
    if (!this.selectedCubeId) {
      return null
    }
    return this.getCube(this.selectedCubeId)
  }

  // Cube activation/deactivation
  activateCube(cubeId: string): void {
    const cube = this.getCube(cubeId)
    if (!cube) {
      throw new Error(`Cube with ID ${cubeId} not found`)
    }

    if (!cube.isActive) {
      cube.isActive = true
      this.notifyStateChange(cubeId, cube)
    }
  }

  deactivateCube(cubeId: string): void {
    const cube = this.getCube(cubeId)
    if (!cube) {
      throw new Error(`Cube with ID ${cubeId} not found`)
    }

    if (cube.isActive) {
      cube.isActive = false
      this.notifyStateChange(cubeId, cube)
    }
  }

  // Cube state queries
  isSelected(cubeId: string): boolean {
    return this.selectedCubeId === cubeId
  }

  isActive(cubeId: string): boolean {
    const cube = this.getCube(cubeId)
    return cube ? cube.isActive : false
  }

  getActiveCubes(): CubeInstance[] {
    return this.getAllCubes().filter(cube => cube.isActive)
  }

  getCubesByType(type: CubeType): CubeInstance[] {
    return this.getAllCubes().filter(cube => cube.type === type)
  }

  // Batch operations
  updateCubeParameters(cubeId: string, newParameters: Partial<AudioParams>): void {
    const cube = this.getCube(cubeId)
    if (!cube) {
      throw new Error(`Cube with ID ${cubeId} not found`)
    }

    // Validate and update parameters
    cube.parameters = CubeFactory.updateCubeParameters(cube, newParameters)
    this.notifyStateChange(cubeId, cube)
  }

  updateCubeTransform(cubeId: string, transform: Partial<Transform3D>): void {
    const cube = this.getCube(cubeId)
    if (!cube) {
      throw new Error(`Cube with ID ${cubeId} not found`)
    }

    if (transform.position) {
      cube.transform.position.copy(transform.position)
    }
    if (transform.rotation) {
      cube.transform.rotation.copy(transform.rotation)
      // Update audio parameters when rotation changes
      const audioParams = this.mapTransformToAudio(cube)
      cube.parameters = { ...cube.parameters, ...audioParams }
    }
    if (transform.scale) {
      cube.transform.scale.copy(transform.scale)
    }

    this.notifyStateChange(cubeId, cube)
  }

  // Utility methods
  getCubeCount(): number {
    return this.cubes.size
  }

  getActiveCubeCount(): number {
    return this.getActiveCubes().length
  }

  clear(): void {
    const cubeIds = Array.from(this.cubes.keys())
    
    // Destroy all cubes
    for (const cubeId of cubeIds) {
      this.destroyCube(cubeId)
    }
    
    // Clear selection
    this.selectedCubeId = null
  }

  // Clone cube
  cloneCube(sourceCubeId: string, newPosition: Vector3): CubeInstance {
    const sourceCube = this.getCube(sourceCubeId)
    if (!sourceCube) {
      throw new Error(`Source cube with ID ${sourceCubeId} not found`)
    }

    const clonedCube = CubeFactory.cloneCube(sourceCube, newPosition)
    this.cubes.set(clonedCube.id, clonedCube)
    
    // Notify listeners
    this.onCubeCreated?.(clonedCube)
    
    return clonedCube
  }

  // Private helper methods
  private notifyStateChange(cubeId: string, cube: CubeInstance): void {
    this.onCubeStateChange?.(cubeId, cube)
  }
}