import { ReactableApp } from '@/interfaces/ReactableApp'
import { RenderEngineImpl } from '@/rendering/RenderEngineImpl'
import { InteractionManagerImpl } from '@/core/InteractionManagerImpl'
import { UIManager } from '@/ui/UIManager'
import { ProjectManager } from '@/services/ProjectManager'
import { AudioEngineImpl } from '@/audio/AudioEngineImpl'
import { ConnectionManagerImpl } from '@/core/ConnectionManagerImpl'
import { CubeManagerImpl } from '@/core/CubeManagerImpl'
import { ErrorHandlerImpl } from '@/services/ErrorHandlerImpl'
import { AppState, CubeInstance, CubeType, Transform3D, ErrorType } from '@/types'
import { Vector2, Vector3 } from 'three'

export class ReactableAppImpl implements ReactableApp {
  private state: AppState = {
    isAudioStarted: false,
    cubes: new Map(),
    connections: [],
    selectedCube: null,
    isRecording: false
  }
  
  private renderEngine: RenderEngineImpl | null = null
  private interactionManager: InteractionManagerImpl | null = null
  private uiManager: UIManager | null = null
  private projectManager: ProjectManager | null = null
  private audioEngine: AudioEngineImpl | null = null
  private connectionManager: ConnectionManagerImpl | null = null
  private cubeManager: CubeManagerImpl | null = null
  private errorHandler: ErrorHandlerImpl | null = null

  async initialize(): Promise<void> {
    console.log('Initializing ReacTable 3D Emulator...')
    
    // Initialize error handler
    this.errorHandler = new ErrorHandlerImpl()
    
    // Initialize 3D scene
    const canvasContainer = document.getElementById('canvas-container')
    if (!canvasContainer) {
      throw new Error('Canvas container not found')
    }
    
    this.renderEngine = new RenderEngineImpl(canvasContainer)
    console.log('3D scene initialized')
    
    // Initialize audio engine (suspended)
    this.audioEngine = new AudioEngineImpl()
    await this.audioEngine.initialize(this.errorHandler)
    console.log('Audio engine initialized (suspended)')
    
    // Initialize cube and connection managers
    this.cubeManager = new CubeManagerImpl()
    this.connectionManager = new ConnectionManagerImpl()
    console.log('Cube and connection managers initialized')
    
    // Initialize interaction manager
    this.interactionManager = new InteractionManagerImpl()
    this.interactionManager.initialize(canvasContainer)
    this.interactionManager.setRenderEngine(this.renderEngine)
    this.setupInteractionCallbacks()
    console.log('Interaction manager initialized')
    
    // Initialize project manager
    this.projectManager = new ProjectManager((error: ErrorType, message: string) => {
      console.error(`Project error: ${error} - ${message}`)
      if (this.uiManager) {
        this.uiManager.showToast(message, 'error')
      }
    })
    console.log('Project manager initialized')

    // Initialize UI manager
    this.uiManager = new UIManager(this, {
      cubeTypeSelected: (cubeType: CubeType) => {
        console.log(`Cube type selected: ${cubeType}`)
      },
      clearScene: () => {
        this.clearAllCubes()
      },
      startAudio: async () => {
        await this.startAudio()
      },
      stopAudio: () => {
        this.stopAudio()
      },
      startRecording: () => {
        this.startRecording()
      },
      pauseRecording: () => {
        this.pauseRecording()
      },
      stopRecording: () => {
        this.stopRecording()
      },
      saveProject: () => {
        this.saveProject()
      },
      loadProject: () => {
        this.loadProject()
      },
      exportProject: () => {
        this.exportProject()
      },
      importProject: (file: File) => {
        this.importProject(file)
      },
      newProject: () => {
        this.newProject()
      }
    })
    console.log('UI manager initialized')
    
    // Try to load saved project
    this.loadProject()
    
    // Start auto-save
    if (this.projectManager) {
      this.projectManager.startAutoSave(() => this.state)
    }
    
    console.log('ReacTable initialized (audio suspended)')
  }

  async startAudio(): Promise<void> {
    console.log('Starting audio context...')
    
    if (!this.audioEngine) {
      throw new Error('Audio engine not initialized')
    }
    
    try {
      await this.audioEngine.start()
      this.state.isAudioStarted = true
      
      // Setup audio nodes for existing cubes
      this.setupAudioForExistingCubes()
      
      // Update UI state
      if (this.uiManager) {
        this.uiManager.updateAudioState(true)
        this.uiManager.showUI()
        this.uiManager.showToast('Audio started successfully!', 'info')
      }
      
      console.log('Audio context started')
    } catch (error) {
      console.error('Failed to start audio:', error)
      if (this.uiManager) {
        this.uiManager.showToast('Failed to start audio. Please try again.', 'error')
      }
      throw error
    }
  }

  stopAudio(): void {
    console.log('Stopping audio context...')
    
    if (this.audioEngine) {
      this.audioEngine.stop()
    }
    
    this.state.isAudioStarted = false
    
    // Update UI state
    if (this.uiManager) {
      this.uiManager.updateAudioState(false)
      this.uiManager.showToast('Audio stopped', 'info')
    }
    
    console.log('Audio context stopped')
  }

  startRecording(): void {
    if (!this.state.isAudioStarted) {
      if (this.uiManager) {
        this.uiManager.showToast('Please start audio first', 'warning')
      }
      return
    }

    if (!this.audioEngine) {
      if (this.uiManager) {
        this.uiManager.showToast('Audio engine not available', 'error')
      }
      return
    }

    try {
      this.audioEngine.startRecording()
      console.log('Recording started')
      this.state.isRecording = true
      
      if (this.uiManager) {
        this.uiManager.showToast('Recording started', 'info')
        this.updateRecordingUI()
      }
    } catch (error) {
      console.error('Failed to start recording:', error)
      if (this.uiManager) {
        this.uiManager.showToast(`Recording failed: ${error}`, 'error')
      }
    }
  }

  pauseRecording(): void {
    if (!this.state.isRecording || !this.audioEngine) {
      return
    }

    try {
      this.audioEngine.pauseRecording()
      console.log('Recording paused/resumed')
      
      if (this.uiManager) {
        this.uiManager.showToast('Recording paused/resumed', 'info')
        this.updateRecordingUI()
      }
    } catch (error) {
      console.error('Failed to pause/resume recording:', error)
      if (this.uiManager) {
        this.uiManager.showToast(`Recording pause failed: ${error}`, 'error')
      }
    }
  }

  async stopRecording(): Promise<void> {
    if (!this.state.isRecording || !this.audioEngine) {
      return
    }

    try {
      const recordingBlob = await this.audioEngine.stopRecording()
      console.log('Recording stopped')
      this.state.isRecording = false
      
      // Save the recording
      this.saveRecording(recordingBlob)
      
      if (this.uiManager) {
        this.uiManager.showToast('Recording stopped and saved', 'info')
        this.updateRecordingUI()
      }
    } catch (error) {
      console.error('Failed to stop recording:', error)
      this.state.isRecording = false
      if (this.uiManager) {
        this.uiManager.showToast(`Recording stop failed: ${error}`, 'error')
        this.updateRecordingUI()
      }
    }
  }

  getState(): AppState {
    return { ...this.state }
  }

  setState(state: Partial<AppState>): void {
    this.state = { ...this.state, ...state }
  }

  update(_deltaTime: number): void {
    // Update audio parameters based on cube positions/rotations
    this.updateAudioParameters()
    
    // Update connections between cubes
    this.updateConnections()
    
    // Update recording state in UI
    if (this.state.isRecording && this.audioEngine && this.uiManager) {
      this.updateRecordingUI()
    }
  }

  render(): void {
    if (this.renderEngine) {
      this.renderEngine.render()
    }
  }

  destroy(): void {
    if (this.audioEngine) {
      this.audioEngine.stop()
      this.audioEngine = null
    }
    
    if (this.projectManager) {
      this.projectManager.destroy()
      this.projectManager = null
    }
    
    if (this.uiManager) {
      this.uiManager.hideUI()
      this.uiManager = null
    }
    
    if (this.interactionManager) {
      this.interactionManager.destroy()
      this.interactionManager = null
    }
    
    if (this.renderEngine) {
      this.renderEngine.destroy()
      this.renderEngine = null
    }
    
    this.connectionManager = null
    this.cubeManager = null
    this.errorHandler = null
  }

  private setupInteractionCallbacks(): void {
    if (!this.interactionManager || !this.renderEngine) return

    // Handle cube clicks (selection and table clicks for creation)
    this.interactionManager.setOnCubeClick((cubeId: string | null, screenPosition: Vector2) => {
      if (cubeId) {
        // Select existing cube
        this.state.selectedCube = cubeId
        this.renderEngine!.selectCube(cubeId)
      } else if (this.uiManager && this.uiManager.isInPlacementMode()) {
        // Clicked on table while in placement mode - create new cube
        this.createCubeAtScreenPosition(screenPosition)
      }
    })

    // Handle cube deletion
    this.interactionManager.setOnCubeDelete((cubeId: string) => {
      this.deleteCube(cubeId)
    })

    // Handle drag operations
    this.interactionManager.setOnDragStart((cubeId: string, screenPosition: Vector2) => {
      this.renderEngine!.startDragCube(cubeId, screenPosition)
    })

    this.interactionManager.setOnDragUpdate((screenPosition: Vector2) => {
      this.renderEngine!.updateDragCube(screenPosition)
    })

    this.interactionManager.setOnDragEnd(() => {
      this.renderEngine!.endDragCube()
      this.updateCubeTransformFromRender()
    })

    // Handle rotation operations
    this.interactionManager.setOnRotateStart((cubeId: string, screenPosition: Vector2) => {
      this.renderEngine!.startRotateCube(cubeId, screenPosition)
    })

    this.interactionManager.setOnRotateUpdate((screenPosition: Vector2) => {
      this.renderEngine!.updateRotateCube(screenPosition)
    })

    this.interactionManager.setOnRotateEnd(() => {
      this.renderEngine!.endRotateCube()
      this.updateCubeTransformFromRender()
    })
  }

  private createCubeAtScreenPosition(screenPosition: Vector2): void {
    if (!this.renderEngine || !this.uiManager) return

    const selectedType = this.uiManager.getSelectedCubeType()
    if (!selectedType) return

    // Perform raycast to get world position on table
    const raycastResults = this.renderEngine.raycast(screenPosition)
    const tableHit = raycastResults.find(hit => hit.object.name === 'table')
    
    if (tableHit) {
      // Create a new cube at the clicked position
      const cubeId = `cube-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
      const cube: CubeInstance = {
        id: cubeId,
        type: selectedType,
        transform: {
          position: new Vector3(tableHit.point.x, 0.5, tableHit.point.z), // Place slightly above table
          rotation: new Vector3(0, 0, 0),
          scale: new Vector3(1, 1, 1)
        },
        audioNodeId: '', // Will be set if audio is started
        isActive: false,
        parameters: {}
      }

      // Create audio node if audio is started
      if (this.state.isAudioStarted && this.audioEngine) {
        try {
          cube.audioNodeId = this.audioEngine.createAudioNode(selectedType, {})
          cube.isActive = true
        } catch (error) {
          console.error(`Failed to create audio node for new cube:`, error)
        }
      }

      // Add to state and render
      this.state.cubes.set(cubeId, cube)
      this.renderEngine.addCube(cube)
      
      // Select the newly created cube
      this.state.selectedCube = cubeId
      this.renderEngine.selectCube(cubeId)
      
      // Confirm placement in UI
      this.uiManager.confirmPlacement()
      
      // Show success message
      this.uiManager.showToast(`Created ${selectedType} cube`, 'info')
      
      console.log(`Created ${selectedType} cube ${cubeId} at position`, cube.transform.position)
    }
  }

  private deleteCube(cubeId: string): void {
    if (!this.renderEngine) return

    const cube = this.state.cubes.get(cubeId)
    if (cube) {
      // Remove audio node if exists
      if (cube.audioNodeId && this.audioEngine) {
        try {
          this.audioEngine.removeAudioNode(cube.audioNodeId)
        } catch (error) {
          console.error(`Failed to remove audio node for cube ${cubeId}:`, error)
        }
      }
      
      // Remove from render engine
      this.renderEngine.removeCube(cubeId)
      
      // Remove from state
      this.state.cubes.delete(cubeId)
      
      // Clear selection if this was the selected cube
      if (this.state.selectedCube === cubeId) {
        this.state.selectedCube = null
        this.renderEngine.clearSelection()
      }
      
      console.log(`Deleted cube ${cubeId}`)
      
      // Show confirmation
      if (this.uiManager) {
        this.uiManager.showToast(`Deleted ${cube.type} cube`, 'info')
      }
    }
  }

  private updateCubeTransformFromRender(): void {
    if (!this.renderEngine || !this.state.selectedCube) return

    const cubeId = this.state.selectedCube
    const cube = this.state.cubes.get(cubeId)
    
    if (cube) {
      // Get the current transform from the render engine
      const cubeGroup = this.renderEngine.getScene().getObjectByName(`cube-${cubeId}`)
      if (cubeGroup) {
        // Update the cube's transform in our state
        cube.transform.position.copy(cubeGroup.position)
        cube.transform.rotation.setFromEuler(cubeGroup.rotation)
        cube.transform.scale.copy(cubeGroup.scale)
        
        console.log(`Updated cube ${cubeId} transform:`, {
          position: cube.transform.position.toArray(),
          rotation: cube.transform.rotation.toArray(),
          scale: cube.transform.scale.toArray()
        })
        
        // Update audio parameters based on new transform
        this.updateAudioNodeFromCube(cube)
      }
    }
  }

  private clearAllCubes(): void {
    if (!this.renderEngine) return

    // Remove all cubes from render engine
    for (const cubeId of this.state.cubes.keys()) {
      this.renderEngine.removeCube(cubeId)
    }

    // Clear state
    this.state.cubes.clear()
    this.state.selectedCube = null
    this.state.connections = []

    // Clear selection
    this.renderEngine.clearSelection()

    // Show confirmation
    if (this.uiManager) {
      this.uiManager.showToast('All cubes cleared', 'info')
    }

    console.log('Cleared all cubes')
  }

  // Project Management Methods

  saveProject(name?: string): void {
    if (!this.projectManager || !this.uiManager) return

    try {
      const projectId = this.projectManager.saveCurrentProject(this.state, {
        name: name || 'My Project',
        author: 'ReacTable User'
      })
      
      this.uiManager.showToast('Project saved successfully', 'info')
      console.log(`Project saved with ID: ${projectId}`)
    } catch (error) {
      console.error('Failed to save project:', error)
      this.uiManager.showToast('Failed to save project', 'error')
    }
  }

  loadProject(): void {
    if (!this.projectManager || !this.renderEngine) return

    try {
      const loadedProject = this.projectManager.loadCurrentProject()
      
      if (loadedProject) {
        // Clear current scene
        this.clearAllCubes()
        
        // Load cubes
        for (const cube of loadedProject.cubes.values()) {
          this.state.cubes.set(cube.id, cube)
          this.renderEngine.addCube(cube)
        }
        
        // Load connections
        this.state.connections = loadedProject.connections
        
        // Update UI
        if (this.uiManager) {
          this.uiManager.showToast(`Loaded: ${loadedProject.metadata.name}`, 'info')
        }
        
        console.log(`Project loaded: ${loadedProject.metadata.name}`)
      } else {
        console.log('No saved project found')
      }
    } catch (error) {
      console.error('Failed to load project:', error)
      if (this.uiManager) {
        this.uiManager.showToast('Failed to load project', 'error')
      }
    }
  }

  exportProject(filename?: string): void {
    if (!this.projectManager || !this.uiManager) return

    try {
      this.projectManager.exportProject(this.state, filename, {
        name: 'Exported Project',
        author: 'ReacTable User'
      })
      
      this.uiManager.showToast('Project exported successfully', 'info')
    } catch (error) {
      console.error('Failed to export project:', error)
      this.uiManager.showToast('Failed to export project', 'error')
    }
  }

  async importProject(file: File): Promise<void> {
    if (!this.projectManager || !this.renderEngine || !this.uiManager) return

    try {
      const importedProject = await this.projectManager.importProject(file)
      
      // Clear current scene
      this.clearAllCubes()
      
      // Load cubes
      for (const cube of importedProject.cubes.values()) {
        this.state.cubes.set(cube.id, cube)
        this.renderEngine.addCube(cube)
      }
      
      // Load connections
      this.state.connections = importedProject.connections
      
      this.uiManager.showToast(`Imported: ${importedProject.metadata.name}`, 'info')
      console.log(`Project imported: ${importedProject.metadata.name}`)
    } catch (error) {
      console.error('Failed to import project:', error)
      this.uiManager.showToast('Failed to import project', 'error')
    }
  }

  newProject(name?: string): void {
    if (!this.projectManager || !this.uiManager) return

    try {
      // Clear current scene
      this.clearAllCubes()
      
      // Create new project
      const projectId = this.projectManager.createNewProject(name || 'New Project')
      
      this.uiManager.showToast('New project created', 'info')
      console.log(`New project created with ID: ${projectId}`)
    } catch (error) {
      console.error('Failed to create new project:', error)
      this.uiManager.showToast('Failed to create new project', 'error')
    }
  }

  getProjectsList(): Array<{
    id: string
    name: string
    created: string
    modified: string
    author?: string
  }> {
    return this.projectManager?.getProjectsList() || []
  }

  getStorageInfo(): {
    used: number
    available: number
    percentage: number
  } {
    return this.projectManager?.getStorageInfo() || { used: 0, available: 0, percentage: 0 }
  }

  // Audio Integration Methods

  private setupAudioForExistingCubes(): void {
    if (!this.audioEngine) return
    
    // Create audio nodes for existing cubes
    for (const cube of this.state.cubes.values()) {
      try {
        const audioNodeId = this.audioEngine.createAudioNode(cube.type, cube.parameters)
        cube.audioNodeId = audioNodeId
        this.updateAudioNodeFromCube(cube)
      } catch (error) {
        console.error(`Failed to create audio node for cube ${cube.id}:`, error)
      }
    }
  }

  private updateAudioParameters(): void {
    if (!this.audioEngine || !this.cubeManager) return
    
    // Update audio parameters for all cubes based on their 3D transforms
    for (const cube of this.state.cubes.values()) {
      if (cube.audioNodeId) {
        const audioParams = this.cubeManager.mapTransformToAudio(cube)
        try {
          this.audioEngine.updateAudioNode(cube.audioNodeId, audioParams)
        } catch (error) {
          console.error(`Failed to update audio node ${cube.audioNodeId}:`, error)
        }
      }
    }
  }

  private updateConnections(): void {
    if (!this.connectionManager || !this.audioEngine) return
    
    // Get current cubes as array
    const cubes = Array.from(this.state.cubes.values())
    
    // Update connection detection
    this.connectionManager.updateConnections(cubes)
    
    // Get new connections and update audio routing
    const newConnections = this.connectionManager.getConnections()
    
    // Update state connections
    this.state.connections = newConnections
    
    // Update audio connections
    for (const connection of newConnections) {
      if (connection.isActive) {
        const fromCube = this.state.cubes.get(connection.fromCubeId)
        const toCube = this.state.cubes.get(connection.toCubeId)
        
        if (fromCube && toCube && fromCube.audioNodeId && toCube.audioNodeId) {
          try {
            this.audioEngine.connectNodes(fromCube.audioNodeId, toCube.audioNodeId)
          } catch (error) {
            console.error(`Failed to connect audio nodes ${fromCube.audioNodeId} -> ${toCube.audioNodeId}:`, error)
          }
        }
      }
    }
    
    // Update visual connections in render engine
    if (this.renderEngine) {
      // Show/hide connections based on the state
      for (const connection of newConnections) {
        if (connection.isActive) {
          this.renderEngine.showConnection(connection.fromCubeId, connection.toCubeId, connection.strength)
        } else {
          this.renderEngine.hideConnection(connection.fromCubeId, connection.toCubeId)
        }
      }
    }
  }

  private updateAudioNodeFromCube(cube: CubeInstance): void {
    if (!this.audioEngine || !cube.audioNodeId || !this.cubeManager) return
    
    const audioParams = this.cubeManager.mapTransformToAudio(cube)
    try {
      this.audioEngine.updateAudioNode(cube.audioNodeId, audioParams)
    } catch (error) {
      console.error(`Failed to update audio node for cube ${cube.id}:`, error)
    }
  }

  private updateRecordingUI(): void {
    if (!this.audioEngine || !this.uiManager) return
    
    const recordingState = this.audioEngine.getRecordingState()
    this.uiManager.updateRecordingState(recordingState)
  }

  private saveRecording(blob: Blob): void {
    // Create download link
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `reactable-recording-${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}.webm`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }
}