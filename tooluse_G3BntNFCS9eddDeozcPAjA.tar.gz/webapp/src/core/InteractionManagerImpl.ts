import { Vector2 } from 'three'
import { InteractionManager, InteractionState } from '@/interfaces/InteractionManager'
import { RenderEngine } from '@/interfaces/RenderEngine'

export class InteractionManagerImpl implements InteractionManager {
  private container: HTMLElement | null = null
  private renderEngine: RenderEngine | null = null
  private state: InteractionState = {
    isMouseDown: false,
    isDragging: false,
    isRotating: false,
    pressedKeys: new Set(),
    mousePosition: new Vector2(),
    selectedCubeId: null
  }

  // Event callbacks
  private onCubeClickCallback: ((cubeId: string | null, screenPosition: Vector2) => void) | null = null
  private onCubeDeleteCallback: ((cubeId: string) => void) | null = null
  private onDragStartCallback: ((cubeId: string, screenPosition: Vector2) => void) | null = null
  private onDragUpdateCallback: ((screenPosition: Vector2) => void) | null = null
  private onDragEndCallback: (() => void) | null = null
  private onRotateStartCallback: ((cubeId: string, screenPosition: Vector2) => void) | null = null
  private onRotateUpdateCallback: ((screenPosition: Vector2) => void) | null = null
  private onRotateEndCallback: (() => void) | null = null

  // Constants
  private readonly DRAG_THRESHOLD = 5 // pixels
  private mouseDownPosition = new Vector2()

  initialize(container: HTMLElement): void {
    this.container = container
    this.setupEventListeners()
  }

  setRenderEngine(renderEngine: RenderEngine): void {
    this.renderEngine = renderEngine
  }

  private setupEventListeners(): void {
    if (!this.container) return

    // Mouse events
    this.container.addEventListener('mousedown', this.handleMouseDown.bind(this))
    this.container.addEventListener('mousemove', this.handleMouseMove.bind(this))
    this.container.addEventListener('mouseup', this.handleMouseUp.bind(this))
    this.container.addEventListener('contextmenu', this.handleContextMenu.bind(this))

    // Keyboard events (on document to capture when canvas doesn't have focus)
    document.addEventListener('keydown', this.handleKeyDown.bind(this))
    document.addEventListener('keyup', this.handleKeyUp.bind(this))

    // Prevent default drag behavior on the container
    this.container.addEventListener('dragstart', (e) => e.preventDefault())
  }

  private handleMouseDown(event: MouseEvent): void {
    if (event.button !== 0) return // Only handle left mouse button

    const rect = this.container!.getBoundingClientRect()
    const screenPosition = new Vector2(
      event.clientX - rect.left,
      event.clientY - rect.top
    )

    this.state.isMouseDown = true
    this.state.mousePosition.copy(screenPosition)
    this.mouseDownPosition.copy(screenPosition)

    // Perform raycast to see what was clicked
    if (this.renderEngine) {
      const raycastResults = this.renderEngine.raycast(screenPosition)
      
      if (raycastResults.length > 0) {
        const hit = raycastResults[0]
        
        if (hit.cubeId) {
          // Clicked on a cube
          this.state.selectedCubeId = hit.cubeId
          
          // Check if R key is pressed for rotation
          if (this.state.pressedKeys.has('KeyR')) {
            this.startRotation(hit.cubeId, screenPosition)
          } else {
            // Prepare for potential drag (will be confirmed on mouse move)
            // Don't start drag immediately to allow for simple clicks
          }
        } else {
          // Clicked on table or empty space
          this.state.selectedCubeId = null
          if (this.renderEngine) {
            this.renderEngine.clearSelection()
          }
        }
      }

      // Notify about click
      if (this.onCubeClickCallback) {
        this.onCubeClickCallback(this.state.selectedCubeId, screenPosition)
      }
    }
  }

  private handleMouseMove(event: MouseEvent): void {
    const rect = this.container!.getBoundingClientRect()
    const screenPosition = new Vector2(
      event.clientX - rect.left,
      event.clientY - rect.top
    )

    this.state.mousePosition.copy(screenPosition)

    if (this.state.isMouseDown && !this.state.isDragging && !this.state.isRotating) {
      // Check if we've moved enough to start dragging
      const dragDistance = screenPosition.distanceTo(this.mouseDownPosition)
      
      if (dragDistance > this.DRAG_THRESHOLD && this.state.selectedCubeId) {
        // Start dragging if we have a selected cube and aren't rotating
        if (!this.state.pressedKeys.has('KeyR')) {
          this.startDrag(this.state.selectedCubeId, screenPosition)
        }
      }
    }

    // Update ongoing drag or rotation
    if (this.state.isDragging && this.onDragUpdateCallback) {
      this.onDragUpdateCallback(screenPosition)
    } else if (this.state.isRotating && this.onRotateUpdateCallback) {
      this.onRotateUpdateCallback(screenPosition)
    }
  }

  private handleMouseUp(event: MouseEvent): void {
    if (event.button !== 0) return // Only handle left mouse button

    this.state.isMouseDown = false

    // End drag or rotation
    if (this.state.isDragging) {
      this.endDrag()
    } else if (this.state.isRotating) {
      this.endRotation()
    }
  }

  private handleContextMenu(event: MouseEvent): void {
    event.preventDefault() // Prevent browser context menu
  }

  private handleKeyDown(event: KeyboardEvent): void {
    this.state.pressedKeys.add(event.code)

    // Handle Delete key for cube deletion
    if (event.code === 'Delete' && this.state.selectedCubeId) {
      if (this.onCubeDeleteCallback) {
        this.onCubeDeleteCallback(this.state.selectedCubeId)
      }
    }

    // Prevent default behavior for keys we handle
    if (event.code === 'KeyR' || event.code === 'Delete') {
      event.preventDefault()
    }
  }

  private handleKeyUp(event: KeyboardEvent): void {
    this.state.pressedKeys.delete(event.code)

    // If R key is released during rotation, end rotation
    if (event.code === 'KeyR' && this.state.isRotating) {
      this.endRotation()
    }
  }

  private startDrag(cubeId: string, screenPosition: Vector2): void {
    this.state.isDragging = true
    
    if (this.onDragStartCallback) {
      this.onDragStartCallback(cubeId, screenPosition)
    }
  }

  private endDrag(): void {
    this.state.isDragging = false
    
    if (this.onDragEndCallback) {
      this.onDragEndCallback()
    }
  }

  private startRotation(cubeId: string, screenPosition: Vector2): void {
    this.state.isRotating = true
    
    if (this.onRotateStartCallback) {
      this.onRotateStartCallback(cubeId, screenPosition)
    }
  }

  private endRotation(): void {
    this.state.isRotating = false
    
    if (this.onRotateEndCallback) {
      this.onRotateEndCallback()
    }
  }

  // Public callback setters
  setOnCubeClick(callback: (cubeId: string | null, screenPosition: Vector2) => void): void {
    this.onCubeClickCallback = callback
  }

  setOnCubeDelete(callback: (cubeId: string) => void): void {
    this.onCubeDeleteCallback = callback
  }

  setOnDragStart(callback: (cubeId: string, screenPosition: Vector2) => void): void {
    this.onDragStartCallback = callback
  }

  setOnDragUpdate(callback: (screenPosition: Vector2) => void): void {
    this.onDragUpdateCallback = callback
  }

  setOnDragEnd(callback: () => void): void {
    this.onDragEndCallback = callback
  }

  setOnRotateStart(callback: (cubeId: string, screenPosition: Vector2) => void): void {
    this.onRotateStartCallback = callback
  }

  setOnRotateUpdate(callback: (screenPosition: Vector2) => void): void {
    this.onRotateUpdateCallback = callback
  }

  setOnRotateEnd(callback: () => void): void {
    this.onRotateEndCallback = callback
  }

  // State queries
  isKeyPressed(key: string): boolean {
    return this.state.pressedKeys.has(key)
  }

  getState(): InteractionState {
    return { ...this.state }
  }

  destroy(): void {
    if (this.container) {
      // Remove mouse events
      this.container.removeEventListener('mousedown', this.handleMouseDown.bind(this))
      this.container.removeEventListener('mousemove', this.handleMouseMove.bind(this))
      this.container.removeEventListener('mouseup', this.handleMouseUp.bind(this))
      this.container.removeEventListener('contextmenu', this.handleContextMenu.bind(this))
      this.container.removeEventListener('dragstart', (e) => e.preventDefault())
    }

    // Remove keyboard events
    document.removeEventListener('keydown', this.handleKeyDown.bind(this))
    document.removeEventListener('keyup', this.handleKeyUp.bind(this))

    // Clear state
    this.state.pressedKeys.clear()
    this.container = null
    this.renderEngine = null
  }
}