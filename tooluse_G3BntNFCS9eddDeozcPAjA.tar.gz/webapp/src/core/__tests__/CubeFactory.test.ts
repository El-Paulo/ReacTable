import { Vector3 } from 'three'
import { CubeFactory } from '../CubeFactory'
import { CubeType, CubeInstance, AudioParams } from '@/types'

describe('CubeFactory', () => {
  describe('createCube', () => {
    it('should create a valid oscillator cube', () => {
      const position = new Vector3(1, 0, 1)
      const cube = CubeFactory.createCube(CubeType.OSCILLATOR, position)

      expect(cube.id).toBeDefined()
      expect(cube.id).toContain('oscillator')
      expect(cube.type).toBe(CubeType.OSCILLATOR)
      expect(cube.transform.position).toEqual(position)
      expect(cube.transform.rotation).toEqual(new Vector3(0, 0, 0))
      expect(cube.transform.scale).toEqual(new Vector3(1, 1, 1))
      expect(cube.audioNodeId).toBeDefined()
      expect(cube.audioNodeId).toContain('audio_')
      expect(cube.isActive).toBe(false)
      expect(cube.parameters).toEqual({ frequency: 440, detune: 0, type: 0 })
    })

    it('should create a valid filter cube', () => {
      const position = new Vector3(2, 0, 2)
      const cube = CubeFactory.createCube(CubeType.FILTER, position)

      expect(cube.type).toBe(CubeType.FILTER)
      expect(cube.parameters).toEqual({ cutoff: 1000, resonance: 1, type: 0 })
    })

    it('should create a valid gain cube', () => {
      const position = new Vector3(3, 0, 3)
      const cube = CubeFactory.createCube(CubeType.GAIN, position)

      expect(cube.type).toBe(CubeType.GAIN)
      expect(cube.parameters).toEqual({ gain: 0.5 })
    })

    it('should create a valid output cube', () => {
      const position = new Vector3(4, 0, 4)
      const cube = CubeFactory.createCube(CubeType.OUTPUT, position)

      expect(cube.type).toBe(CubeType.OUTPUT)
      expect(cube.parameters).toEqual({})
    })

    it('should create cubes with unique IDs', () => {
      const position = new Vector3(0, 0, 0)
      const cube1 = CubeFactory.createCube(CubeType.OSCILLATOR, position)
      const cube2 = CubeFactory.createCube(CubeType.OSCILLATOR, position)

      expect(cube1.id).not.toBe(cube2.id)
      expect(cube1.audioNodeId).not.toBe(cube2.audioNodeId)
    })

    it('should clone the position vector', () => {
      const position = new Vector3(5, 0, 5)
      const cube = CubeFactory.createCube(CubeType.OSCILLATOR, position)

      position.x = 10
      expect(cube.transform.position.x).toBe(5)
    })
  })

  describe('getCubeTypeDefinition', () => {
    it('should return correct definition for oscillator', () => {
      const definition = CubeFactory.getCubeTypeDefinition(CubeType.OSCILLATOR)

      expect(definition.type).toBe(CubeType.OSCILLATOR)
      expect(definition.name).toBe('Oscillator')
      expect(definition.color).toBe('#ff6b6b')
      expect(definition.canConnect.input).toBe(false)
      expect(definition.canConnect.output).toBe(true)
      expect(definition.parameters).toHaveLength(2)
    })

    it('should throw error for invalid cube type', () => {
      expect(() => {
        CubeFactory.getCubeTypeDefinition('invalid' as CubeType)
      }).toThrow('Unknown cube type: invalid')
    })
  })

  describe('validateCubeParameters', () => {
    it('should validate oscillator parameters correctly', () => {
      const validParams = { frequency: 440, detune: 0 }
      expect(CubeFactory.validateCubeParameters(CubeType.OSCILLATOR, validParams)).toBe(true)
    })

    it('should throw error for parameters outside range', () => {
      const invalidParams = { frequency: 10 } // Below minimum of 20
      expect(() => {
        CubeFactory.validateCubeParameters(CubeType.OSCILLATOR, invalidParams)
      }).toThrow('Parameter frequency value 10 is outside valid range [20, 2000]')
    })

    it('should throw error for non-number parameters', () => {
      const invalidParams = { frequency: 'invalid' as any }
      expect(() => {
        CubeFactory.validateCubeParameters(CubeType.OSCILLATOR, invalidParams)
      }).toThrow('Parameter frequency must be a number, got string')
    })

    it('should allow undefined parameters', () => {
      const partialParams = { frequency: 440 } // detune is undefined
      expect(CubeFactory.validateCubeParameters(CubeType.OSCILLATOR, partialParams)).toBe(true)
    })

    it('should validate filter parameters', () => {
      const validParams = { cutoff: 1000, resonance: 5 }
      expect(CubeFactory.validateCubeParameters(CubeType.FILTER, validParams)).toBe(true)

      const invalidParams = { cutoff: 50000 } // Above maximum
      expect(() => {
        CubeFactory.validateCubeParameters(CubeType.FILTER, invalidParams)
      }).toThrow('Parameter cutoff value 50000 is outside valid range [20, 20000]')
    })

    it('should validate gain parameters', () => {
      const validParams = { gain: 1.5 }
      expect(CubeFactory.validateCubeParameters(CubeType.GAIN, validParams)).toBe(true)

      const invalidParams = { gain: -0.5 } // Below minimum
      expect(() => {
        CubeFactory.validateCubeParameters(CubeType.GAIN, invalidParams)
      }).toThrow('Parameter gain value -0.5 is outside valid range [0, 2]')
    })
  })

  describe('createDefaultParameters', () => {
    it('should create default parameters for oscillator', () => {
      const params = CubeFactory.createDefaultParameters(CubeType.OSCILLATOR)
      expect(params).toEqual({ frequency: 440, detune: 0, type: 0 })
    })

    it('should create default parameters for filter', () => {
      const params = CubeFactory.createDefaultParameters(CubeType.FILTER)
      expect(params).toEqual({ cutoff: 1000, resonance: 1, type: 0 })
    })

    it('should create default parameters for gain', () => {
      const params = CubeFactory.createDefaultParameters(CubeType.GAIN)
      expect(params).toEqual({ gain: 0.5 })
    })

    it('should create default parameters for output', () => {
      const params = CubeFactory.createDefaultParameters(CubeType.OUTPUT)
      expect(params).toEqual({})
    })
  })

  describe('updateCubeParameters', () => {
    it('should update cube parameters with validation', () => {
      const cube = CubeFactory.createCube(CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      const newParams = CubeFactory.updateCubeParameters(cube, { frequency: 880 })

      expect(newParams).toEqual({ frequency: 880, detune: 0, type: 0 })
    })

    it('should throw error for invalid parameter updates', () => {
      const cube = CubeFactory.createCube(CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      
      expect(() => {
        CubeFactory.updateCubeParameters(cube, { frequency: 5000 }) // Above max
      }).toThrow('Parameter frequency value 5000 is outside valid range [20, 2000]')
    })

    it('should preserve existing parameters when updating', () => {
      const cube = CubeFactory.createCube(CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      const newParams = CubeFactory.updateCubeParameters(cube, { detune: 50 })

      expect(newParams).toEqual({ frequency: 440, detune: 50, type: 0 })
    })
  })

  describe('connection capabilities', () => {
    it('should correctly identify input capabilities', () => {
      expect(CubeFactory.canAcceptInput(CubeType.OSCILLATOR)).toBe(false)
      expect(CubeFactory.canAcceptInput(CubeType.FILTER)).toBe(true)
      expect(CubeFactory.canAcceptInput(CubeType.GAIN)).toBe(true)
      expect(CubeFactory.canAcceptInput(CubeType.OUTPUT)).toBe(true)
    })

    it('should correctly identify output capabilities', () => {
      expect(CubeFactory.canProvideOutput(CubeType.OSCILLATOR)).toBe(true)
      expect(CubeFactory.canProvideOutput(CubeType.FILTER)).toBe(true)
      expect(CubeFactory.canProvideOutput(CubeType.GAIN)).toBe(true)
      expect(CubeFactory.canProvideOutput(CubeType.OUTPUT)).toBe(false)
    })
  })

  describe('getCubeColor', () => {
    it('should return correct colors for each cube type', () => {
      expect(CubeFactory.getCubeColor(CubeType.OSCILLATOR)).toBe('#ff6b6b')
      expect(CubeFactory.getCubeColor(CubeType.FILTER)).toBe('#4ecdc4')
      expect(CubeFactory.getCubeColor(CubeType.GAIN)).toBe('#45b7d1')
      expect(CubeFactory.getCubeColor(CubeType.OUTPUT)).toBe('#f9ca24')
    })
  })

  describe('getAllCubeTypes', () => {
    it('should return all available cube types', () => {
      const types = CubeFactory.getAllCubeTypes()
      expect(types).toContain(CubeType.OSCILLATOR)
      expect(types).toContain(CubeType.FILTER)
      expect(types).toContain(CubeType.GAIN)
      expect(types).toContain(CubeType.OUTPUT)
      expect(types).toHaveLength(4)
    })
  })

  describe('getAllCubeTypeDefinitions', () => {
    it('should return all cube type definitions', () => {
      const definitions = CubeFactory.getAllCubeTypeDefinitions()
      expect(Object.keys(definitions)).toHaveLength(4)
      expect(definitions[CubeType.OSCILLATOR]).toBeDefined()
      expect(definitions[CubeType.FILTER]).toBeDefined()
      expect(definitions[CubeType.GAIN]).toBeDefined()
      expect(definitions[CubeType.OUTPUT]).toBeDefined()
    })
  })

  describe('cloneCube', () => {
    it('should clone a cube with new ID and position', () => {
      const originalCube = CubeFactory.createCube(CubeType.OSCILLATOR, new Vector3(1, 0, 1))
      originalCube.transform.rotation.set(0.5, 0.5, 0.5)
      originalCube.transform.scale.set(2, 2, 2)
      originalCube.parameters.frequency = 880

      const newPosition = new Vector3(5, 0, 5)
      const clonedCube = CubeFactory.cloneCube(originalCube, newPosition)

      expect(clonedCube.id).not.toBe(originalCube.id)
      expect(clonedCube.audioNodeId).not.toBe(originalCube.audioNodeId)
      expect(clonedCube.type).toBe(originalCube.type)
      expect(clonedCube.transform.position).toEqual(newPosition)
      expect(clonedCube.transform.rotation).toEqual(originalCube.transform.rotation)
      expect(clonedCube.transform.scale).toEqual(originalCube.transform.scale)
      expect(clonedCube.parameters).toEqual(originalCube.parameters)
      expect(clonedCube.isActive).toBe(false)
    })

    it('should not affect original cube when modifying clone', () => {
      const originalCube = CubeFactory.createCube(CubeType.OSCILLATOR, new Vector3(1, 0, 1))
      const clonedCube = CubeFactory.cloneCube(originalCube, new Vector3(5, 0, 5))

      clonedCube.parameters.frequency = 880
      clonedCube.transform.rotation.x = 1

      expect(originalCube.parameters.frequency).toBe(440)
      expect(originalCube.transform.rotation.x).toBe(0)
    })
  })

  describe('validation edge cases', () => {
    it('should throw error for cube with invalid ID', () => {
      expect(() => {
        const cube = CubeFactory.createCube(CubeType.OSCILLATOR, new Vector3(0, 0, 0))
        cube.id = ''
        CubeFactory['validateCube'](cube)
      }).toThrow('Cube must have a valid string ID')
    })

    it('should throw error for cube with invalid type', () => {
      expect(() => {
        const cube = CubeFactory.createCube(CubeType.OSCILLATOR, new Vector3(0, 0, 0))
        cube.type = 'invalid' as CubeType
        CubeFactory['validateCube'](cube)
      }).toThrow('Invalid cube type: invalid')
    })

    it('should throw error for cube with missing transform', () => {
      expect(() => {
        const cube = CubeFactory.createCube(CubeType.OSCILLATOR, new Vector3(0, 0, 0))
        cube.transform = null as any
        CubeFactory['validateCube'](cube)
      }).toThrow('Cube must have valid transform with position, rotation, and scale')
    })

    it('should throw error for cube with invalid audio node ID', () => {
      expect(() => {
        const cube = CubeFactory.createCube(CubeType.OSCILLATOR, new Vector3(0, 0, 0))
        cube.audioNodeId = ''
        CubeFactory['validateCube'](cube)
      }).toThrow('Cube must have a valid audio node ID')
    })

    it('should throw error for cube with invalid isActive', () => {
      expect(() => {
        const cube = CubeFactory.createCube(CubeType.OSCILLATOR, new Vector3(0, 0, 0))
        cube.isActive = 'true' as any
        CubeFactory['validateCube'](cube)
      }).toThrow('Cube isActive must be a boolean')
    })

    it('should throw error for cube with invalid parameters', () => {
      expect(() => {
        const cube = CubeFactory.createCube(CubeType.OSCILLATOR, new Vector3(0, 0, 0))
        cube.parameters = null as any
        CubeFactory['validateCube'](cube)
      }).toThrow('Cube must have valid parameters object')
    })
  })
})