import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest'
import { Vector2 } from 'three'
import { InteractionManagerImpl } from '../InteractionManagerImpl'
import { RenderEngine } from '@/interfaces/RenderEngine'
import { CubeType } from '@/types'

// Mock RenderEngine
const mockRenderEngine: Partial<RenderEngine> = {
  raycast: vi.fn(),
  clearSelection: vi.fn(),
  startDragCube: vi.fn(),
  updateDragCube: vi.fn(),
  endDragCube: vi.fn(),
  startRotateCube: vi.fn(),
  updateRotateCube: vi.fn(),
  endRotateCube: vi.fn(),
  isDragging: vi.fn().mockReturnValue(false),
  isRotating: vi.fn().mockReturnValue(false)
}

// Mock DOM elements
const mockContainer = {
  addEventListener: vi.fn(),
  removeEventListener: vi.fn(),
  getBoundingClientRect: vi.fn().mockReturnValue({
    left: 0,
    top: 0,
    width: 800,
    height: 600
  })
} as unknown as HTMLElement

describe('InteractionManagerImpl', () => {
  let interactionManager: InteractionManagerImpl
  let onCubeClickSpy: ReturnType<typeof vi.fn>
  let onCubeDeleteSpy: ReturnType<typeof vi.fn>
  let onDragStartSpy: ReturnType<typeof vi.fn>
  let onDragUpdateSpy: ReturnType<typeof vi.fn>
  let onDragEndSpy: ReturnType<typeof vi.fn>
  let onRotateStartSpy: ReturnType<typeof vi.fn>
  let onRotateUpdateSpy: ReturnType<typeof vi.fn>
  let onRotateEndSpy: ReturnType<typeof vi.fn>

  beforeEach(() => {
    // Reset mock container
    vi.clearAllMocks()
    
    interactionManager = new InteractionManagerImpl()
    
    // Set up spies
    onCubeClickSpy = vi.fn()
    onCubeDeleteSpy = vi.fn()
    onDragStartSpy = vi.fn()
    onDragUpdateSpy = vi.fn()
    onDragEndSpy = vi.fn()
    onRotateStartSpy = vi.fn()
    onRotateUpdateSpy = vi.fn()
    onRotateEndSpy = vi.fn()

    // Set up callbacks
    interactionManager.setOnCubeClick(onCubeClickSpy)
    interactionManager.setOnCubeDelete(onCubeDeleteSpy)
    interactionManager.setOnDragStart(onDragStartSpy)
    interactionManager.setOnDragUpdate(onDragUpdateSpy)
    interactionManager.setOnDragEnd(onDragEndSpy)
    interactionManager.setOnRotateStart(onRotateStartSpy)
    interactionManager.setOnRotateUpdate(onRotateUpdateSpy)
    interactionManager.setOnRotateEnd(onRotateEndSpy)

    // Initialize with mock container
    interactionManager.initialize(mockContainer)
    interactionManager.setRenderEngine(mockRenderEngine as RenderEngine)
  })

  afterEach(() => {
    interactionManager.destroy()
  })

  describe('initialization', () => {
    it('should set up event listeners on container', () => {
      expect(mockContainer.addEventListener).toHaveBeenCalledWith('mousedown', expect.any(Function))
      expect(mockContainer.addEventListener).toHaveBeenCalledWith('mousemove', expect.any(Function))
      expect(mockContainer.addEventListener).toHaveBeenCalledWith('mouseup', expect.any(Function))
      expect(mockContainer.addEventListener).toHaveBeenCalledWith('contextmenu', expect.any(Function))
      expect(mockContainer.addEventListener).toHaveBeenCalledWith('dragstart', expect.any(Function))
    })

    it('should have initial state', () => {
      const state = interactionManager.getState()
      expect(state.isMouseDown).toBe(false)
      expect(state.isDragging).toBe(false)
      expect(state.isRotating).toBe(false)
      expect(state.pressedKeys.size).toBe(0)
      expect(state.selectedCubeId).toBe(null)
    })
  })

  describe('callback system', () => {
    it('should call cube click callback when set', () => {
      const cubeId = 'test-cube-1'
      const screenPosition = new Vector2(100, 100)
      
      // Directly test the callback system
      if (interactionManager['onCubeClickCallback']) {
        interactionManager['onCubeClickCallback'](cubeId, screenPosition)
      }

      expect(onCubeClickSpy).toHaveBeenCalledWith(cubeId, screenPosition)
    })

    it('should call cube delete callback when set', () => {
      const cubeId = 'test-cube-1'
      
      // Directly test the callback system
      if (interactionManager['onCubeDeleteCallback']) {
        interactionManager['onCubeDeleteCallback'](cubeId)
      }

      expect(onCubeDeleteSpy).toHaveBeenCalledWith(cubeId)
    })
  })

  describe('drag operations', () => {
    it('should call drag start callback', () => {
      const cubeId = 'test-cube-1'
      const screenPosition = new Vector2(100, 100)
      
      // Directly test the callback system
      if (interactionManager['onDragStartCallback']) {
        interactionManager['onDragStartCallback'](cubeId, screenPosition)
      }

      expect(onDragStartSpy).toHaveBeenCalledWith(cubeId, screenPosition)
    })

    it('should call drag update callback', () => {
      const screenPosition = new Vector2(150, 120)
      
      // Directly test the callback system
      if (interactionManager['onDragUpdateCallback']) {
        interactionManager['onDragUpdateCallback'](screenPosition)
      }

      expect(onDragUpdateSpy).toHaveBeenCalledWith(screenPosition)
    })

    it('should call drag end callback', () => {
      // Directly test the callback system
      if (interactionManager['onDragEndCallback']) {
        interactionManager['onDragEndCallback']()
      }

      expect(onDragEndSpy).toHaveBeenCalled()
    })
  })

  describe('rotation operations', () => {
    it('should call rotation start callback', () => {
      const cubeId = 'test-cube-1'
      const screenPosition = new Vector2(100, 100)
      
      // Directly test the callback system
      if (interactionManager['onRotateStartCallback']) {
        interactionManager['onRotateStartCallback'](cubeId, screenPosition)
      }

      expect(onRotateStartSpy).toHaveBeenCalledWith(cubeId, screenPosition)
    })

    it('should call rotation update callback', () => {
      const screenPosition = new Vector2(150, 120)
      
      // Directly test the callback system
      if (interactionManager['onRotateUpdateCallback']) {
        interactionManager['onRotateUpdateCallback'](screenPosition)
      }

      expect(onRotateUpdateSpy).toHaveBeenCalledWith(screenPosition)
    })

    it('should call rotation end callback', () => {
      // Directly test the callback system
      if (interactionManager['onRotateEndCallback']) {
        interactionManager['onRotateEndCallback']()
      }

      expect(onRotateEndSpy).toHaveBeenCalled()
    })
  })

  describe('state management', () => {
    it('should track state correctly', () => {
      const state = interactionManager.getState()
      
      expect(state.isMouseDown).toBe(false)
      expect(state.isDragging).toBe(false)
      expect(state.isRotating).toBe(false)
      expect(state.selectedCubeId).toBe(null)
    })

    it('should allow state modification', () => {
      const state = interactionManager.getState()
      
      // Modify state (this would normally be done by internal methods)
      state.selectedCubeId = 'test-cube'
      state.isDragging = true
      
      expect(state.selectedCubeId).toBe('test-cube')
      expect(state.isDragging).toBe(true)
    })
  })

  describe('key state management', () => {
    it('should track pressed keys initially as false', () => {
      expect(interactionManager.isKeyPressed('KeyR')).toBe(false)
      expect(interactionManager.isKeyPressed('Delete')).toBe(false)
    })

    it('should provide key state query method', () => {
      // Test that the method exists and returns boolean
      const result = interactionManager.isKeyPressed('KeyR')
      expect(typeof result).toBe('boolean')
    })
  })

  describe('cleanup', () => {
    it('should remove event listeners on destroy', () => {
      interactionManager.destroy()

      expect(mockContainer.removeEventListener).toHaveBeenCalledWith('mousedown', expect.any(Function))
      expect(mockContainer.removeEventListener).toHaveBeenCalledWith('mousemove', expect.any(Function))
      expect(mockContainer.removeEventListener).toHaveBeenCalledWith('mouseup', expect.any(Function))
      expect(mockContainer.removeEventListener).toHaveBeenCalledWith('contextmenu', expect.any(Function))
    })

    it('should clear state on destroy', () => {
      // Add some keys to state
      const keyDownEvent = new KeyboardEvent('keydown', { code: 'KeyR' })
      document.dispatchEvent(keyDownEvent)

      expect(interactionManager.isKeyPressed('KeyR')).toBe(true)

      interactionManager.destroy()

      expect(interactionManager.getState().pressedKeys.size).toBe(0)
    })
  })
})