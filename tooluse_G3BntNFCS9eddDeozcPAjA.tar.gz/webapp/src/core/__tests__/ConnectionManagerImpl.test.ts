import { Vector3 } from 'three'
import { vi } from 'vitest'
import { ConnectionManagerImpl } from '../ConnectionManagerImpl'
import { CubeInstance, CubeType, Connection } from '@/types'

// Helper function to create test cube instances
const createTestCube = (
  id: string,
  type: CubeType,
  position: Vector3,
  isActive: boolean = true
): CubeInstance => ({
  id,
  type,
  transform: {
    position: position.clone(),
    rotation: new Vector3(),
    scale: new Vector3(1, 1, 1)
  },
  audioNodeId: `audio-${id}`,
  isActive,
  parameters: {}
})

describe('ConnectionManagerImpl', () => {
  let connectionManager: ConnectionManagerImpl
  let mockConnectionCreatedCallback: ReturnType<typeof vi.fn>
  let mockConnectionRemovedCallback: ReturnType<typeof vi.fn>

  beforeEach(() => {
    connectionManager = new ConnectionManagerImpl()
    mockConnectionCreatedCallback = vi.fn()
    mockConnectionRemovedCallback = vi.fn()
    
    connectionManager.onConnectionCreated(mockConnectionCreatedCallback)
    connectionManager.onConnectionRemoved(mockConnectionRemovedCallback)
  })

  describe('Proximity Detection', () => {
    it('should detect cubes within proximity threshold', () => {
      const cube1 = createTestCube('cube1', CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      const cube2 = createTestCube('cube2', CubeType.FILTER, new Vector3(1.5, 0, 0))
      
      expect(connectionManager.checkProximity(cube1, cube2)).toBe(true)
    })

    it('should not detect cubes outside proximity threshold', () => {
      const cube1 = createTestCube('cube1', CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      const cube2 = createTestCube('cube2', CubeType.FILTER, new Vector3(3, 0, 0))
      
      expect(connectionManager.checkProximity(cube1, cube2)).toBe(false)
    })

    it('should detect cubes exactly at proximity threshold', () => {
      const cube1 = createTestCube('cube1', CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      const cube2 = createTestCube('cube2', CubeType.FILTER, new Vector3(2, 0, 0))
      
      expect(connectionManager.checkProximity(cube1, cube2)).toBe(true)
    })

    it('should work with 3D distances', () => {
      const cube1 = createTestCube('cube1', CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      const cube2 = createTestCube('cube2', CubeType.FILTER, new Vector3(1, 1, 1))
      
      const distance = Math.sqrt(3) // ~1.73
      expect(distance).toBeLessThan(2.0)
      expect(connectionManager.checkProximity(cube1, cube2)).toBe(true)
    })
  })

  describe('Connection Creation and Removal', () => {
    it('should create connection between two cubes', () => {
      const connection = connectionManager.createConnection('cube1', 'cube2')
      
      expect(connection).toEqual({
        id: 'cube1->cube2',
        fromCubeId: 'cube1',
        toCubeId: 'cube2',
        strength: 1.0,
        isActive: true
      })
      
      expect(mockConnectionCreatedCallback).toHaveBeenCalledWith(connection)
    })

    it('should not create duplicate connections', () => {
      const connection1 = connectionManager.createConnection('cube1', 'cube2')
      const connection2 = connectionManager.createConnection('cube1', 'cube2')
      
      expect(connection1).toBe(connection2)
      expect(mockConnectionCreatedCallback).toHaveBeenCalledTimes(1)
    })

    it('should remove connection by ID', () => {
      const connection = connectionManager.createConnection('cube1', 'cube2')
      connectionManager.removeConnection(connection.id)
      
      expect(connectionManager.getConnections()).toHaveLength(0)
      expect(mockConnectionRemovedCallback).toHaveBeenCalledWith(connection.id)
    })

    it('should handle removing non-existent connection gracefully', () => {
      connectionManager.removeConnection('non-existent')
      
      expect(mockConnectionRemovedCallback).not.toHaveBeenCalled()
    })
  })

  describe('Automatic Connection Updates', () => {
    it('should create connection when cubes come into proximity', () => {
      const cube1 = createTestCube('cube1', CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      const cube2 = createTestCube('cube2', CubeType.FILTER, new Vector3(1.5, 0, 0))
      
      connectionManager.updateConnections([cube1, cube2])
      
      const connections = connectionManager.getConnections()
      expect(connections).toHaveLength(1)
      expect(connections[0].fromCubeId).toBe('cube1')
      expect(connections[0].toCubeId).toBe('cube2')
      expect(mockConnectionCreatedCallback).toHaveBeenCalledTimes(1)
    })

    it('should remove connection when cubes move apart', () => {
      const cube1 = createTestCube('cube1', CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      const cube2 = createTestCube('cube2', CubeType.FILTER, new Vector3(1.5, 0, 0))
      
      // First update - create connection
      connectionManager.updateConnections([cube1, cube2])
      expect(connectionManager.getConnections()).toHaveLength(1)
      
      // Move cube2 away
      cube2.transform.position.set(5, 0, 0)
      
      // Second update - remove connection
      connectionManager.updateConnections([cube1, cube2])
      expect(connectionManager.getConnections()).toHaveLength(0)
      expect(mockConnectionRemovedCallback).toHaveBeenCalledTimes(1)
    })

    it('should update connection strength based on distance', () => {
      const cube1 = createTestCube('cube1', CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      const cube2 = createTestCube('cube2', CubeType.FILTER, new Vector3(1, 0, 0))
      
      connectionManager.updateConnections([cube1, cube2])
      
      const connections = connectionManager.getConnections()
      expect(connections).toHaveLength(1)
      
      const expectedStrength = connectionManager.calculateConnectionStrength(cube1, cube2)
      expect(connections[0].strength).toBe(expectedStrength)
      expect(connections[0].strength).toBeGreaterThan(0.5) // Close distance should have high strength
    })

    it('should not create connections between inactive cubes', () => {
      const cube1 = createTestCube('cube1', CubeType.OSCILLATOR, new Vector3(0, 0, 0), false)
      const cube2 = createTestCube('cube2', CubeType.FILTER, new Vector3(1.5, 0, 0))
      
      connectionManager.updateConnections([cube1, cube2])
      
      expect(connectionManager.getConnections()).toHaveLength(0)
      expect(mockConnectionCreatedCallback).not.toHaveBeenCalled()
    })

    it('should remove connections when cube becomes inactive', () => {
      const cube1 = createTestCube('cube1', CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      const cube2 = createTestCube('cube2', CubeType.FILTER, new Vector3(1.5, 0, 0))
      
      // Create connection
      connectionManager.updateConnections([cube1, cube2])
      expect(connectionManager.getConnections()).toHaveLength(1)
      
      // Deactivate cube1
      cube1.isActive = false
      
      // Update should remove connection
      connectionManager.updateConnections([cube1, cube2])
      expect(connectionManager.getConnections()).toHaveLength(0)
      expect(mockConnectionRemovedCallback).toHaveBeenCalledTimes(1)
    })
  })

  describe('Connection Direction Logic', () => {
    it('should connect oscillator to filter', () => {
      const oscillator = createTestCube('osc', CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      const filter = createTestCube('filter', CubeType.FILTER, new Vector3(1, 0, 0))
      
      connectionManager.updateConnections([oscillator, filter])
      
      const connections = connectionManager.getConnections()
      expect(connections).toHaveLength(1)
      expect(connections[0].fromCubeId).toBe('osc')
      expect(connections[0].toCubeId).toBe('filter')
    })

    it('should connect filter to gain', () => {
      const filter = createTestCube('filter', CubeType.FILTER, new Vector3(0, 0, 0))
      const gain = createTestCube('gain', CubeType.GAIN, new Vector3(1, 0, 0))
      
      connectionManager.updateConnections([filter, gain])
      
      const connections = connectionManager.getConnections()
      expect(connections).toHaveLength(1)
      expect(connections[0].fromCubeId).toBe('filter')
      expect(connections[0].toCubeId).toBe('gain')
    })

    it('should connect gain to output', () => {
      const gain = createTestCube('gain', CubeType.GAIN, new Vector3(0, 0, 0))
      const output = createTestCube('output', CubeType.OUTPUT, new Vector3(1, 0, 0))
      
      connectionManager.updateConnections([gain, output])
      
      const connections = connectionManager.getConnections()
      expect(connections).toHaveLength(1)
      expect(connections[0].fromCubeId).toBe('gain')
      expect(connections[0].toCubeId).toBe('output')
    })

    it('should not connect output to anything', () => {
      const output1 = createTestCube('output1', CubeType.OUTPUT, new Vector3(0, 0, 0))
      const output2 = createTestCube('output2', CubeType.OUTPUT, new Vector3(1, 0, 0))
      
      connectionManager.updateConnections([output1, output2])
      
      expect(connectionManager.getConnections()).toHaveLength(0)
    })

    it('should connect oscillator to filter when in proximity', () => {
      const filter = createTestCube('filter', CubeType.FILTER, new Vector3(0, 0, 0))
      const oscillator = createTestCube('osc', CubeType.OSCILLATOR, new Vector3(1, 0, 0))
      
      connectionManager.updateConnections([filter, oscillator])
      
      const connections = connectionManager.getConnections()
      expect(connections).toHaveLength(1)
      expect(connections[0].fromCubeId).toBe('osc')
      expect(connections[0].toCubeId).toBe('filter')
    })

    it('should not allow connections TO oscillator', () => {
      const oscillator1 = createTestCube('osc1', CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      const oscillator2 = createTestCube('osc2', CubeType.OSCILLATOR, new Vector3(1, 0, 0))
      
      connectionManager.updateConnections([oscillator1, oscillator2])
      
      expect(connectionManager.getConnections()).toHaveLength(0)
    })
  })

  describe('Connection Strength Calculation', () => {
    it('should return maximum strength at zero distance', () => {
      const cube1 = createTestCube('cube1', CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      const cube2 = createTestCube('cube2', CubeType.FILTER, new Vector3(0, 0, 0))
      
      const strength = connectionManager.calculateConnectionStrength(cube1, cube2)
      expect(strength).toBe(1.0)
    })

    it('should return zero strength beyond threshold', () => {
      const cube1 = createTestCube('cube1', CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      const cube2 = createTestCube('cube2', CubeType.FILTER, new Vector3(3, 0, 0))
      
      const strength = connectionManager.calculateConnectionStrength(cube1, cube2)
      expect(strength).toBe(0)
    })

    it('should return intermediate strength at mid-distance', () => {
      const cube1 = createTestCube('cube1', CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      const cube2 = createTestCube('cube2', CubeType.FILTER, new Vector3(1, 0, 0))
      
      const strength = connectionManager.calculateConnectionStrength(cube1, cube2)
      expect(strength).toBeGreaterThan(0)
      expect(strength).toBeLessThan(1.0)
      expect(strength).toBeCloseTo(0.75, 2) // 1 - (1/2) * 0.5 = 0.75
    })
  })

  describe('Connection Queries', () => {
    beforeEach(() => {
      connectionManager.createConnection('cube1', 'cube2')
      connectionManager.createConnection('cube2', 'cube3')
      connectionManager.createConnection('cube4', 'cube2')
    })

    it('should get all connections for a cube', () => {
      const connections = connectionManager.getConnectionsForCube('cube2')
      expect(connections).toHaveLength(3)
    })

    it('should get input connections for a cube', () => {
      const inputConnections = connectionManager.getInputConnections('cube2')
      expect(inputConnections).toHaveLength(2)
      expect(inputConnections.every(conn => conn.toCubeId === 'cube2')).toBe(true)
    })

    it('should get output connections for a cube', () => {
      const outputConnections = connectionManager.getOutputConnections('cube2')
      expect(outputConnections).toHaveLength(1)
      expect(outputConnections[0].fromCubeId).toBe('cube2')
      expect(outputConnections[0].toCubeId).toBe('cube3')
    })

    it('should return empty arrays for cube with no connections', () => {
      expect(connectionManager.getConnectionsForCube('nonexistent')).toHaveLength(0)
      expect(connectionManager.getInputConnections('nonexistent')).toHaveLength(0)
      expect(connectionManager.getOutputConnections('nonexistent')).toHaveLength(0)
    })
  })

  describe('Clear Functionality', () => {
    it('should clear all connections', () => {
      connectionManager.createConnection('cube1', 'cube2')
      connectionManager.createConnection('cube2', 'cube3')
      
      expect(connectionManager.getConnections()).toHaveLength(2)
      
      connectionManager.clear()
      
      expect(connectionManager.getConnections()).toHaveLength(0)
      expect(mockConnectionRemovedCallback).toHaveBeenCalledTimes(2)
    })
  })

  describe('Cycle Detection and Validation', () => {
    it('should detect simple cycles', () => {
      const connections: Connection[] = [
        { id: '1', fromCubeId: 'A', toCubeId: 'B', strength: 1, isActive: true },
        { id: '2', fromCubeId: 'B', toCubeId: 'C', strength: 1, isActive: true },
        { id: '3', fromCubeId: 'C', toCubeId: 'A', strength: 1, isActive: true }
      ]
      
      expect(connectionManager.detectCycles(connections)).toBe(true)
    })

    it('should not detect cycles in valid chains', () => {
      const connections: Connection[] = [
        { id: '1', fromCubeId: 'A', toCubeId: 'B', strength: 1, isActive: true },
        { id: '2', fromCubeId: 'B', toCubeId: 'C', strength: 1, isActive: true },
        { id: '3', fromCubeId: 'C', toCubeId: 'D', strength: 1, isActive: true }
      ]
      
      expect(connectionManager.detectCycles(connections)).toBe(false)
    })

    it('should detect self-loops', () => {
      const connections: Connection[] = [
        { id: '1', fromCubeId: 'A', toCubeId: 'A', strength: 1, isActive: true }
      ]
      
      expect(connectionManager.detectCycles(connections)).toBe(true)
    })

    it('should prevent connection that would create cycle', () => {
      // Create a chain: A -> B -> C
      connectionManager.createConnection('A', 'B')
      connectionManager.createConnection('B', 'C')
      
      // Try to create C -> A (would create cycle)
      expect(connectionManager.validateConnection('C', 'A')).toBe(false)
    })

    it('should allow connection that does not create cycle', () => {
      // Create a chain: A -> B -> C
      connectionManager.createConnection('A', 'B')
      connectionManager.createConnection('B', 'C')
      
      // Try to create D -> A (no cycle)
      expect(connectionManager.validateConnection('D', 'A')).toBe(true)
    })

    it('should prevent self-connections', () => {
      expect(connectionManager.validateConnection('A', 'A')).toBe(false)
    })

    it('should detect complex cycles', () => {
      const connections: Connection[] = [
        { id: '1', fromCubeId: 'A', toCubeId: 'B', strength: 1, isActive: true },
        { id: '2', fromCubeId: 'B', toCubeId: 'C', strength: 1, isActive: true },
        { id: '3', fromCubeId: 'C', toCubeId: 'D', strength: 1, isActive: true },
        { id: '4', fromCubeId: 'D', toCubeId: 'E', strength: 1, isActive: true },
        { id: '5', fromCubeId: 'E', toCubeId: 'B', strength: 1, isActive: true } // Creates cycle B->C->D->E->B
      ]
      
      expect(connectionManager.detectCycles(connections)).toBe(true)
    })

    it('should handle disconnected components without false positives', () => {
      const connections: Connection[] = [
        // Component 1: A -> B -> C
        { id: '1', fromCubeId: 'A', toCubeId: 'B', strength: 1, isActive: true },
        { id: '2', fromCubeId: 'B', toCubeId: 'C', strength: 1, isActive: true },
        // Component 2: D -> E -> F
        { id: '3', fromCubeId: 'D', toCubeId: 'E', strength: 1, isActive: true },
        { id: '4', fromCubeId: 'E', toCubeId: 'F', strength: 1, isActive: true }
      ]
      
      expect(connectionManager.detectCycles(connections)).toBe(false)
    })
  })

  describe('Connection Type Validation', () => {
    it('should validate valid connection types', () => {
      // Valid connections
      expect(connectionManager.validateConnectionTypes(CubeType.OSCILLATOR, CubeType.FILTER)).toBe(true)
      expect(connectionManager.validateConnectionTypes(CubeType.OSCILLATOR, CubeType.GAIN)).toBe(true)
      expect(connectionManager.validateConnectionTypes(CubeType.OSCILLATOR, CubeType.OUTPUT)).toBe(true)
      expect(connectionManager.validateConnectionTypes(CubeType.FILTER, CubeType.GAIN)).toBe(true)
      expect(connectionManager.validateConnectionTypes(CubeType.FILTER, CubeType.OUTPUT)).toBe(true)
      expect(connectionManager.validateConnectionTypes(CubeType.GAIN, CubeType.OUTPUT)).toBe(true)
    })

    it('should reject invalid connection types', () => {
      // Invalid connections
      expect(connectionManager.validateConnectionTypes(CubeType.OUTPUT, CubeType.OSCILLATOR)).toBe(false)
      expect(connectionManager.validateConnectionTypes(CubeType.OUTPUT, CubeType.FILTER)).toBe(false)
      expect(connectionManager.validateConnectionTypes(CubeType.OUTPUT, CubeType.GAIN)).toBe(false)
      expect(connectionManager.validateConnectionTypes(CubeType.OUTPUT, CubeType.OUTPUT)).toBe(false)
    })

    it('should allow filter to filter connections', () => {
      expect(connectionManager.validateConnectionTypes(CubeType.FILTER, CubeType.FILTER)).toBe(true)
    })

    it('should allow gain to gain connections', () => {
      expect(connectionManager.validateConnectionTypes(CubeType.GAIN, CubeType.GAIN)).toBe(true)
    })

    it('should prevent invalid type connections during automatic updates', () => {
      const output1 = createTestCube('output1', CubeType.OUTPUT, new Vector3(0, 0, 0))
      const output2 = createTestCube('output2', CubeType.OUTPUT, new Vector3(1, 0, 0))
      
      connectionManager.updateConnections([output1, output2])
      
      // Should not create any connections between outputs
      expect(connectionManager.getConnections()).toHaveLength(0)
    })
  })

  describe('Visual Warning System', () => {
    it('should trigger warning for self-connection attempts', () => {
      const mockWarningCallback = vi.fn()
      connectionManager.onInvalidConnectionAttempt(mockWarningCallback)
      
      connectionManager.validateConnection('cube1', 'cube1')
      
      expect(mockWarningCallback).toHaveBeenCalledWith('cube1', 'cube1', 'Self-connections are not allowed')
    })

    it('should trigger warning for cycle-creating connections', () => {
      const mockWarningCallback = vi.fn()
      connectionManager.onInvalidConnectionAttempt(mockWarningCallback)
      
      // Create a chain: A -> B -> C
      connectionManager.createConnection('A', 'B')
      connectionManager.createConnection('B', 'C')
      
      // Try to create C -> A (would create cycle)
      connectionManager.validateConnection('C', 'A')
      
      expect(mockWarningCallback).toHaveBeenCalledWith('C', 'A', 'Connection would create an audio feedback loop')
    })

    it('should trigger warning for incompatible cube types', () => {
      const mockWarningCallback = vi.fn()
      connectionManager.onInvalidConnectionAttempt(mockWarningCallback)
      
      // Two output cubes - neither can connect to the other
      const output1 = createTestCube('output1', CubeType.OUTPUT, new Vector3(0, 0, 0))
      const output2 = createTestCube('output2', CubeType.OUTPUT, new Vector3(1, 0, 0))
      
      connectionManager.updateConnections([output1, output2])
      
      expect(mockWarningCallback).toHaveBeenCalledWith(
        expect.any(String),
        expect.any(String),
        expect.stringContaining('Cannot connect')
      )
    })
  })

  describe('Multiple Cube Scenarios', () => {
    it('should handle complex multi-cube proximity scenarios', () => {
      const oscillator = createTestCube('osc', CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      const filter1 = createTestCube('filter1', CubeType.FILTER, new Vector3(1.5, 0, 0))
      const filter2 = createTestCube('filter2', CubeType.FILTER, new Vector3(0, 1.5, 0))
      const gain = createTestCube('gain', CubeType.GAIN, new Vector3(1.5, 1.5, 0))
      const output = createTestCube('output', CubeType.OUTPUT, new Vector3(3, 0, 0))
      
      connectionManager.updateConnections([oscillator, filter1, filter2, gain, output])
      
      const connections = connectionManager.getConnections()
      
      // Should have connections: osc->filter1, osc->filter2, filter1->gain, filter2->gain
      expect(connections.length).toBeGreaterThan(0)
      
      // Verify oscillator connects to both filters
      const oscConnections = connectionManager.getOutputConnections('osc')
      expect(oscConnections).toHaveLength(2)
      expect(oscConnections.some(conn => conn.toCubeId === 'filter1')).toBe(true)
      expect(oscConnections.some(conn => conn.toCubeId === 'filter2')).toBe(true)
    })

    it('should update connections when cubes move dynamically', () => {
      const cube1 = createTestCube('cube1', CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      const cube2 = createTestCube('cube2', CubeType.FILTER, new Vector3(5, 0, 0)) // Far away
      const cube3 = createTestCube('cube3', CubeType.GAIN, new Vector3(1, 0, 0)) // Close to cube1
      
      // Initial state - only cube1 and cube3 should connect
      connectionManager.updateConnections([cube1, cube2, cube3])
      expect(connectionManager.getConnections()).toHaveLength(1)
      expect(connectionManager.getConnections()[0].fromCubeId).toBe('cube1')
      expect(connectionManager.getConnections()[0].toCubeId).toBe('cube3')
      
      // Move cube2 close to cube3
      cube2.transform.position.set(1.5, 0, 0)
      
      connectionManager.updateConnections([cube1, cube2, cube3])
      
      // Now should have cube1->cube3 and cube3->cube2 (gain->filter not allowed, so cube2->cube3)
      const connections = connectionManager.getConnections()
      expect(connections.length).toBeGreaterThanOrEqual(1)
    })
  })
})