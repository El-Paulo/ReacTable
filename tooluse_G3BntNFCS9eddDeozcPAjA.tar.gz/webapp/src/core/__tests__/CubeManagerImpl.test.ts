import { Vector3 } from 'three'
import { vi } from 'vitest'
import { CubeManagerImpl } from '../CubeManagerImpl'
import { CubeType, CubeInstance } from '@/types'

describe('CubeManagerImpl', () => {
  let cubeManager: CubeManagerImpl

  beforeEach(() => {
    cubeManager = new CubeManagerImpl()
  })

  describe('cube lifecycle', () => {
    it('should create a cube successfully', () => {
      const position = new Vector3(1, 0, 1)
      const cube = cubeManager.createCube(CubeType.OSCILLATOR, position)

      expect(cube).toBeDefined()
      expect(cube.type).toBe(CubeType.OSCILLATOR)
      expect(cube.transform.position).toEqual(position)
      expect(cubeManager.getCube(cube.id)).toBe(cube)
      expect(cubeManager.getCubeCount()).toBe(1)
    })

    it('should call onCreate callback when cube is created', () => {
      const onCreated = vi.fn()
      cubeManager.setOnCubeCreated(onCreated)

      const cube = cubeManager.createCube(CubeType.OSCILLATOR, new Vector3(0, 0, 0))

      expect(onCreated).toHaveBeenCalledWith(cube)
    })

    it('should destroy a cube successfully', () => {
      const cube = cubeManager.createCube(CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      const cubeId = cube.id

      cubeManager.destroyCube(cubeId)

      expect(cubeManager.getCube(cubeId)).toBeNull()
      expect(cubeManager.getCubeCount()).toBe(0)
    })

    it('should call onDestroy callback when cube is destroyed', () => {
      const onDestroyed = vi.fn()
      cubeManager.setOnCubeDestroyed(onDestroyed)

      const cube = cubeManager.createCube(CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      cubeManager.destroyCube(cube.id)

      expect(onDestroyed).toHaveBeenCalledWith(cube.id)
    })

    it('should throw error when destroying non-existent cube', () => {
      expect(() => {
        cubeManager.destroyCube('non-existent-id')
      }).toThrow('Cube with ID non-existent-id not found')
    })

    it('should deactivate cube before destroying if active', () => {
      const cube = cubeManager.createCube(CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      cubeManager.activateCube(cube.id)
      
      expect(cubeManager.isActive(cube.id)).toBe(true)
      
      cubeManager.destroyCube(cube.id)
      // Should not throw error and cube should be destroyed
      expect(cubeManager.getCube(cube.id)).toBeNull()
    })

    it('should deselect cube before destroying if selected', () => {
      const cube = cubeManager.createCube(CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      cubeManager.selectCube(cube.id)
      
      expect(cubeManager.getSelectedCube()).toBe(cube)
      
      cubeManager.destroyCube(cube.id)
      expect(cubeManager.getSelectedCube()).toBeNull()
    })
  })

  describe('cube retrieval', () => {
    it('should get cube by ID', () => {
      const cube = cubeManager.createCube(CubeType.FILTER, new Vector3(2, 0, 2))
      const retrieved = cubeManager.getCube(cube.id)

      expect(retrieved).toBe(cube)
    })

    it('should return null for non-existent cube', () => {
      const retrieved = cubeManager.getCube('non-existent-id')
      expect(retrieved).toBeNull()
    })

    it('should get all cubes', () => {
      const cube1 = cubeManager.createCube(CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      const cube2 = cubeManager.createCube(CubeType.FILTER, new Vector3(1, 0, 1))
      
      const allCubes = cubeManager.getAllCubes()
      expect(allCubes).toHaveLength(2)
      expect(allCubes).toContain(cube1)
      expect(allCubes).toContain(cube2)
    })

    it('should get cubes by type', () => {
      const osc1 = cubeManager.createCube(CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      const osc2 = cubeManager.createCube(CubeType.OSCILLATOR, new Vector3(1, 0, 1))
      const filter = cubeManager.createCube(CubeType.FILTER, new Vector3(2, 0, 2))

      const oscillators = cubeManager.getCubesByType(CubeType.OSCILLATOR)
      expect(oscillators).toHaveLength(2)
      expect(oscillators).toContain(osc1)
      expect(oscillators).toContain(osc2)
      expect(oscillators).not.toContain(filter)
    })
  })

  describe('cube manipulation', () => {
    let cube: CubeInstance

    beforeEach(() => {
      cube = cubeManager.createCube(CubeType.OSCILLATOR, new Vector3(0, 0, 0))
    })

    it('should move cube to new position', () => {
      const newPosition = new Vector3(5, 0, 5)
      cubeManager.moveCube(cube.id, newPosition)

      expect(cube.transform.position).toEqual(newPosition)
    })

    it('should rotate cube and update audio parameters', () => {
      const onStateChange = vi.fn()
      cubeManager.setOnCubeStateChange(onStateChange)

      const newRotation = new Vector3(0, Math.PI / 4, 0)
      cubeManager.rotateCube(cube.id, newRotation)

      expect(cube.transform.rotation).toEqual(newRotation)
      expect(onStateChange).toHaveBeenCalledWith(cube.id, cube)
      
      // Check that audio parameters were updated based on rotation
      expect(cube.parameters.frequency).not.toBe(440) // Should be different from default
    })

    it('should scale cube', () => {
      const newScale = new Vector3(2, 2, 2)
      cubeManager.scaleCube(cube.id, newScale)

      expect(cube.transform.scale).toEqual(newScale)
    })

    it('should throw error when manipulating non-existent cube', () => {
      expect(() => {
        cubeManager.moveCube('non-existent', new Vector3(0, 0, 0))
      }).toThrow('Cube with ID non-existent not found')

      expect(() => {
        cubeManager.rotateCube('non-existent', new Vector3(0, 0, 0))
      }).toThrow('Cube with ID non-existent not found')

      expect(() => {
        cubeManager.scaleCube('non-existent', new Vector3(1, 1, 1))
      }).toThrow('Cube with ID non-existent not found')
    })
  })

  describe('parameter mapping', () => {
    it('should map oscillator rotation to frequency and detune', () => {
      const cube = cubeManager.createCube(CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      
      // Set rotation that should map to specific frequency
      cube.transform.rotation.set(0, Math.PI / 2, 0) // 90 degrees Y rotation
      
      const audioParams = cubeManager.mapTransformToAudio(cube)
      
      expect(audioParams.frequency).toBeDefined()
      expect(audioParams.frequency).toBeGreaterThan(20)
      expect(audioParams.frequency).toBeLessThan(2000)
      expect(audioParams.detune).toBeDefined()
    })

    it('should map filter rotation to cutoff and resonance', () => {
      const cube = cubeManager.createCube(CubeType.FILTER, new Vector3(0, 0, 0))
      
      cube.transform.rotation.set(Math.PI / 4, Math.PI / 4, 0)
      
      const audioParams = cubeManager.mapTransformToAudio(cube)
      
      expect(audioParams.cutoff).toBeDefined()
      expect(audioParams.cutoff).toBeGreaterThan(20)
      expect(audioParams.cutoff).toBeLessThan(20000)
      expect(audioParams.resonance).toBeDefined()
    })

    it('should map gain rotation to gain parameter', () => {
      const cube = cubeManager.createCube(CubeType.GAIN, new Vector3(0, 0, 0))
      
      cube.transform.rotation.set(0, Math.PI, 0) // 180 degrees
      
      const audioParams = cubeManager.mapTransformToAudio(cube)
      
      expect(audioParams.gain).toBeDefined()
      expect(audioParams.gain).toBeGreaterThanOrEqual(0)
      expect(audioParams.gain).toBeLessThanOrEqual(2)
    })

    it('should handle output cube with no parameters', () => {
      const cube = cubeManager.createCube(CubeType.OUTPUT, new Vector3(0, 0, 0))
      
      const audioParams = cubeManager.mapTransformToAudio(cube)
      
      expect(Object.keys(audioParams)).toHaveLength(0)
    })

    it('should use logarithmic scaling for frequency parameters', () => {
      const cube = cubeManager.createCube(CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      
      // Test different rotations
      cube.transform.rotation.set(0, 0, 0) // Should give frequency near minimum
      const params1 = cubeManager.mapTransformToAudio(cube)
      
      cube.transform.rotation.set(0, Math.PI * 2, 0) // Should give frequency near maximum
      const params2 = cubeManager.mapTransformToAudio(cube)
      
      expect(params1.frequency).toBeLessThan(params2.frequency)
      expect(params1.frequency).toBeGreaterThan(0)
      expect(params2.frequency).toBeLessThan(2000)
    })
  })

  describe('cube selection', () => {
    let cube1: CubeInstance
    let cube2: CubeInstance

    beforeEach(() => {
      cube1 = cubeManager.createCube(CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      cube2 = cubeManager.createCube(CubeType.FILTER, new Vector3(1, 0, 1))
    })

    it('should select a cube', () => {
      cubeManager.selectCube(cube1.id)
      
      expect(cubeManager.getSelectedCube()).toBe(cube1)
      expect(cubeManager.isSelected(cube1.id)).toBe(true)
      expect(cubeManager.isSelected(cube2.id)).toBe(false)
    })

    it('should deselect current cube when selecting another', () => {
      cubeManager.selectCube(cube1.id)
      cubeManager.selectCube(cube2.id)
      
      expect(cubeManager.getSelectedCube()).toBe(cube2)
      expect(cubeManager.isSelected(cube1.id)).toBe(false)
      expect(cubeManager.isSelected(cube2.id)).toBe(true)
    })

    it('should deselect cube', () => {
      cubeManager.selectCube(cube1.id)
      cubeManager.deselectCube()
      
      expect(cubeManager.getSelectedCube()).toBeNull()
      expect(cubeManager.isSelected(cube1.id)).toBe(false)
    })

    it('should throw error when selecting non-existent cube', () => {
      expect(() => {
        cubeManager.selectCube('non-existent')
      }).toThrow('Cube with ID non-existent not found')
    })

    it('should handle deselect when no cube is selected', () => {
      expect(() => {
        cubeManager.deselectCube()
      }).not.toThrow()
      
      expect(cubeManager.getSelectedCube()).toBeNull()
    })
  })

  describe('cube activation', () => {
    let cube: CubeInstance

    beforeEach(() => {
      cube = cubeManager.createCube(CubeType.OSCILLATOR, new Vector3(0, 0, 0))
    })

    it('should activate cube', () => {
      expect(cube.isActive).toBe(false)
      
      cubeManager.activateCube(cube.id)
      
      expect(cube.isActive).toBe(true)
      expect(cubeManager.isActive(cube.id)).toBe(true)
    })

    it('should deactivate cube', () => {
      cubeManager.activateCube(cube.id)
      expect(cube.isActive).toBe(true)
      
      cubeManager.deactivateCube(cube.id)
      
      expect(cube.isActive).toBe(false)
      expect(cubeManager.isActive(cube.id)).toBe(false)
    })

    it('should get active cubes', () => {
      const cube2 = cubeManager.createCube(CubeType.FILTER, new Vector3(1, 0, 1))
      
      cubeManager.activateCube(cube.id)
      
      const activeCubes = cubeManager.getActiveCubes()
      expect(activeCubes).toHaveLength(1)
      expect(activeCubes).toContain(cube)
      expect(activeCubes).not.toContain(cube2)
      
      expect(cubeManager.getActiveCubeCount()).toBe(1)
    })

    it('should not change state if already active/inactive', () => {
      const onStateChange = vi.fn()
      cubeManager.setOnCubeStateChange(onStateChange)
      
      // Activate already inactive cube
      cubeManager.activateCube(cube.id)
      expect(onStateChange).toHaveBeenCalledTimes(1)
      
      // Try to activate again
      cubeManager.activateCube(cube.id)
      expect(onStateChange).toHaveBeenCalledTimes(1) // Should not be called again
      
      // Deactivate
      cubeManager.deactivateCube(cube.id)
      expect(onStateChange).toHaveBeenCalledTimes(2)
      
      // Try to deactivate again
      cubeManager.deactivateCube(cube.id)
      expect(onStateChange).toHaveBeenCalledTimes(2) // Should not be called again
    })

    it('should throw error when activating/deactivating non-existent cube', () => {
      expect(() => {
        cubeManager.activateCube('non-existent')
      }).toThrow('Cube with ID non-existent not found')

      expect(() => {
        cubeManager.deactivateCube('non-existent')
      }).toThrow('Cube with ID non-existent not found')
    })
  })

  describe('batch operations', () => {
    let cube: CubeInstance

    beforeEach(() => {
      cube = cubeManager.createCube(CubeType.OSCILLATOR, new Vector3(0, 0, 0))
    })

    it('should update cube parameters', () => {
      const newParams = { frequency: 880 }
      cubeManager.updateCubeParameters(cube.id, newParams)

      expect(cube.parameters.frequency).toBe(880)
      expect(cube.parameters.detune).toBe(0) // Should preserve existing
    })

    it('should update cube transform', () => {
      const newTransform = {
        position: new Vector3(5, 0, 5),
        rotation: new Vector3(0, Math.PI / 2, 0)
      }
      
      cubeManager.updateCubeTransform(cube.id, newTransform)

      expect(cube.transform.position).toEqual(newTransform.position)
      expect(cube.transform.rotation).toEqual(newTransform.rotation)
      // Audio parameters should be updated due to rotation change
      expect(cube.parameters.frequency).not.toBe(440)
    })

    it('should throw error when updating non-existent cube', () => {
      expect(() => {
        cubeManager.updateCubeParameters('non-existent', { frequency: 880 })
      }).toThrow('Cube with ID non-existent not found')

      expect(() => {
        cubeManager.updateCubeTransform('non-existent', { position: new Vector3(0, 0, 0) })
      }).toThrow('Cube with ID non-existent not found')
    })
  })

  describe('utility methods', () => {
    it('should get cube count', () => {
      expect(cubeManager.getCubeCount()).toBe(0)
      
      cubeManager.createCube(CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      expect(cubeManager.getCubeCount()).toBe(1)
      
      cubeManager.createCube(CubeType.FILTER, new Vector3(1, 0, 1))
      expect(cubeManager.getCubeCount()).toBe(2)
    })

    it('should clear all cubes', () => {
      const onDestroyed = vi.fn()
      cubeManager.setOnCubeDestroyed(onDestroyed)
      
      const cube1 = cubeManager.createCube(CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      const cube2 = cubeManager.createCube(CubeType.FILTER, new Vector3(1, 0, 1))
      cubeManager.selectCube(cube1.id)
      
      cubeManager.clear()
      
      expect(cubeManager.getCubeCount()).toBe(0)
      expect(cubeManager.getSelectedCube()).toBeNull()
      expect(onDestroyed).toHaveBeenCalledTimes(2)
    })

    it('should clone cube', () => {
      const originalCube = cubeManager.createCube(CubeType.OSCILLATOR, new Vector3(1, 0, 1))
      originalCube.transform.rotation.set(0.5, 0.5, 0.5)
      originalCube.parameters.frequency = 880

      const newPosition = new Vector3(5, 0, 5)
      const clonedCube = cubeManager.cloneCube(originalCube.id, newPosition)

      expect(clonedCube.id).not.toBe(originalCube.id)
      expect(clonedCube.type).toBe(originalCube.type)
      expect(clonedCube.transform.position).toEqual(newPosition)
      expect(clonedCube.transform.rotation).toEqual(originalCube.transform.rotation)
      expect(clonedCube.parameters.frequency).toBe(880)
      expect(cubeManager.getCubeCount()).toBe(2)
    })

    it('should throw error when cloning non-existent cube', () => {
      expect(() => {
        cubeManager.cloneCube('non-existent', new Vector3(0, 0, 0))
      }).toThrow('Source cube with ID non-existent not found')
    })
  })

  describe('state change notifications', () => {
    it('should notify on state changes', () => {
      const onStateChange = vi.fn()
      cubeManager.setOnCubeStateChange(onStateChange)

      const cube = cubeManager.createCube(CubeType.OSCILLATOR, new Vector3(0, 0, 0))
      
      // Clear previous calls from creation
      onStateChange.mockClear()
      
      cubeManager.moveCube(cube.id, new Vector3(1, 0, 1))
      expect(onStateChange).toHaveBeenCalledWith(cube.id, cube)
      
      cubeManager.rotateCube(cube.id, new Vector3(0, Math.PI / 4, 0))
      expect(onStateChange).toHaveBeenCalledWith(cube.id, cube)
      
      cubeManager.selectCube(cube.id)
      expect(onStateChange).toHaveBeenCalledWith(cube.id, cube)
    })
  })
})