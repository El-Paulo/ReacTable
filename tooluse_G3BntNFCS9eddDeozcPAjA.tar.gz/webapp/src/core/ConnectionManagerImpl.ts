import { Vector3 } from 'three'
import { ConnectionManager } from '@/interfaces/ConnectionManager'
import { CubeInstance, Connection, CubeType } from '@/types'

export class ConnectionManagerImpl implements ConnectionManager {
  private connections: Map<string, Connection> = new Map()
  private connectionCreatedCallbacks: ((connection: Connection) => void)[] = []
  private connectionRemovedCallbacks: ((connectionId: string) => void)[] = []
  private invalidConnectionCallbacks: ((fromId: string, toId: string, reason: string) => void)[] = []
  
  // Configuration constants
  private readonly PROXIMITY_THRESHOLD = 2.0 // Distance threshold for automatic connections
  private readonly CONNECTION_STRENGTH_FALLOFF = 0.5 // How quickly connection strength decreases with distance
  
  constructor() {
    // Initialize empty connection manager
  }

  /**
   * Updates all connections based on current cube positions
   * This is the main method called each frame to maintain automatic connections
   */
  updateConnections(cubes: CubeInstance[]): void {
    const activeCubes = cubes.filter(cube => cube.isActive)
    
    // Check all pairs of cubes for proximity-based connections
    for (let i = 0; i < activeCubes.length; i++) {
      for (let j = i + 1; j < activeCubes.length; j++) {
        const cube1 = activeCubes[i]
        const cube2 = activeCubes[j]
        
        this.updateConnectionBetweenCubes(cube1, cube2)
      }
    }
    
    // Remove connections for inactive cubes
    this.removeInactiveConnections(cubes)
  }

  /**
   * Checks if two cubes are within proximity threshold
   */
  checkProximity(cube1: CubeInstance, cube2: CubeInstance): boolean {
    const distance = cube1.transform.position.distanceTo(cube2.transform.position)
    return distance <= this.PROXIMITY_THRESHOLD
  }

  /**
   * Creates a new connection between two cubes
   */
  createConnection(fromId: string, toId: string): Connection {
    const connectionId = this.generateConnectionId(fromId, toId)
    
    // Check if connection already exists
    if (this.connections.has(connectionId)) {
      return this.connections.get(connectionId)!
    }
    
    const connection: Connection = {
      id: connectionId,
      fromCubeId: fromId,
      toCubeId: toId,
      strength: 1.0,
      isActive: true
    }
    
    this.connections.set(connectionId, connection)
    
    // Notify listeners
    this.connectionCreatedCallbacks.forEach(callback => callback(connection))
    
    return connection
  }

  /**
   * Removes a connection by ID
   */
  removeConnection(connectionId: string): void {
    if (this.connections.has(connectionId)) {
      this.connections.delete(connectionId)
      
      // Notify listeners
      this.connectionRemovedCallbacks.forEach(callback => callback(connectionId))
    }
  }

  /**
   * Gets all current connections
   */
  getConnections(): Connection[] {
    return Array.from(this.connections.values())
  }

  /**
   * Validates if a connection between two cubes is allowed
   */
  validateConnection(fromId: string, toId: string): boolean {
    // Prevent self-connections
    if (fromId === toId) {
      this.notifyInvalidConnection(fromId, toId, 'Self-connections are not allowed')
      return false
    }
    
    // Check if connection would create a cycle
    const tempConnections = [...this.getConnections()]
    tempConnections.push({
      id: 'temp',
      fromCubeId: fromId,
      toCubeId: toId,
      strength: 1.0,
      isActive: true
    })
    
    if (this.detectCycles(tempConnections)) {
      this.notifyInvalidConnection(fromId, toId, 'Connection would create an audio feedback loop')
      return false
    }
    
    return true
  }

  /**
   * Validates connection based on cube types
   */
  validateConnectionTypes(fromType: CubeType, toType: CubeType): boolean {
    // Define connection rules
    const connectionRules: Record<CubeType, CubeType[]> = {
      [CubeType.OSCILLATOR]: [CubeType.FILTER, CubeType.GAIN, CubeType.OUTPUT],
      [CubeType.FILTER]: [CubeType.FILTER, CubeType.GAIN, CubeType.OUTPUT],
      [CubeType.GAIN]: [CubeType.FILTER, CubeType.GAIN, CubeType.OUTPUT],
      [CubeType.OUTPUT]: [] // Output cubes cannot connect to anything
    }
    
    const allowedTargets = connectionRules[fromType] || []
    return allowedTargets.includes(toType)
  }

  /**
   * Detects cycles in the connection graph using DFS
   */
  detectCycles(connections: Connection[]): boolean {
    // Build adjacency list
    const graph = new Map<string, string[]>()
    const visited = new Set<string>()
    const recursionStack = new Set<string>()
    
    // Initialize graph
    connections.forEach(conn => {
      if (!graph.has(conn.fromCubeId)) {
        graph.set(conn.fromCubeId, [])
      }
      if (!graph.has(conn.toCubeId)) {
        graph.set(conn.toCubeId, [])
      }
      graph.get(conn.fromCubeId)!.push(conn.toCubeId)
    })
    
    // DFS cycle detection
    const hasCycleDFS = (node: string): boolean => {
      visited.add(node)
      recursionStack.add(node)
      
      const neighbors = graph.get(node) || []
      for (const neighbor of neighbors) {
        if (!visited.has(neighbor)) {
          if (hasCycleDFS(neighbor)) {
            return true
          }
        } else if (recursionStack.has(neighbor)) {
          return true
        }
      }
      
      recursionStack.delete(node)
      return false
    }
    
    // Check all nodes
    for (const node of graph.keys()) {
      if (!visited.has(node)) {
        if (hasCycleDFS(node)) {
          return true
        }
      }
    }
    
    return false
  }

  /**
   * Registers callback for connection creation events
   */
  onConnectionCreated(callback: (connection: Connection) => void): void {
    this.connectionCreatedCallbacks.push(callback)
  }

  /**
   * Registers callback for connection removal events
   */
  onConnectionRemoved(callback: (connectionId: string) => void): void {
    this.connectionRemovedCallbacks.push(callback)
  }

  /**
   * Registers callback for invalid connection attempts
   */
  onInvalidConnectionAttempt(callback: (fromId: string, toId: string, reason: string) => void): void {
    this.invalidConnectionCallbacks.push(callback)
  }

  /**
   * Gets connections for a specific cube
   */
  getConnectionsForCube(cubeId: string): Connection[] {
    return this.getConnections().filter(
      conn => conn.fromCubeId === cubeId || conn.toCubeId === cubeId
    )
  }

  /**
   * Gets input connections for a cube (connections where this cube is the target)
   */
  getInputConnections(cubeId: string): Connection[] {
    return this.getConnections().filter(conn => conn.toCubeId === cubeId)
  }

  /**
   * Gets output connections for a cube (connections where this cube is the source)
   */
  getOutputConnections(cubeId: string): Connection[] {
    return this.getConnections().filter(conn => conn.fromCubeId === cubeId)
  }

  /**
   * Calculates connection strength based on distance
   */
  calculateConnectionStrength(cube1: CubeInstance, cube2: CubeInstance): number {
    const distance = cube1.transform.position.distanceTo(cube2.transform.position)
    
    if (distance > this.PROXIMITY_THRESHOLD) {
      return 0
    }
    
    // Linear falloff from 1.0 at distance 0 to 0.0 at threshold
    const normalizedDistance = distance / this.PROXIMITY_THRESHOLD
    return Math.max(0, 1.0 - normalizedDistance * this.CONNECTION_STRENGTH_FALLOFF)
  }

  /**
   * Determines connection direction based on cube types
   */
  determineConnectionDirection(cube1: CubeInstance, cube2: CubeInstance): { from: string; to: string } | null {
    const getPriority = (type: CubeType): number => {
      switch (type) {
        case CubeType.OSCILLATOR: return 0
        case CubeType.FILTER: return 1
        case CubeType.GAIN: return 2
        case CubeType.OUTPUT: return 3
        default: return 1
      }
    }
    
    // Determine direction based on type priorities
    const priority1 = getPriority(cube1.type)
    const priority2 = getPriority(cube2.type)
    
    // Try cube1 -> cube2
    if (priority1 < priority2 && this.validateConnectionTypes(cube1.type, cube2.type)) {
      return { from: cube1.id, to: cube2.id }
    }
    
    // Try cube2 -> cube1
    if (priority2 < priority1 && this.validateConnectionTypes(cube2.type, cube1.type)) {
      return { from: cube2.id, to: cube1.id }
    }
    
    // If no valid direction found, notify about invalid connection attempt
    const reason = `Cannot connect ${cube1.type} to ${cube2.type}: incompatible types`
    this.notifyInvalidConnection(cube1.id, cube2.id, reason)
    
    return null // No valid connection direction
  }

  /**
   * Clears all connections
   */
  clear(): void {
    const connectionIds = Array.from(this.connections.keys())
    connectionIds.forEach(id => this.removeConnection(id))
  }

  // Private helper methods

  /**
   * Updates connection between two specific cubes
   */
  private updateConnectionBetweenCubes(cube1: CubeInstance, cube2: CubeInstance): void {
    const isInProximity = this.checkProximity(cube1, cube2)
    const connectionDirection = this.determineConnectionDirection(cube1, cube2)
    
    if (isInProximity && connectionDirection) {
      const { from, to } = connectionDirection
      
      // Validate connection before creating
      if (this.validateConnection(from, to)) {
        const connectionId = this.generateConnectionId(from, to)
        let connection = this.connections.get(connectionId)
        
        if (!connection) {
          // Create new connection
          connection = this.createConnection(from, to)
        }
        
        // Update connection strength based on distance
        const strength = this.calculateConnectionStrength(cube1, cube2)
        connection.strength = strength
        connection.isActive = strength > 0
      }
    } else {
      // Remove existing connection if cubes are no longer in proximity
      if (connectionDirection) {
        const { from, to } = connectionDirection
        const connectionId = this.generateConnectionId(from, to)
        this.removeConnection(connectionId)
      }
    }
  }

  /**
   * Removes connections involving inactive cubes
   */
  private removeInactiveConnections(cubes: CubeInstance[]): void {
    const activeCubeIds = new Set(cubes.filter(cube => cube.isActive).map(cube => cube.id))
    
    const connectionsToRemove: string[] = []
    
    this.connections.forEach((connection, connectionId) => {
      if (!activeCubeIds.has(connection.fromCubeId) || !activeCubeIds.has(connection.toCubeId)) {
        connectionsToRemove.push(connectionId)
      }
    })
    
    connectionsToRemove.forEach(id => this.removeConnection(id))
  }

  /**
   * Generates a unique connection ID from two cube IDs
   */
  private generateConnectionId(fromId: string, toId: string): string {
    return `${fromId}->${toId}`
  }

  /**
   * Notifies listeners about invalid connection attempts
   */
  private notifyInvalidConnection(fromId: string, toId: string, reason: string): void {
    this.invalidConnectionCallbacks.forEach(callback => callback(fromId, toId, reason))
  }
}