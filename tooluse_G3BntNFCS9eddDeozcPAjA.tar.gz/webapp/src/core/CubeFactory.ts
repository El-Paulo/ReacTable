import { Vector3 } from 'three'
import { CubeType, CubeInstance, CubeTypeDefinition, AudioParams, Transform3D } from '@/types'
import { CUBE_TYPES } from '@/config/cubeTypes'

export class CubeFactory {
  private static cubeCounter = 0

  /**
   * Creates a new cube instance of the specified type at the given position
   */
  static createCube(type: CubeType, position: Vector3): CubeInstance {
    const typeDefinition = this.getCubeTypeDefinition(type)
    const cubeId = this.generateCubeId(type)
    
    const cube: CubeInstance = {
      id: cubeId,
      type,
      transform: {
        position: position.clone(),
        rotation: new Vector3(0, 0, 0),
        scale: new Vector3(1, 1, 1)
      },
      audioNodeId: `audio_${cubeId}`,
      isActive: false,
      parameters: { ...typeDefinition.defaultValues }
    }

    // Validate the created cube
    this.validateCube(cube)
    
    return cube
  }

  /**
   * Gets the type definition for a specific cube type
   */
  static getCubeTypeDefinition(type: CubeType): CubeTypeDefinition {
    const definition = CUBE_TYPES[type]
    if (!definition) {
      throw new Error(`Unknown cube type: ${type}`)
    }
    return definition
  }

  /**
   * Validates cube parameters against type definition
   */
  static validateCubeParameters(type: CubeType, parameters: AudioParams): boolean {
    const typeDefinition = this.getCubeTypeDefinition(type)
    
    for (const paramDef of typeDefinition.parameters) {
      const value = parameters[paramDef.name]
      
      if (value !== undefined) {
        if (typeof value !== 'number') {
          throw new Error(`Parameter ${paramDef.name} must be a number, got ${typeof value}`)
        }
        
        if (value < paramDef.min || value > paramDef.max) {
          throw new Error(
            `Parameter ${paramDef.name} value ${value} is outside valid range [${paramDef.min}, ${paramDef.max}]`
          )
        }
      }
    }
    
    return true
  }

  /**
   * Creates default parameters for a cube type
   */
  static createDefaultParameters(type: CubeType): AudioParams {
    const typeDefinition = this.getCubeTypeDefinition(type)
    return { ...typeDefinition.defaultValues }
  }

  /**
   * Updates cube parameters with validation
   */
  static updateCubeParameters(cube: CubeInstance, newParameters: Partial<AudioParams>): AudioParams {
    const updatedParams: AudioParams = { ...cube.parameters }
    
    // Only add defined values from newParameters
    Object.entries(newParameters).forEach(([key, value]) => {
      if (value !== undefined) {
        updatedParams[key] = value
      }
    })
    
    // Validate the updated parameters
    this.validateCubeParameters(cube.type, updatedParams)
    
    return updatedParams
  }

  /**
   * Checks if a cube type can accept input connections
   */
  static canAcceptInput(type: CubeType): boolean {
    const typeDefinition = this.getCubeTypeDefinition(type)
    return typeDefinition.canConnect.input
  }

  /**
   * Checks if a cube type can provide output connections
   */
  static canProvideOutput(type: CubeType): boolean {
    const typeDefinition = this.getCubeTypeDefinition(type)
    return typeDefinition.canConnect.output
  }

  /**
   * Gets the color for a cube type
   */
  static getCubeColor(type: CubeType): string {
    const typeDefinition = this.getCubeTypeDefinition(type)
    return typeDefinition.color
  }

  /**
   * Gets all available cube types
   */
  static getAllCubeTypes(): CubeType[] {
    return Object.values(CubeType)
  }

  /**
   * Gets all cube type definitions
   */
  static getAllCubeTypeDefinitions(): Record<CubeType, CubeTypeDefinition> {
    return { ...CUBE_TYPES }
  }

  /**
   * Clones a cube instance with a new ID and position
   */
  static cloneCube(sourceCube: CubeInstance, newPosition: Vector3): CubeInstance {
    const clonedCube: CubeInstance = {
      id: this.generateCubeId(sourceCube.type),
      type: sourceCube.type,
      transform: {
        position: newPosition.clone(),
        rotation: sourceCube.transform.rotation.clone(),
        scale: sourceCube.transform.scale.clone()
      },
      audioNodeId: `audio_${this.generateCubeId(sourceCube.type)}`,
      isActive: false,
      parameters: { ...sourceCube.parameters }
    }

    this.validateCube(clonedCube)
    return clonedCube
  }

  /**
   * Generates a unique cube ID
   */
  private static generateCubeId(type: CubeType): string {
    this.cubeCounter++
    return `${type}_${this.cubeCounter}_${Date.now()}`
  }

  /**
   * Validates a complete cube instance
   */
  private static validateCube(cube: CubeInstance): void {
    if (!cube.id || typeof cube.id !== 'string') {
      throw new Error('Cube must have a valid string ID')
    }

    if (!Object.values(CubeType).includes(cube.type)) {
      throw new Error(`Invalid cube type: ${cube.type}`)
    }

    if (!cube.transform || !cube.transform.position || !cube.transform.rotation || !cube.transform.scale) {
      throw new Error('Cube must have valid transform with position, rotation, and scale')
    }

    if (!cube.audioNodeId || typeof cube.audioNodeId !== 'string') {
      throw new Error('Cube must have a valid audio node ID')
    }

    if (typeof cube.isActive !== 'boolean') {
      throw new Error('Cube isActive must be a boolean')
    }

    if (!cube.parameters || typeof cube.parameters !== 'object') {
      throw new Error('Cube must have valid parameters object')
    }

    // Validate parameters against type definition
    this.validateCubeParameters(cube.type, cube.parameters)
  }
}