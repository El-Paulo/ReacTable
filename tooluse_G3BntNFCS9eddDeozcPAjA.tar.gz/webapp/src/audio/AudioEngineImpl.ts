import { AudioEngine } from '@/interfaces/AudioEngine'
import { ErrorHandler } from '@/interfaces/ErrorHandler'
import { CubeType, AudioParams, ErrorType } from '@/types'

interface AudioNodeInfo {
  id: string
  type: CubeType
  node: AudioNode
  params: AudioParams
  connections: Set<string>
}

export interface RecordingState {
  isRecording: boolean
  isPaused: boolean
  duration: number
  maxDuration: number
}

export class AudioEngineImpl implements AudioEngine {
  private audioContext: AudioContext | null = null
  private audioNodes: Map<string, AudioNodeInfo> = new Map()
  private outputNode: GainNode | null = null
  private isInitialized = false
  private isStarted = false
  private nodeIdCounter = 0
  private mediaRecorder: MediaRecorder | null = null
  private recordingStream: MediaStreamAudioDestinationNode | null = null
  private recordingState: RecordingState = {
    isRecording: false,
    isPaused: false,
    duration: 0,
    maxDuration: 300 // 5 minutes default
  }
  private recordingStartTime = 0
  private recordingTimer: number | null = null
  private recordingChunks: BlobPart[] = []
  private errorHandler: ErrorHandler | null = null

  async initialize(errorHandler?: ErrorHandler): Promise<void> {
    if (this.isInitialized) {
      return
    }

    this.errorHandler = errorHandler || null

    try {
      // Check Web Audio API support
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext
      if (!AudioContextClass) {
        const error = new Error('Web Audio API not supported in this browser')
        this.errorHandler?.handleError(ErrorType.AUDIO_CONTEXT_FAILED, error)
        throw error
      }

      // Create audio context with optimal settings
      this.audioContext = new AudioContextClass({
        latencyHint: 'interactive',
        sampleRate: 44100
      })

      // Check if context creation succeeded
      if (!this.audioContext) {
        const error = new Error('Failed to create audio context')
        this.errorHandler?.handleError(ErrorType.AUDIO_CONTEXT_FAILED, error)
        throw error
      }

      // Create master output node
      this.outputNode = this.audioContext.createGain()
      this.outputNode.gain.value = 0.5 // Safe default volume
      this.outputNode.connect(this.audioContext.destination)

      // Set up recording stream
      this.recordingStream = this.audioContext.createMediaStreamDestination()
      this.outputNode.connect(this.recordingStream)

      this.isInitialized = true
      console.log('Audio engine initialized successfully')
    } catch (error) {
      this.errorHandler?.handleError(ErrorType.AUDIO_CONTEXT_FAILED, error)
      throw new Error(`Failed to initialize audio context: ${error}`)
    }
  }

  async start(): Promise<void> {
    if (!this.isInitialized) {
      const error = new Error('AudioEngine must be initialized before starting')
      this.errorHandler?.handleError(ErrorType.AUDIO_CONTEXT_FAILED, error)
      throw error
    }

    if (this.isStarted) {
      return
    }

    if (!this.audioContext) {
      const error = new Error('Audio context not available')
      this.errorHandler?.handleError(ErrorType.AUDIO_CONTEXT_FAILED, error)
      throw error
    }

    try {
      // Check if user interaction is required
      if (this.audioContext.state === 'suspended') {
        console.log('Audio context suspended - user interaction required')
        this.errorHandler?.handleError(ErrorType.AUDIO_PERMISSION_DENIED, {
          reason: 'User interaction required to start audio',
          state: this.audioContext.state
        })
        
        // Try to resume anyway
        await this.audioContext.resume()
      }

      // Verify audio context is running
      if (this.audioContext.state === 'closed') {
        const error = new Error(`Audio context failed to start, state: ${this.audioContext.state}`)
        this.errorHandler?.handleError(ErrorType.AUDIO_CONTEXT_FAILED, error)
        throw error
      }

      // Additional check for running state
      if (this.audioContext.state !== 'running') {
        console.warn(`Audio context in unexpected state: ${this.audioContext.state}`)
        // Don't throw error for suspended state as it might be recoverable
        if (this.audioContext.state !== 'suspended') {
          const error = new Error(`Audio context in invalid state: ${this.audioContext.state}`)
          this.errorHandler?.handleError(ErrorType.AUDIO_CONTEXT_FAILED, error)
          throw error
        }
      }

      this.isStarted = true
      console.log('Audio engine started successfully')
    } catch (error) {
      this.errorHandler?.handleError(ErrorType.AUDIO_CONTEXT_FAILED, error)
      throw new Error(`Failed to start audio context: ${error}`)
    }
  }

  stop(): void {
    if (!this.isStarted) {
      return
    }

    // Stop all audio nodes
    this.audioNodes.forEach(nodeInfo => {
      this.stopAudioNode(nodeInfo)
    })

    // Suspend audio context
    if (this.audioContext && this.audioContext.state !== 'closed') {
      this.audioContext.suspend()
    }

    this.isStarted = false
  }

  createAudioNode(type: CubeType, params: AudioParams): string {
    if (!this.isInitialized || !this.audioContext) {
      throw new Error('AudioEngine not initialized')
    }

    const nodeId = this.generateNodeId()
    let audioNode: AudioNode

    try {
      switch (type) {
        case CubeType.OSCILLATOR:
          audioNode = this.createOscillatorNode(params)
          break
        case CubeType.FILTER:
          audioNode = this.createFilterNode(params)
          break
        case CubeType.GAIN:
          audioNode = this.createGainNode(params)
          break
        case CubeType.OUTPUT:
          audioNode = this.createOutputNode(params)
          break
        default:
          throw new Error(`Unsupported cube type: ${type}`)
      }

      const nodeInfo: AudioNodeInfo = {
        id: nodeId,
        type,
        node: audioNode,
        params: { ...params },
        connections: new Set()
      }

      this.audioNodes.set(nodeId, nodeInfo)
      return nodeId
    } catch (error) {
      throw new Error(`Failed to create audio node of type ${type}: ${error}`)
    }
  }

  updateAudioNode(nodeId: string, params: AudioParams): void {
    const nodeInfo = this.audioNodes.get(nodeId)
    if (!nodeInfo) {
      throw new Error(`Audio node ${nodeId} not found`)
    }

    try {
      this.updateNodeParameters(nodeInfo, params)
      nodeInfo.params = { ...params }
    } catch (error) {
      throw new Error(`Failed to update audio node ${nodeId}: ${error}`)
    }
  }

  removeAudioNode(nodeId: string): void {
    const nodeInfo = this.audioNodes.get(nodeId)
    if (!nodeInfo) {
      return
    }

    try {
      // Disconnect all connections
      nodeInfo.connections.forEach(connectedId => {
        this.disconnectNodes(nodeId, connectedId)
      })

      // Stop and disconnect the node
      this.stopAudioNode(nodeInfo)
      nodeInfo.node.disconnect()

      this.audioNodes.delete(nodeId)
    } catch (error) {
      console.error(`Error removing audio node ${nodeId}:`, error)
    }
  }

  connectNodes(fromId: string, toId: string): void {
    const fromNode = this.audioNodes.get(fromId)
    const toNode = this.audioNodes.get(toId)

    if (!fromNode || !toNode) {
      throw new Error(`Cannot connect nodes: ${fromId} or ${toId} not found`)
    }

    try {
      // Validate connection is possible
      if (!this.canConnect(fromNode.type, toNode.type)) {
        throw new Error(`Cannot connect ${fromNode.type} to ${toNode.type}`)
      }

      // Make the connection
      fromNode.node.connect(toNode.node)
      fromNode.connections.add(toId)

      console.log(`Connected ${fromId} (${fromNode.type}) to ${toId} (${toNode.type})`)
    } catch (error) {
      throw new Error(`Failed to connect nodes ${fromId} to ${toId}: ${error}`)
    }
  }

  disconnectNodes(fromId: string, toId: string): void {
    const fromNode = this.audioNodes.get(fromId)
    const toNode = this.audioNodes.get(toId)

    if (!fromNode || !toNode) {
      return
    }

    try {
      fromNode.node.disconnect(toNode.node)
      fromNode.connections.delete(toId)
      console.log(`Disconnected ${fromId} from ${toId}`)
    } catch (error) {
      console.error(`Error disconnecting nodes ${fromId} from ${toId}:`, error)
    }
  }

  startRecording(maxDuration?: number): void {
    if (!this.recordingStream) {
      const error = new Error('Recording not available - audio engine not initialized')
      this.errorHandler?.handleError(ErrorType.RECORDING_NOT_SUPPORTED, error)
      throw error
    }

    if (this.recordingState.isRecording) {
      throw new Error('Recording already in progress')
    }

    // Check MediaRecorder support
    if (!window.MediaRecorder) {
      const error = new Error('MediaRecorder not supported in this browser')
      this.errorHandler?.handleError(ErrorType.RECORDING_NOT_SUPPORTED, error)
      throw error
    }

    try {
      const stream = this.recordingStream.stream
      
      // Try different MIME types for better browser compatibility
      let mimeType = 'audio/webm;codecs=opus'
      if (!MediaRecorder.isTypeSupported(mimeType)) {
        mimeType = 'audio/webm'
        if (!MediaRecorder.isTypeSupported(mimeType)) {
          mimeType = 'audio/mp4'
          if (!MediaRecorder.isTypeSupported(mimeType)) {
            mimeType = '' // Let browser choose
          }
        }
      }

      this.mediaRecorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined)
      this.recordingChunks = []

      // Set up event handlers
      this.mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          this.recordingChunks.push(event.data)
        }
      }

      this.mediaRecorder.onstop = () => {
        this.recordingState.isRecording = false
        this.recordingState.isPaused = false
        if (this.recordingTimer) {
          clearInterval(this.recordingTimer)
          this.recordingTimer = null
        }
      }

      this.mediaRecorder.onerror = (event) => {
        console.error('Recording error:', event)
        this.errorHandler?.handleError(ErrorType.RECORDING_NOT_SUPPORTED, {
          reason: 'MediaRecorder error during recording',
          event
        })
        this.recordingState.isRecording = false
        this.recordingState.isPaused = false
        if (this.recordingTimer) {
          clearInterval(this.recordingTimer)
          this.recordingTimer = null
        }
      }

      // Start recording
      this.mediaRecorder.start(1000) // Collect data every second
      this.recordingState.isRecording = true
      this.recordingState.isPaused = false
      this.recordingState.duration = 0
      this.recordingState.maxDuration = maxDuration || 300
      this.recordingStartTime = Date.now()

      // Start duration timer
      this.recordingTimer = window.setInterval(() => {
        if (this.recordingState.isRecording && !this.recordingState.isPaused) {
          this.recordingState.duration = (Date.now() - this.recordingStartTime) / 1000
          
          // Auto-stop if max duration reached
          if (this.recordingState.duration >= this.recordingState.maxDuration) {
            this.stopRecording()
          }
        }
      }, 100)

      console.log(`Recording started with MIME type: ${mimeType || 'auto'}`)
    } catch (error) {
      this.errorHandler?.handleError(ErrorType.RECORDING_NOT_SUPPORTED, error)
      throw new Error(`Failed to start recording: ${error}`)
    }
  }

  pauseRecording(): void {
    if (!this.mediaRecorder || !this.recordingState.isRecording) {
      throw new Error('No active recording to pause')
    }

    if (this.recordingState.isPaused) {
      // Resume recording
      this.mediaRecorder.resume()
      this.recordingState.isPaused = false
      this.recordingStartTime = Date.now() - (this.recordingState.duration * 1000)
      console.log('Recording resumed')
    } else {
      // Pause recording
      this.mediaRecorder.pause()
      this.recordingState.isPaused = true
      console.log('Recording paused')
    }
  }

  async stopRecording(): Promise<Blob> {
    if (!this.mediaRecorder || !this.recordingState.isRecording) {
      throw new Error('No active recording to stop')
    }

    return new Promise((resolve, reject) => {
      const timeoutId = setTimeout(() => {
        reject(new Error('Recording stop timeout'))
      }, 5000)

      this.mediaRecorder!.onstop = () => {
        clearTimeout(timeoutId)
        
        // Determine MIME type for blob
        let mimeType = 'audio/webm'
        if (this.recordingChunks.length > 0) {
          const firstChunk = this.recordingChunks[0] as Blob
          if (firstChunk.type) {
            mimeType = firstChunk.type
          }
        }

        const blob = new Blob(this.recordingChunks, { type: mimeType })
        this.recordingChunks = []
        
        console.log(`Recording stopped. Blob size: ${blob.size} bytes, type: ${blob.type}`)
        resolve(blob)
      }

      this.mediaRecorder!.onerror = (event) => {
        clearTimeout(timeoutId)
        reject(new Error(`Recording stop error: ${event}`))
      }

      this.mediaRecorder!.stop()
    })
  }

  getRecordingState(): RecordingState {
    return { ...this.recordingState }
  }

  isRecordingSupported(): boolean {
    return !!(window.MediaRecorder && this.recordingStream)
  }

  getLatency(): number {
    if (!this.audioContext) {
      return 0
    }
    return this.audioContext.baseLatency + this.audioContext.outputLatency
  }

  getCPUUsage(): number {
    // Web Audio API doesn't provide direct CPU usage metrics
    // This is a placeholder that could be enhanced with performance monitoring
    return 0
  }

  destroy(): void {
    // Stop recording if active
    if (this.recordingState.isRecording) {
      try {
        this.stopRecording()
      } catch (error) {
        console.error('Error stopping recording during destroy:', error)
      }
    }

    // Clear recording timer
    if (this.recordingTimer) {
      clearInterval(this.recordingTimer)
      this.recordingTimer = null
    }

    this.stop()

    // Clean up all nodes
    this.audioNodes.clear()

    // Close audio context
    if (this.audioContext && this.audioContext.state !== 'closed') {
      this.audioContext.close()
    }

    this.audioContext = null
    this.outputNode = null
    this.recordingStream = null
    this.mediaRecorder = null
    this.recordingChunks = []
    this.isInitialized = false
    this.isStarted = false
  }

  // Private helper methods

  private generateNodeId(): string {
    return `node_${++this.nodeIdCounter}_${Date.now()}`
  }

  private createOscillatorNode(params: AudioParams): OscillatorNode {
    if (!this.audioContext) {
      throw new Error('Audio context not available')
    }

    const oscillator = this.audioContext.createOscillator()
    
    // Set frequency parameter with validation
    const frequency = this.validateParam(params.frequency ?? 440, 20, 2000)
    oscillator.frequency.value = frequency
    
    // Set detune parameter with validation
    const detune = this.validateParam(params.detune ?? 0, -100, 100)
    oscillator.detune.value = detune
    
    // Set waveform type with validation
    const waveformTypes: OscillatorType[] = ['sine', 'square', 'sawtooth', 'triangle']
    const typeIndex = Math.floor(this.validateParam(params.type ?? 0, 0, 3))
    oscillator.type = waveformTypes[typeIndex]

    // Start the oscillator
    oscillator.start()
    
    console.log(`Created oscillator: freq=${frequency}Hz, detune=${detune}cents, type=${oscillator.type}`)
    return oscillator
  }

  private createFilterNode(params: AudioParams): BiquadFilterNode {
    if (!this.audioContext) {
      throw new Error('Audio context not available')
    }

    const filter = this.audioContext.createBiquadFilter()
    
    // Set cutoff frequency with validation
    const cutoff = this.validateParam(params.cutoff ?? 1000, 20, 20000)
    filter.frequency.value = cutoff
    
    // Set resonance (Q factor) with validation
    const resonance = this.validateParam(params.resonance ?? 1, 0.1, 30)
    filter.Q.value = resonance
    
    // Set filter type with validation
    const filterTypes: BiquadFilterType[] = ['lowpass', 'highpass', 'bandpass', 'notch']
    const typeIndex = Math.floor(this.validateParam(params.type ?? 0, 0, 3))
    filter.type = filterTypes[typeIndex]

    console.log(`Created filter: cutoff=${cutoff}Hz, Q=${resonance}, type=${filter.type}`)
    return filter
  }

  private createGainNode(params: AudioParams): GainNode {
    if (!this.audioContext) {
      throw new Error('Audio context not available')
    }

    const gain = this.audioContext.createGain()
    
    // Set gain value with validation and safety limits
    const gainValue = this.validateParam(params.gain ?? 0.5, 0, 2)
    gain.gain.value = gainValue
    
    console.log(`Created gain node: gain=${gainValue}`)
    return gain
  }

  private createOutputNode(_params: AudioParams): GainNode {
    if (!this.audioContext || !this.outputNode) {
      throw new Error('Audio context or output node not available')
    }

    // Output node is a gain node that connects to the master output
    const outputGain = this.audioContext.createGain()
    outputGain.gain.value = 1.0
    outputGain.connect(this.outputNode)
    
    console.log('Created output node connected to master output')
    return outputGain
  }

  private updateNodeParameters(nodeInfo: AudioNodeInfo, params: AudioParams): void {
    const { node, type } = nodeInfo

    switch (type) {
      case CubeType.OSCILLATOR:
        const osc = node as OscillatorNode
        if (params.frequency !== undefined) {
          osc.frequency.setValueAtTime(
            this.validateParam(params.frequency, 20, 2000),
            this.audioContext!.currentTime
          )
        }
        if (params.detune !== undefined) {
          osc.detune.setValueAtTime(
            this.validateParam(params.detune, -100, 100),
            this.audioContext!.currentTime
          )
        }
        break

      case CubeType.FILTER:
        const filter = node as BiquadFilterNode
        if (params.cutoff !== undefined) {
          filter.frequency.setValueAtTime(
            this.validateParam(params.cutoff, 20, 20000),
            this.audioContext!.currentTime
          )
        }
        if (params.resonance !== undefined) {
          filter.Q.setValueAtTime(
            this.validateParam(params.resonance, 0.1, 30),
            this.audioContext!.currentTime
          )
        }
        break

      case CubeType.GAIN:
        const gain = node as GainNode
        if (params.gain !== undefined) {
          gain.gain.setValueAtTime(
            this.validateParam(params.gain, 0, 2),
            this.audioContext!.currentTime
          )
        }
        break
    }
  }

  private stopAudioNode(nodeInfo: AudioNodeInfo): void {
    if (nodeInfo.type === CubeType.OSCILLATOR) {
      const osc = nodeInfo.node as OscillatorNode
      try {
        osc.stop()
      } catch (error) {
        // Oscillator might already be stopped
      }
    }
  }

  private canConnect(fromType: CubeType, toType: CubeType): boolean {
    // Define connection rules based on cube types
    const connectionRules: Record<CubeType, CubeType[]> = {
      [CubeType.OSCILLATOR]: [CubeType.FILTER, CubeType.GAIN, CubeType.OUTPUT],
      [CubeType.FILTER]: [CubeType.FILTER, CubeType.GAIN, CubeType.OUTPUT],
      [CubeType.GAIN]: [CubeType.FILTER, CubeType.GAIN, CubeType.OUTPUT],
      [CubeType.OUTPUT]: [] // Output nodes don't connect to anything
    }

    return connectionRules[fromType]?.includes(toType) ?? false
  }

  private validateParam(value: number, min: number, max: number): number {
    return Math.max(min, Math.min(max, value))
  }
}