import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest'
import { AudioEngineImpl } from '../AudioEngineImpl'
import { CubeType } from '@/types'

// Mock Web Audio API
const mockAudioContext = {
  state: 'running' as AudioContextState,
  currentTime: 0,
  baseLatency: 0.005,
  outputLatency: 0.01,
  destination: {},
  createGain: vi.fn(),
  createOscillator: vi.fn(),
  createBiquadFilter: vi.fn(),
  createMediaStreamDestination: vi.fn(),
  resume: vi.fn().mockResolvedValue(undefined),
  suspend: vi.fn().mockResolvedValue(undefined),
  close: vi.fn().mockResolvedValue(undefined)
}

const mockGainNode = {
  gain: { value: 0.5, setValueAtTime: vi.fn() },
  connect: vi.fn(),
  disconnect: vi.fn()
}

const mockOscillatorNode = {
  frequency: { value: 440, setValueAtTime: vi.fn() },
  detune: { value: 0, setValueAtTime: vi.fn() },
  type: 'sine',
  start: vi.fn(),
  stop: vi.fn(),
  connect: vi.fn(),
  disconnect: vi.fn()
}

const mockFilterNode = {
  frequency: { value: 1000, setValueAtTime: vi.fn() },
  Q: { value: 1, setValueAtTime: vi.fn() },
  type: 'lowpass',
  connect: vi.fn(),
  disconnect: vi.fn()
}

// Mock MediaStream
const mockMediaStream = {
  getTracks: vi.fn().mockReturnValue([]),
  getAudioTracks: vi.fn().mockReturnValue([]),
  getVideoTracks: vi.fn().mockReturnValue([])
}

const mockMediaStreamDestination = {
  stream: mockMediaStream,
  connect: vi.fn(),
  disconnect: vi.fn()
}

// Mock MediaRecorder
const mockMediaRecorder = {
  start: vi.fn(),
  stop: vi.fn(),
  ondataavailable: null as any,
  onstop: null as any,
  onerror: null as any
}

// Setup global mocks
Object.defineProperty(window, 'AudioContext', {
  writable: true,
  value: vi.fn().mockImplementation(() => mockAudioContext)
})

Object.defineProperty(window, 'MediaRecorder', {
  writable: true,
  value: vi.fn().mockImplementation(() => mockMediaRecorder)
})

Object.defineProperty(window, 'MediaStream', {
  writable: true,
  value: vi.fn().mockImplementation(() => mockMediaStream)
})

describe('AudioEngineImpl', () => {
  let audioEngine: AudioEngineImpl

  beforeEach(() => {
    vi.clearAllMocks()
    
    // Setup mock return values
    mockAudioContext.createGain.mockReturnValue(mockGainNode)
    mockAudioContext.createOscillator.mockReturnValue(mockOscillatorNode)
    mockAudioContext.createBiquadFilter.mockReturnValue(mockFilterNode)
    mockAudioContext.createMediaStreamDestination.mockReturnValue(mockMediaStreamDestination)
    
    audioEngine = new AudioEngineImpl()
  })

  afterEach(() => {
    audioEngine.destroy()
  })

  describe('initialization', () => {
    it('should initialize audio context successfully', async () => {
      await audioEngine.initialize()
      
      expect(window.AudioContext).toHaveBeenCalledWith({
        latencyHint: 'interactive',
        sampleRate: 44100
      })
      expect(mockAudioContext.createGain).toHaveBeenCalled()
      expect(mockGainNode.connect).toHaveBeenCalledWith(mockAudioContext.destination)
    })

    it('should not initialize twice', async () => {
      await audioEngine.initialize()
      await audioEngine.initialize()
      
      expect(window.AudioContext).toHaveBeenCalledTimes(1)
    })

    it('should handle initialization errors', async () => {
      const errorMessage = 'AudioContext creation failed'
      vi.mocked(window.AudioContext).mockImplementationOnce(() => {
        throw new Error(errorMessage)
      })

      await expect(audioEngine.initialize()).rejects.toThrow(`Failed to initialize audio context: Error: ${errorMessage}`)
    })
  })

  describe('start and stop', () => {
    beforeEach(async () => {
      await audioEngine.initialize()
    })

    it('should start audio context successfully', async () => {
      mockAudioContext.state = 'suspended'
      
      await audioEngine.start()
      
      expect(mockAudioContext.resume).toHaveBeenCalled()
    })

    it('should not start if not initialized', async () => {
      const uninitializedEngine = new AudioEngineImpl()
      
      await expect(uninitializedEngine.start()).rejects.toThrow('AudioEngine must be initialized before starting')
    })

    it('should stop audio context', async () => {
      // Setup for successful start
      mockAudioContext.state = 'running'
      await audioEngine.start()
      
      audioEngine.stop()
      
      expect(mockAudioContext.suspend).toHaveBeenCalled()
    })

    it('should not start twice', async () => {
      // Setup for successful start
      mockAudioContext.state = 'running'
      await audioEngine.start()
      await audioEngine.start()
      
      // Resume should not be called since context is already running
      expect(mockAudioContext.resume).not.toHaveBeenCalled()
    })
  })

  describe('audio node creation', () => {
    beforeEach(async () => {
      await audioEngine.initialize()
    })

    it('should create oscillator node with default parameters', () => {
      const nodeId = audioEngine.createAudioNode(CubeType.OSCILLATOR, {})
      
      expect(nodeId).toMatch(/^node_\d+_\d+$/)
      expect(mockAudioContext.createOscillator).toHaveBeenCalled()
      expect(mockOscillatorNode.frequency.value).toBe(440)
      expect(mockOscillatorNode.detune.value).toBe(0)
      expect(mockOscillatorNode.type).toBe('sine')
      expect(mockOscillatorNode.start).toHaveBeenCalled()
    })

    it('should create oscillator node with custom parameters', () => {
      const params = { frequency: 880, detune: 50, type: 1 }
      audioEngine.createAudioNode(CubeType.OSCILLATOR, params)
      
      expect(mockOscillatorNode.frequency.value).toBe(880)
      expect(mockOscillatorNode.detune.value).toBe(50)
      expect(mockOscillatorNode.type).toBe('square')
    })

    it('should create filter node with default parameters', () => {
      const nodeId = audioEngine.createAudioNode(CubeType.FILTER, {})
      
      expect(nodeId).toMatch(/^node_\d+_\d+$/)
      expect(mockAudioContext.createBiquadFilter).toHaveBeenCalled()
      expect(mockFilterNode.frequency.value).toBe(1000)
      expect(mockFilterNode.Q.value).toBe(1)
      expect(mockFilterNode.type).toBe('lowpass')
    })

    it('should create filter node with custom parameters', () => {
      const params = { cutoff: 2000, resonance: 5, type: 2 }
      audioEngine.createAudioNode(CubeType.FILTER, params)
      
      expect(mockFilterNode.frequency.value).toBe(2000)
      expect(mockFilterNode.Q.value).toBe(5)
      expect(mockFilterNode.type).toBe('bandpass')
    })

    it('should create gain node with default parameters', () => {
      const nodeId = audioEngine.createAudioNode(CubeType.GAIN, {})
      
      expect(nodeId).toMatch(/^node_\d+_\d+$/)
      expect(mockAudioContext.createGain).toHaveBeenCalled()
      expect(mockGainNode.gain.value).toBe(0.5)
    })

    it('should create gain node with custom parameters', () => {
      const params = { gain: 1.5 }
      audioEngine.createAudioNode(CubeType.GAIN, params)
      
      expect(mockGainNode.gain.value).toBe(1.5)
    })

    it('should create output node', () => {
      const nodeId = audioEngine.createAudioNode(CubeType.OUTPUT, {})
      
      expect(nodeId).toMatch(/^node_\d+_\d+$/)
      expect(mockAudioContext.createGain).toHaveBeenCalled()
      expect(mockGainNode.connect).toHaveBeenCalled()
    })

    it('should validate parameter ranges', () => {
      // Test frequency bounds
      audioEngine.createAudioNode(CubeType.OSCILLATOR, { frequency: -100 })
      expect(mockOscillatorNode.frequency.value).toBe(20) // Clamped to minimum

      audioEngine.createAudioNode(CubeType.OSCILLATOR, { frequency: 5000 })
      expect(mockOscillatorNode.frequency.value).toBe(2000) // Clamped to maximum
    })

    it('should throw error for unsupported cube type', () => {
      expect(() => {
        audioEngine.createAudioNode('invalid' as CubeType, {})
      }).toThrow('Unsupported cube type: invalid')
    })

    it('should throw error if not initialized', () => {
      const uninitializedEngine = new AudioEngineImpl()
      
      expect(() => {
        uninitializedEngine.createAudioNode(CubeType.OSCILLATOR, {})
      }).toThrow('AudioEngine not initialized')
    })

    it('should validate parameter bounds correctly', () => {
      // Test extreme values are clamped properly
      const oscId1 = audioEngine.createAudioNode(CubeType.OSCILLATOR, { frequency: -1000 })
      const oscId2 = audioEngine.createAudioNode(CubeType.OSCILLATOR, { frequency: 50000 })
      
      expect(oscId1).toMatch(/^node_\d+_\d+$/)
      expect(oscId2).toMatch(/^node_\d+_\d+$/)
      
      // Verify the values were clamped (we can't directly check the node values in tests,
      // but the creation should succeed without throwing)
    })
  })

  describe('audio node updates', () => {
    let nodeId: string

    beforeEach(async () => {
      await audioEngine.initialize()
      nodeId = audioEngine.createAudioNode(CubeType.OSCILLATOR, {})
    })

    it('should update oscillator parameters', () => {
      const newParams = { frequency: 880, detune: 25 }
      audioEngine.updateAudioNode(nodeId, newParams)
      
      expect(mockOscillatorNode.frequency.setValueAtTime).toHaveBeenCalledWith(880, 0)
      expect(mockOscillatorNode.detune.setValueAtTime).toHaveBeenCalledWith(25, 0)
    })

    it('should update filter parameters', () => {
      const filterNodeId = audioEngine.createAudioNode(CubeType.FILTER, {})
      const newParams = { cutoff: 1500, resonance: 3 }
      
      audioEngine.updateAudioNode(filterNodeId, newParams)
      
      expect(mockFilterNode.frequency.setValueAtTime).toHaveBeenCalledWith(1500, 0)
      expect(mockFilterNode.Q.setValueAtTime).toHaveBeenCalledWith(3, 0)
    })

    it('should update gain parameters', () => {
      const gainNodeId = audioEngine.createAudioNode(CubeType.GAIN, {})
      const newParams = { gain: 0.8 }
      
      audioEngine.updateAudioNode(gainNodeId, newParams)
      
      expect(mockGainNode.gain.setValueAtTime).toHaveBeenCalledWith(0.8, 0)
    })

    it('should throw error for non-existent node', () => {
      expect(() => {
        audioEngine.updateAudioNode('invalid-id', {})
      }).toThrow('Audio node invalid-id not found')
    })
  })

  describe('audio node removal', () => {
    let nodeId: string

    beforeEach(async () => {
      await audioEngine.initialize()
      nodeId = audioEngine.createAudioNode(CubeType.OSCILLATOR, {})
    })

    it('should remove audio node successfully', () => {
      audioEngine.removeAudioNode(nodeId)
      
      expect(mockOscillatorNode.stop).toHaveBeenCalled()
      expect(mockOscillatorNode.disconnect).toHaveBeenCalled()
    })

    it('should handle removal of non-existent node gracefully', () => {
      expect(() => {
        audioEngine.removeAudioNode('invalid-id')
      }).not.toThrow()
    })
  })

  describe('node connections', () => {
    let oscId: string
    let filterId: string
    let gainId: string
    let outputId: string

    beforeEach(async () => {
      await audioEngine.initialize()
      oscId = audioEngine.createAudioNode(CubeType.OSCILLATOR, {})
      filterId = audioEngine.createAudioNode(CubeType.FILTER, {})
      gainId = audioEngine.createAudioNode(CubeType.GAIN, {})
      outputId = audioEngine.createAudioNode(CubeType.OUTPUT, {})
    })

    it('should connect compatible nodes', () => {
      audioEngine.connectNodes(oscId, filterId)
      
      expect(mockOscillatorNode.connect).toHaveBeenCalledWith(mockFilterNode)
    })

    it('should connect multiple nodes in chain', () => {
      audioEngine.connectNodes(oscId, filterId)
      audioEngine.connectNodes(filterId, gainId)
      audioEngine.connectNodes(gainId, outputId)
      
      expect(mockOscillatorNode.connect).toHaveBeenCalledWith(mockFilterNode)
      expect(mockFilterNode.connect).toHaveBeenCalledWith(mockGainNode)
      expect(mockGainNode.connect).toHaveBeenCalledWith(mockGainNode) // Output node is also a gain node
    })

    it('should prevent invalid connections', () => {
      expect(() => {
        audioEngine.connectNodes(outputId, oscId)
      }).toThrow('Cannot connect output to oscillator')
    })

    it('should throw error for non-existent nodes', () => {
      expect(() => {
        audioEngine.connectNodes('invalid-from', 'invalid-to')
      }).toThrow('Cannot connect nodes: invalid-from or invalid-to not found')
    })

    it('should disconnect nodes', () => {
      audioEngine.connectNodes(oscId, filterId)
      audioEngine.disconnectNodes(oscId, filterId)
      
      expect(mockOscillatorNode.disconnect).toHaveBeenCalledWith(mockFilterNode)
    })

    it('should handle disconnection of non-connected nodes gracefully', () => {
      expect(() => {
        audioEngine.disconnectNodes(oscId, filterId)
      }).not.toThrow()
    })
  })

  describe('recording', () => {
    beforeEach(async () => {
      await audioEngine.initialize()
    })

    it('should start recording', () => {
      audioEngine.startRecording()
      
      expect(window.MediaRecorder).toHaveBeenCalledWith(
        mockMediaStreamDestination.stream,
        { mimeType: 'audio/webm;codecs=opus' }
      )
      expect(mockMediaRecorder.start).toHaveBeenCalled()
    })

    it('should stop recording and return blob', async () => {
      audioEngine.startRecording()
      
      const recordingPromise = audioEngine.stopRecording()
      
      // Simulate MediaRecorder events
      const testData = new Blob(['test'], { type: 'audio/webm' })
      mockMediaRecorder.ondataavailable({ data: testData })
      mockMediaRecorder.onstop()
      
      const result = await recordingPromise
      expect(result).toBeInstanceOf(Blob)
      expect(mockMediaRecorder.stop).toHaveBeenCalled()
    })

    it('should handle recording errors', async () => {
      audioEngine.startRecording()
      
      const recordingPromise = audioEngine.stopRecording()
      
      // Simulate error
      mockMediaRecorder.onerror('Recording failed')
      
      await expect(recordingPromise).rejects.toThrow('Recording error: Recording failed')
    })

    it('should throw error when stopping without active recording', async () => {
      await expect(audioEngine.stopRecording()).rejects.toThrow('No active recording')
    })
  })

  describe('performance monitoring', () => {
    beforeEach(async () => {
      await audioEngine.initialize()
    })

    it('should return audio latency', () => {
      const latency = audioEngine.getLatency()
      expect(latency).toBe(0.015) // baseLatency + outputLatency
    })

    it('should return CPU usage placeholder', () => {
      const cpuUsage = audioEngine.getCPUUsage()
      expect(cpuUsage).toBe(0)
    })
  })

  describe('cleanup', () => {
    it('should destroy audio engine properly', async () => {
      await audioEngine.initialize()
      
      // Setup for successful start
      mockAudioContext.state = 'running'
      await audioEngine.start()
      
      audioEngine.destroy()
      
      expect(mockAudioContext.close).toHaveBeenCalled()
    })
  })
})