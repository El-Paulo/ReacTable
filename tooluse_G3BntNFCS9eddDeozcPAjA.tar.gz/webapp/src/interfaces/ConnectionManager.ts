import { CubeInstance, Connection, CubeType } from '@/types'

export interface ConnectionManager {
  // Connection detection
  updateConnections(cubes: CubeInstance[]): void
  checkProximity(cube1: CubeInstance, cube2: CubeInstance): boolean
  
  // Connection management
  createConnection(fromId: string, toId: string): Connection
  removeConnection(connectionId: string): void
  getConnections(): Connection[]
  
  // Validation
  validateConnection(fromId: string, toId: string): boolean
  detectCycles(connections: Connection[]): boolean
  validateConnectionTypes(fromType: CubeType, toType: CubeType): boolean
  
  // Visual warnings
  onInvalidConnectionAttempt(callback: (fromId: string, toId: string, reason: string) => void): void
  
  // Events
  onConnectionCreated(callback: (connection: Connection) => void): void
  onConnectionRemoved(callback: (connectionId: string) => void): void
}