import { Vector2 } from 'three'

export interface InteractionManager {
  // Initialization
  initialize(container: HTMLElement): void
  
  // Event handling
  setOnCubeClick(callback: (cubeId: string | null, screenPosition: Vector2) => void): void
  setOnCubeDelete(callback: (cubeId: string) => void): void
  setOnDragStart(callback: (cubeId: string, screenPosition: Vector2) => void): void
  setOnDragUpdate(callback: (screenPosition: Vector2) => void): void
  setOnDragEnd(callback: () => void): void
  setOnRotateStart(callback: (cubeId: string, screenPosition: Vector2) => void): void
  setOnRotateUpdate(callback: (screenPosition: Vector2) => void): void
  setOnRotateEnd(callback: () => void): void
  
  // State
  isKeyPressed(key: string): boolean
  
  // Cleanup
  destroy(): void
}

export interface InteractionState {
  isMouseDown: boolean
  isDragging: boolean
  isRotating: boolean
  pressedKeys: Set<string>
  mousePosition: Vector2
  selectedCubeId: string | null
}