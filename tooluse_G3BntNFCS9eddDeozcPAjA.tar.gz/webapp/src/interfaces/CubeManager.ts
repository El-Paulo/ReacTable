import { Vector3 } from 'three'
import { CubeType, CubeInstance, AudioParams } from '@/types'

export interface CubeManager {
  // Cube lifecycle
  createCube(type: CubeType, position: Vector3): CubeInstance
  destroyCube(cubeId: string): void
  getCube(cubeId: string): CubeInstance | null
  getAllCubes(): CubeInstance[]
  
  // Cube manipulation
  moveCube(cubeId: string, position: Vector3): void
  rotateCube(cubeId: string, rotation: Vector3): void
  scaleCube(cubeId: string, scale: Vector3): void
  
  // Parameter mapping
  mapTransformToAudio(cube: CubeInstance): AudioParams
  
  // Selection
  selectCube(cubeId: string): void
  deselectCube(): void
  getSelectedCube(): CubeInstance | null
}