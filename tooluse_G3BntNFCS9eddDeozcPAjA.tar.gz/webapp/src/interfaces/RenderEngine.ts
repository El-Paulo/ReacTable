import { Vector2 } from 'three'
import { CubeInstance, Transform3D, RaycastResult } from '@/types'

export interface RenderEngine {
  // Scene management
  initializeScene(): void
  addCube(cube: CubeInstance): void
  removeCube(cubeId: string): void
  updateCube(cubeId: string, transform: Transform3D): void
  
  // Camera controls
  setCameraController(controller: CameraController): void
  
  // Visual effects
  showConnection(from: string, to: string, intensity: number): void
  hideConnection(from: string, to: string): void
  
  // Interaction
  raycast(screenPosition: Vector2): RaycastResult[]
  selectCube(cubeId: string): void
  clearSelection(): void
  getSelectedCubeId(): string | null
  setCubeActive(cubeId: string, active: boolean): void
  
  // Cube manipulation
  startDragCube(cubeId: string, screenPosition: Vector2): void
  updateDragCube(screenPosition: Vector2): void
  endDragCube(): void
  startRotateCube(cubeId: string, screenPosition: Vector2): void
  updateRotateCube(screenPosition: Vector2): void
  endRotateCube(): void
  isDragging(): boolean
  isRotating(): boolean
  
  // Rendering
  render(): void
  setSize(width: number, height: number): void
  
  // Cleanup
  destroy(): void
}

export interface CameraController {
  update(): void
  enableControls(): void
  disableControls(): void
}