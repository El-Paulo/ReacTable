import { CubeType, AudioParams } from '@/types'
import { ErrorHandler } from './ErrorHandler'

export interface AudioEngine {
  // Initialization
  initialize(errorHandler?: ErrorHandler): Promise<void>
  start(): Promise<void>
  stop(): void
  
  // Node management
  createAudioNode(type: CubeType, params: AudioParams): string
  updateAudioNode(nodeId: string, params: AudioParams): void
  removeAudioNode(nodeId: string): void
  
  // Connections
  connectNodes(fromId: string, toId: string): void
  disconnectNodes(fromId: string, toId: string): void
  
  // Recording
  startRecording(maxDuration?: number): void
  pauseRecording(): void
  stopRecording(): Promise<Blob>
  getRecordingState(): { isRecording: boolean; isPaused: boolean; duration: number; maxDuration: number }
  isRecordingSupported(): boolean
  
  // Performance monitoring
  getLatency(): number
  getCPUUsage(): number
  
  // Cleanup
  destroy(): void
}