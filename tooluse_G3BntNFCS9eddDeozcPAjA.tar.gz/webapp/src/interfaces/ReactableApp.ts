import { AppState } from '@/types'

export interface ReactableApp {
  // Initialization
  initialize(): Promise<void>
  startAudio(): Promise<void>
  
  // Recording
  startRecording(): void
  pauseRecording(): void
  stopRecording(): Promise<void>
  
  // State management
  getState(): AppState
  setState(state: Partial<AppState>): void
  
  // Main update loop
  update(deltaTime: number): void
  render(): void
  
  // Cleanup
  destroy(): void
}