import { PerformanceStatus } from '@/types'

export interface PerformanceMonitor {
  // Metrics collection
  getFPS(): number
  getAudioLatency(): number
  getCPUUsage(): number
  getMemoryUsage(): number
  
  // Thresholds and alerts
  checkPerformance(): PerformanceStatus
  enableDegradedMode(): void
  disableDegradedMode(): void
  
  // Events
  onPerformanceChange(callback: (status: PerformanceStatus) => void): void
}