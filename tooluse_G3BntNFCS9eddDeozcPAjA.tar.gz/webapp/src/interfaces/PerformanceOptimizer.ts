export interface PerformanceOptimizer {
  // Optimization control
  enableOptimizations(): void
  disableOptimizations(): void
  isOptimizationEnabled(): boolean
  
  // Optimization levels
  setOptimizationLevel(level: OptimizationLevel): void
  getOptimizationLevel(): OptimizationLevel
  
  // Cube limits
  getCubeLimit(): number
  setCubeLimit(limit: number): void
  
  // Cube count validation
  isCubeCountExceeded(currentCount: number): boolean
  getCubeLimitWarning(currentCount: number): string | null
  
  // Events
  onOptimizationChange(callback: (level: OptimizationLevel) => void): void
}

export enum OptimizationLevel {
  NONE = 0,
  LOW = 1,
  MEDIUM = 2,
  HIGH = 3,
  EXTREME = 4
}

export interface OptimizationSettings {
  maxCubes: number
  visualQuality: number // 0-1 scale
  audioQuality: number // 0-1 scale
  shadowsEnabled: boolean
  particlesEnabled: boolean
  antiAliasingEnabled: boolean
  audioBufferSize: number
}