import { ErrorType } from '@/types'

export interface ErrorHandler {
  handleError(error: ErrorType, details?: any): void
  showUserMessage(message: string, type: 'error' | 'warning' | 'info'): void
  attemptRecovery(error: ErrorType): Promise<boolean>
  
  // Events
  onError(callback: (error: ErrorType, details?: any) => void): void
}