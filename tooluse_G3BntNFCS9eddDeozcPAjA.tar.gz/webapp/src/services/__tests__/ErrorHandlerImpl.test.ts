import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest'
import { ErrorHandlerImpl } from '../ErrorHandlerImpl'
import { ErrorType } from '@/types'
import { NotificationSystem } from '@/ui/NotificationSystem'

// Mock browser APIs
const mockAudioContext = {
  state: 'running',
  resume: vi.fn().mockResolvedValue(undefined),
  close: vi.fn().mockResolvedValue(undefined)
}

const mockWebGLContext = {
  getSupportedExtensions: vi.fn().mockReturnValue(['EXT_texture_filter_anisotropic']),
  getParameter: vi.fn().mockReturnValue(4096)
}

// Mock global objects
Object.defineProperty(window, 'AudioContext', {
  writable: true,
  value: vi.fn().mockImplementation(() => mockAudioContext)
})

Object.defineProperty(window, 'MediaRecorder', {
  writable: true,
  value: vi.fn()
})

// Mock canvas and WebGL
const mockCanvas = {
  getContext: vi.fn().mockImplementation((type) => {
    if (type === 'webgl' || type === 'experimental-webgl' || type === 'webgl2') {
      return mockWebGLContext
    }
    return null
  })
}

Object.defineProperty(document, 'createElement', {
  writable: true,
  value: vi.fn().mockImplementation((tagName) => {
    if (tagName === 'canvas') {
      return mockCanvas
    }
    return {}
  })
})

// Mock console methods
const consoleSpy = {
  error: vi.spyOn(console, 'error').mockImplementation(() => {}),
  warn: vi.spyOn(console, 'warn').mockImplementation(() => {}),
  log: vi.spyOn(console, 'log').mockImplementation(() => {})
}

// Mock alert
const alertSpy = vi.spyOn(window, 'alert').mockImplementation(() => {})

// Mock NotificationSystem
const mockNotificationSystem = {
  show: vi.fn(),
  error: vi.fn(),
  warning: vi.fn(),
  info: vi.fn(),
  success: vi.fn(),
  showBrowserCompatibilityError: vi.fn(),
  showAudioPermissionError: vi.fn(),
  showWebGLFallbackWarning: vi.fn(),
  showPerformanceWarning: vi.fn(),
  destroy: vi.fn()
}

describe('ErrorHandlerImpl', () => {
  let errorHandler: ErrorHandlerImpl

  beforeEach(() => {
    errorHandler = new ErrorHandlerImpl(mockNotificationSystem as any)
    vi.clearAllMocks()
  })

  afterEach(() => {
    errorHandler.clearErrorHistory()
  })

  describe('handleError', () => {
    it('should handle audio context failed error', () => {
      const callback = vi.fn()
      errorHandler.onError(callback)

      errorHandler.handleError(ErrorType.AUDIO_CONTEXT_FAILED, { reason: 'test' })

      expect(callback).toHaveBeenCalledWith(ErrorType.AUDIO_CONTEXT_FAILED, { reason: 'test' })
      expect(consoleSpy.error).toHaveBeenCalled()
      expect(consoleSpy.log).toHaveBeenCalledWith(
        expect.stringContaining('[ERROR] Audio system failed to initialize')
      )
    })

    it('should handle WebGL not supported error', () => {
      errorHandler.handleError(ErrorType.WEBGL_NOT_SUPPORTED)

      expect(consoleSpy.error).toHaveBeenCalled()
      expect(consoleSpy.log).toHaveBeenCalledWith(
        expect.stringContaining('[ERROR] Your browser does not support WebGL')
      )
    })

    it('should store error in history', () => {
      errorHandler.handleError(ErrorType.AUDIO_PERMISSION_DENIED)

      const history = errorHandler.getErrorHistory(ErrorType.AUDIO_PERMISSION_DENIED)
      expect(history).toHaveLength(1)
      expect(history[0].message).toContain('Audio permission denied')
      expect(history[0].timestamp).toBeGreaterThan(0)
    })

    it('should show alert for critical errors', () => {
      errorHandler.handleError(ErrorType.AUDIO_CONTEXT_FAILED)
      expect(alertSpy).toHaveBeenCalledWith(
        expect.stringContaining('Audio system failed to initialize')
      )
    })

    it('should not show alert for non-critical errors', () => {
      errorHandler.handleError(ErrorType.PERFORMANCE_DEGRADATION)
      expect(alertSpy).not.toHaveBeenCalled()
    })
  })

  describe('showUserMessage', () => {
    it('should log error messages', () => {
      errorHandler.showUserMessage('Test error', 'error')
      expect(consoleSpy.log).toHaveBeenCalledWith('[ERROR] Test error')
    })

    it('should log warning messages', () => {
      errorHandler.showUserMessage('Test warning', 'warning')
      expect(consoleSpy.log).toHaveBeenCalledWith('[WARNING] Test warning')
    })

    it('should log info messages', () => {
      errorHandler.showUserMessage('Test info', 'info')
      expect(consoleSpy.log).toHaveBeenCalledWith('[INFO] Test info')
    })
  })

  describe('attemptRecovery', () => {
    it('should attempt recovery for audio context failed', async () => {
      // Ensure the mock AudioContext is returned and has the right state
      const testAudioContext = {
        state: 'suspended',
        resume: vi.fn().mockImplementation(async () => {
          testAudioContext.state = 'running'
        }),
        close: vi.fn().mockResolvedValue(undefined)
      }
      
      window.AudioContext = vi.fn().mockImplementation(() => testAudioContext)
      
      const success = await errorHandler.attemptRecovery(ErrorType.AUDIO_CONTEXT_FAILED)
      expect(success).toBe(true)
      expect(testAudioContext.resume).toHaveBeenCalled()
      expect(testAudioContext.close).toHaveBeenCalled()
    })

    it('should not attempt recovery for WebGL not supported', async () => {
      const success = await errorHandler.attemptRecovery(ErrorType.WEBGL_NOT_SUPPORTED)
      expect(success).toBe(false)
      expect(consoleSpy.log).toHaveBeenCalledWith(
        expect.stringContaining('[WARNING] Switching to compatibility mode')
      )
    })

    it('should limit recovery attempts', async () => {
      // Mock failed recovery by making AudioContext constructor throw
      const originalAudioContext = window.AudioContext
      window.AudioContext = vi.fn().mockImplementation(() => {
        throw new Error('Recovery failed')
      })

      // Attempt recovery multiple times
      for (let i = 0; i < 5; i++) {
        await errorHandler.attemptRecovery(ErrorType.AUDIO_CONTEXT_FAILED)
      }

      expect(consoleSpy.warn).toHaveBeenCalledWith(
        'Max recovery attempts reached for audio_context_failed'
      )

      // Restore
      window.AudioContext = originalAudioContext
    })

    it('should reset attempts on successful recovery', async () => {
      // First attempt fails
      const originalAudioContext = window.AudioContext
      let callCount = 0
      window.AudioContext = vi.fn().mockImplementation(() => {
        callCount++
        if (callCount === 1) {
          throw new Error('First attempt failed')
        }
        return mockAudioContext
      })

      await errorHandler.attemptRecovery(ErrorType.AUDIO_CONTEXT_FAILED)

      // Second attempt succeeds
      const success = await errorHandler.attemptRecovery(ErrorType.AUDIO_CONTEXT_FAILED)

      expect(success).toBe(true)
      expect(consoleSpy.log).toHaveBeenCalledWith('[INFO] System recovered successfully')

      // Restore
      window.AudioContext = originalAudioContext
    })
  })

  describe('checkBrowserCompatibility', () => {
    it('should detect compatible browser', () => {
      const result = errorHandler.checkBrowserCompatibility()
      expect(result.isCompatible).toBe(true)
      expect(result.issues).toHaveLength(0)
    })

    it('should detect Web Audio API issues', () => {
      // Mock missing Web Audio API
      const originalAudioContext = window.AudioContext
      delete (window as any).AudioContext
      delete (window as any).webkitAudioContext

      const result = errorHandler.checkBrowserCompatibility()
      expect(result.isCompatible).toBe(false)
      expect(result.issues).toContain('Web Audio API not supported')

      // Restore
      window.AudioContext = originalAudioContext
    })

    it('should detect WebGL issues', () => {
      // Mock WebGL not supported
      mockCanvas.getContext.mockReturnValue(null)

      const result = errorHandler.checkBrowserCompatibility()
      expect(result.isCompatible).toBe(false)
      expect(result.issues).toContain('WebGL not supported')

      // Restore
      mockCanvas.getContext.mockImplementation((type) => {
        if (type === 'webgl' || type === 'experimental-webgl') {
          return mockWebGLContext
        }
        return null
      })
    })

    it('should detect MediaRecorder issues', () => {
      // Mock missing MediaRecorder
      const originalMediaRecorder = window.MediaRecorder
      delete (window as any).MediaRecorder

      const result = errorHandler.checkBrowserCompatibility()
      expect(result.isCompatible).toBe(false)
      expect(result.issues).toContain('Audio recording not supported')

      // Restore
      window.MediaRecorder = originalMediaRecorder
    })
  })

  describe('detectWebGLCapabilities', () => {
    it('should detect WebGL capabilities', () => {
      // Reset the mock to ensure it returns the right context for both calls
      mockCanvas.getContext.mockImplementation((type) => {
        if (type === 'webgl' || type === 'experimental-webgl' || type === 'webgl2') {
          return mockWebGLContext
        }
        return null
      })

      const capabilities = errorHandler.detectWebGLCapabilities()
      
      expect(capabilities.hasWebGL).toBe(true)
      expect(capabilities.hasWebGL2).toBe(true)
      expect(capabilities.maxTextureSize).toBe(4096)
      expect(capabilities.extensions).toContain('EXT_texture_filter_anisotropic')
    })

    it('should handle missing WebGL', () => {
      mockCanvas.getContext.mockReturnValue(null)

      const capabilities = errorHandler.detectWebGLCapabilities()
      
      expect(capabilities.hasWebGL).toBe(false)
      expect(capabilities.hasWebGL2).toBe(false)
      expect(capabilities.maxTextureSize).toBe(0)
      expect(capabilities.extensions).toHaveLength(0)

      // Restore
      mockCanvas.getContext.mockImplementation((type) => {
        if (type === 'webgl' || type === 'experimental-webgl') {
          return mockWebGLContext
        }
        if (type === 'webgl2') {
          return mockWebGLContext
        }
        return null
      })
    })
  })

  describe('checkAudioPermissions', () => {
    it('should detect audio permissions granted', async () => {
      const result = await errorHandler.checkAudioPermissions()
      
      expect(result.hasPermission).toBe(true)
      expect(result.canRequestPermission).toBe(true)
      expect(result.error).toBeUndefined()
    })

    it('should detect suspended audio context', async () => {
      const suspendedAudioContext = {
        state: 'suspended',
        close: vi.fn().mockResolvedValue(undefined)
      }
      
      const originalAudioContext = window.AudioContext
      window.AudioContext = vi.fn().mockImplementation(() => suspendedAudioContext)

      const result = await errorHandler.checkAudioPermissions()
      
      expect(result.hasPermission).toBe(false)
      expect(result.canRequestPermission).toBe(true)
      expect(result.error).toBe('Audio requires user interaction to start')

      // Restore
      window.AudioContext = originalAudioContext
    })

    it('should handle missing Web Audio API', async () => {
      const originalAudioContext = window.AudioContext
      delete (window as any).AudioContext
      delete (window as any).webkitAudioContext

      const result = await errorHandler.checkAudioPermissions()
      
      expect(result.hasPermission).toBe(false)
      expect(result.canRequestPermission).toBe(false)
      expect(result.error).toBe('Web Audio API not supported')

      // Restore
      window.AudioContext = originalAudioContext
    })

    it('should handle audio context creation errors', async () => {
      const originalAudioContext = window.AudioContext
      window.AudioContext = vi.fn().mockImplementation(() => {
        throw new Error('Audio context creation failed')
      })

      const result = await errorHandler.checkAudioPermissions()
      
      expect(result.hasPermission).toBe(false)
      expect(result.canRequestPermission).toBe(false)
      expect(result.error).toContain('Audio permission check failed')

      // Restore
      window.AudioContext = originalAudioContext
    })
  })

  describe('error history management', () => {
    it('should track error history', () => {
      errorHandler.handleError(ErrorType.AUDIO_CONTEXT_FAILED)
      errorHandler.handleError(ErrorType.WEBGL_NOT_SUPPORTED)
      errorHandler.handleError(ErrorType.AUDIO_CONTEXT_FAILED)

      const audioErrors = errorHandler.getErrorHistory(ErrorType.AUDIO_CONTEXT_FAILED)
      expect(audioErrors).toHaveLength(2)

      const allErrors = errorHandler.getErrorHistory()
      expect(allErrors).toHaveLength(3)
    })

    it('should clear error history', () => {
      errorHandler.handleError(ErrorType.AUDIO_CONTEXT_FAILED)
      errorHandler.handleError(ErrorType.WEBGL_NOT_SUPPORTED)

      errorHandler.clearErrorHistory(ErrorType.AUDIO_CONTEXT_FAILED)
      expect(errorHandler.getErrorHistory(ErrorType.AUDIO_CONTEXT_FAILED)).toHaveLength(0)
      expect(errorHandler.getErrorHistory(ErrorType.WEBGL_NOT_SUPPORTED)).toHaveLength(1)

      errorHandler.clearErrorHistory()
      expect(errorHandler.getErrorHistory()).toHaveLength(0)
    })
  })

  describe('error callbacks', () => {
    it('should handle callback errors gracefully', () => {
      const faultyCallback = vi.fn().mockImplementation(() => {
        throw new Error('Callback error')
      })
      const goodCallback = vi.fn()

      errorHandler.onError(faultyCallback)
      errorHandler.onError(goodCallback)

      errorHandler.handleError(ErrorType.AUDIO_CONTEXT_FAILED)

      expect(faultyCallback).toHaveBeenCalled()
      expect(goodCallback).toHaveBeenCalled()
      expect(consoleSpy.error).toHaveBeenCalledWith('Error in error callback:', expect.any(Error))
    })
  })
})