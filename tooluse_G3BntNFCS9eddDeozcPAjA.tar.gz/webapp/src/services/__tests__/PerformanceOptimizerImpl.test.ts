import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest'
import { PerformanceOptimizerImpl } from '../PerformanceOptimizerImpl'
import { OptimizationLevel } from '@/interfaces/PerformanceOptimizer'
import { PerformanceMonitor } from '@/interfaces/PerformanceMonitor'
import { RenderEngine } from '@/interfaces/RenderEngine'
import { AudioEngine } from '@/interfaces/AudioEngine'
import { PerformanceStatus } from '@/types'

// Mock PerformanceMonitor
const mockPerformanceMonitor = {
  getFPS: vi.fn(),
  getAudioLatency: vi.fn(),
  getCPUUsage: vi.fn(),
  getMemoryUsage: vi.fn(),
  checkPerformance: vi.fn(),
  enableDegradedMode: vi.fn(),
  disableDegradedMode: vi.fn(),
  onPerformanceChange: vi.fn(),
} as unknown as PerformanceMonitor

// Mock RenderEngine
const mockRenderEngine = {
  initializeScene: vi.fn(),
  addCube: vi.fn(),
  removeCube: vi.fn(),
  updateCube: vi.fn(),
  setCameraController: vi.fn(),
  showConnection: vi.fn(),
  hideConnection: vi.fn(),
  raycast: vi.fn(),
  render: vi.fn(),
  setSize: vi.fn(),
  setVisualQuality: vi.fn(),
  setShadowsEnabled: vi.fn(),
  setParticlesEnabled: vi.fn(),
  setAntiAliasingEnabled: vi.fn(),
} as unknown as RenderEngine

// Mock AudioEngine
const mockAudioEngine = {
  initialize: vi.fn(),
  start: vi.fn(),
  stop: vi.fn(),
  createAudioNode: vi.fn(),
  updateAudioNode: vi.fn(),
  removeAudioNode: vi.fn(),
  connectNodes: vi.fn(),
  disconnectNodes: vi.fn(),
  startRecording: vi.fn(),
  stopRecording: vi.fn(),
  getLatency: vi.fn(),
  getCPUUsage: vi.fn(),
  setAudioQuality: vi.fn(),
  setBufferSize: vi.fn(),
} as unknown as AudioEngine

describe('PerformanceOptimizerImpl', () => {
  let performanceOptimizer: PerformanceOptimizerImpl
  let performanceCallback: (status: PerformanceStatus) => void

  beforeEach(() => {
    vi.clearAllMocks()
    
    // Capture the performance callback
    mockPerformanceMonitor.onPerformanceChange = vi.fn((callback) => {
      performanceCallback = callback
    })

    performanceOptimizer = new PerformanceOptimizerImpl(
      mockPerformanceMonitor,
      mockRenderEngine,
      mockAudioEngine
    )
  })

  afterEach(() => {
    vi.clearAllMocks()
  })

  describe('Initialization', () => {
    it('should initialize with default settings', () => {
      expect(performanceOptimizer.isOptimizationEnabled()).toBe(true)
      expect(performanceOptimizer.getOptimizationLevel()).toBe(OptimizationLevel.NONE)
      expect(performanceOptimizer.getCubeLimit()).toBe(20)
    })

    it('should register performance change callback', () => {
      expect(mockPerformanceMonitor.onPerformanceChange).toHaveBeenCalledWith(expect.any(Function))
    })

    it('should work without render and audio engines', () => {
      const optimizer = new PerformanceOptimizerImpl(mockPerformanceMonitor)
      expect(optimizer.isOptimizationEnabled()).toBe(true)
    })
  })

  describe('Optimization Control', () => {
    it('should enable optimizations', () => {
      const consoleSpy = vi.spyOn(console, 'info').mockImplementation(() => {})
      
      performanceOptimizer.disableOptimizations()
      performanceOptimizer.enableOptimizations()
      
      expect(performanceOptimizer.isOptimizationEnabled()).toBe(true)
      expect(consoleSpy).toHaveBeenCalledWith('Performance Optimizer: Optimizations enabled')
      
      consoleSpy.mockRestore()
    })

    it('should disable optimizations', () => {
      const consoleSpy = vi.spyOn(console, 'info').mockImplementation(() => {})
      
      performanceOptimizer.setOptimizationLevel(OptimizationLevel.HIGH)
      performanceOptimizer.disableOptimizations()
      
      expect(performanceOptimizer.isOptimizationEnabled()).toBe(false)
      expect(performanceOptimizer.getOptimizationLevel()).toBe(OptimizationLevel.NONE)
      expect(consoleSpy).toHaveBeenCalledWith('Performance Optimizer: Optimizations disabled')
      
      consoleSpy.mockRestore()
    })
  })

  describe('Optimization Levels', () => {
    it('should set optimization level', () => {
      const consoleSpy = vi.spyOn(console, 'info').mockImplementation(() => {})
      
      performanceOptimizer.setOptimizationLevel(OptimizationLevel.MEDIUM)
      
      expect(performanceOptimizer.getOptimizationLevel()).toBe(OptimizationLevel.MEDIUM)
      expect(consoleSpy).toHaveBeenCalledWith(
        expect.stringContaining('Changing optimization level from NONE to MEDIUM')
      )
      
      consoleSpy.mockRestore()
    })

    it('should not change level if already set', () => {
      const consoleSpy = vi.spyOn(console, 'info').mockImplementation(() => {})
      
      performanceOptimizer.setOptimizationLevel(OptimizationLevel.LOW)
      consoleSpy.mockClear()
      
      performanceOptimizer.setOptimizationLevel(OptimizationLevel.LOW)
      
      expect(consoleSpy).not.toHaveBeenCalled()
      
      consoleSpy.mockRestore()
    })

    it('should apply visual optimizations when level changes', () => {
      performanceOptimizer.setOptimizationLevel(OptimizationLevel.HIGH)
      
      expect(mockRenderEngine.setVisualQuality).toHaveBeenCalledWith(0.5)
      expect(mockRenderEngine.setShadowsEnabled).toHaveBeenCalledWith(false)
      expect(mockRenderEngine.setParticlesEnabled).toHaveBeenCalledWith(false)
      expect(mockRenderEngine.setAntiAliasingEnabled).toHaveBeenCalledWith(false)
    })

    it('should apply audio optimizations when level changes', () => {
      performanceOptimizer.setOptimizationLevel(OptimizationLevel.MEDIUM)
      
      expect(mockAudioEngine.setAudioQuality).toHaveBeenCalledWith(0.85)
      expect(mockAudioEngine.setBufferSize).toHaveBeenCalledWith(1024)
    })
  })

  describe('Cube Limits', () => {
    it('should return correct cube limit based on optimization level', () => {
      expect(performanceOptimizer.getCubeLimit()).toBe(20) // NONE level
      
      performanceOptimizer.setOptimizationLevel(OptimizationLevel.HIGH)
      expect(performanceOptimizer.getCubeLimit()).toBe(12) // HIGH level
      
      performanceOptimizer.setOptimizationLevel(OptimizationLevel.EXTREME)
      expect(performanceOptimizer.getCubeLimit()).toBe(8) // EXTREME level
    })

    it('should set custom cube limit', () => {
      performanceOptimizer.setCubeLimit(15)
      expect(performanceOptimizer.getCubeLimit()).toBe(15)
      
      // Should respect optimization level limits
      performanceOptimizer.setOptimizationLevel(OptimizationLevel.EXTREME)
      expect(performanceOptimizer.getCubeLimit()).toBe(8) // Limited by EXTREME level
    })

    it('should clamp cube limit to valid range', () => {
      performanceOptimizer.setCubeLimit(-5)
      expect(performanceOptimizer.getCubeLimit()).toBe(1) // Minimum
      
      performanceOptimizer.setCubeLimit(100)
      expect(performanceOptimizer.getCubeLimit()).toBe(20) // Limited by current level
    })

    it('should check if cube count exceeds limit', () => {
      performanceOptimizer.setOptimizationLevel(OptimizationLevel.HIGH) // Limit: 12
      
      expect(performanceOptimizer.isCubeCountExceeded(10)).toBe(false)
      expect(performanceOptimizer.isCubeCountExceeded(12)).toBe(false)
      expect(performanceOptimizer.isCubeCountExceeded(15)).toBe(true)
    })

    it('should provide cube limit warnings', () => {
      performanceOptimizer.setOptimizationLevel(OptimizationLevel.MEDIUM) // Limit: 15
      
      // No warning for safe count
      expect(performanceOptimizer.getCubeLimitWarning(10)).toBeNull()
      
      // Warning for approaching limit
      expect(performanceOptimizer.getCubeLimitWarning(14)).toContain('Approaching cube limit')
      
      // Warning for exceeding limit
      expect(performanceOptimizer.getCubeLimitWarning(18)).toContain('exceed the current limit')
    })
  })

  describe('Performance Change Handling', () => {
    it('should respond to performance changes when enabled', () => {
      const poorPerformance: PerformanceStatus = {
        fps: 15,
        audioLatency: 80,
        cpuUsage: 90,
        memoryUsage: 180,
        isDegraded: true,
        recommendations: ['Critical performance issues']
      }
      
      performanceCallback(poorPerformance)
      
      expect(performanceOptimizer.getOptimizationLevel()).toBeGreaterThan(OptimizationLevel.NONE)
    })

    it('should not respond to performance changes when disabled', () => {
      performanceOptimizer.disableOptimizations()
      
      const poorPerformance: PerformanceStatus = {
        fps: 15,
        audioLatency: 80,
        cpuUsage: 90,
        memoryUsage: 180,
        isDegraded: true,
        recommendations: ['Critical performance issues']
      }
      
      performanceCallback(poorPerformance)
      
      expect(performanceOptimizer.getOptimizationLevel()).toBe(OptimizationLevel.NONE)
    })

    it('should calculate optimization level based on performance metrics', () => {
      // Test extreme performance issues
      const extremePerformance: PerformanceStatus = {
        fps: 10,
        audioLatency: 150,
        cpuUsage: 98,
        memoryUsage: 250,
        isDegraded: true,
        recommendations: []
      }
      
      performanceCallback(extremePerformance)
      expect(performanceOptimizer.getOptimizationLevel()).toBe(OptimizationLevel.EXTREME)
      
      // Test good performance
      const goodPerformance: PerformanceStatus = {
        fps: 60,
        audioLatency: 10,
        cpuUsage: 30,
        memoryUsage: 50,
        isDegraded: false,
        recommendations: []
      }
      
      performanceCallback(goodPerformance)
      expect(performanceOptimizer.getOptimizationLevel()).toBe(OptimizationLevel.NONE)
    })

    it('should calculate medium optimization level correctly', () => {
      const mediumPerformance: PerformanceStatus = {
        fps: 35, // +2 points
        audioLatency: 40, // +2 points
        cpuUsage: 70, // +1 point
        memoryUsage: 100, // 0 points
        isDegraded: false,
        recommendations: []
      }
      
      performanceCallback(mediumPerformance)
      expect(performanceOptimizer.getOptimizationLevel()).toBe(OptimizationLevel.MEDIUM)
    })
  })

  describe('Optimization Callbacks', () => {
    it('should register and call optimization change callbacks', () => {
      const callback = vi.fn()
      
      performanceOptimizer.onOptimizationChange(callback)
      performanceOptimizer.setOptimizationLevel(OptimizationLevel.HIGH)
      
      expect(callback).toHaveBeenCalledWith(OptimizationLevel.HIGH)
    })

    it('should handle callback errors gracefully', () => {
      const errorCallback = vi.fn(() => {
        throw new Error('Callback error')
      })
      const consoleSpy = vi.spyOn(console, 'error').mockImplementation(() => {})
      
      performanceOptimizer.onOptimizationChange(errorCallback)
      performanceOptimizer.setOptimizationLevel(OptimizationLevel.LOW)
      
      expect(consoleSpy).toHaveBeenCalledWith(
        'Performance Optimizer: Error in optimization callback:',
        expect.any(Error)
      )
      
      consoleSpy.mockRestore()
    })

    it('should call multiple callbacks', () => {
      const callback1 = vi.fn()
      const callback2 = vi.fn()
      
      performanceOptimizer.onOptimizationChange(callback1)
      performanceOptimizer.onOptimizationChange(callback2)
      performanceOptimizer.setOptimizationLevel(OptimizationLevel.MEDIUM)
      
      expect(callback1).toHaveBeenCalledWith(OptimizationLevel.MEDIUM)
      expect(callback2).toHaveBeenCalledWith(OptimizationLevel.MEDIUM)
    })
  })

  describe('Engine Integration', () => {
    it('should handle missing render engine methods gracefully', () => {
      const limitedRenderEngine = {
        render: vi.fn(),
        // Missing optimization methods
      } as unknown as RenderEngine
      
      const optimizer = new PerformanceOptimizerImpl(
        mockPerformanceMonitor,
        limitedRenderEngine
      )
      
      // Should not throw error
      expect(() => {
        optimizer.setOptimizationLevel(OptimizationLevel.HIGH)
      }).not.toThrow()
    })

    it('should handle missing audio engine methods gracefully', () => {
      const limitedAudioEngine = {
        start: vi.fn(),
        // Missing optimization methods
      } as unknown as AudioEngine
      
      const optimizer = new PerformanceOptimizerImpl(
        mockPerformanceMonitor,
        undefined,
        limitedAudioEngine
      )
      
      // Should not throw error
      expect(() => {
        optimizer.setOptimizationLevel(OptimizationLevel.HIGH)
      }).not.toThrow()
    })

    it('should handle render engine errors gracefully', () => {
      const errorRenderEngine = {
        setVisualQuality: vi.fn(() => {
          throw new Error('Render error')
        }),
      } as unknown as RenderEngine
      
      const consoleSpy = vi.spyOn(console, 'warn').mockImplementation(() => {})
      
      const optimizer = new PerformanceOptimizerImpl(
        mockPerformanceMonitor,
        errorRenderEngine
      )
      
      optimizer.setOptimizationLevel(OptimizationLevel.LOW)
      
      expect(consoleSpy).toHaveBeenCalledWith(
        'Performance Optimizer: Error applying visual optimizations:',
        expect.any(Error)
      )
      
      consoleSpy.mockRestore()
    })

    it('should handle audio engine errors gracefully', () => {
      const errorAudioEngine = {
        setAudioQuality: vi.fn(() => {
          throw new Error('Audio error')
        }),
      } as unknown as AudioEngine
      
      const consoleSpy = vi.spyOn(console, 'warn').mockImplementation(() => {})
      
      const optimizer = new PerformanceOptimizerImpl(
        mockPerformanceMonitor,
        undefined,
        errorAudioEngine
      )
      
      optimizer.setOptimizationLevel(OptimizationLevel.LOW)
      
      expect(consoleSpy).toHaveBeenCalledWith(
        'Performance Optimizer: Error applying audio optimizations:',
        expect.any(Error)
      )
      
      consoleSpy.mockRestore()
    })

    it('should allow setting engines after construction', () => {
      const optimizer = new PerformanceOptimizerImpl(mockPerformanceMonitor)
      
      optimizer.setRenderEngine(mockRenderEngine)
      optimizer.setAudioEngine(mockAudioEngine)
      
      optimizer.setOptimizationLevel(OptimizationLevel.LOW)
      
      expect(mockRenderEngine.setVisualQuality).toHaveBeenCalled()
      expect(mockAudioEngine.setAudioQuality).toHaveBeenCalled()
    })
  })

  describe('Optimization Settings', () => {
    it('should return current optimization settings', () => {
      performanceOptimizer.setOptimizationLevel(OptimizationLevel.MEDIUM)
      
      const settings = performanceOptimizer.getCurrentSettings()
      
      expect(settings.maxCubes).toBe(15)
      expect(settings.visualQuality).toBe(0.7)
      expect(settings.audioQuality).toBe(0.85)
      expect(settings.shadowsEnabled).toBe(false)
      expect(settings.particlesEnabled).toBe(true)
      expect(settings.antiAliasingEnabled).toBe(false)
      expect(settings.audioBufferSize).toBe(1024)
    })

    it('should return immutable settings copy', () => {
      const settings = performanceOptimizer.getCurrentSettings()
      settings.maxCubes = 999
      
      const newSettings = performanceOptimizer.getCurrentSettings()
      expect(newSettings.maxCubes).not.toBe(999)
    })
  })

  describe('Logging', () => {
    it('should log optimization changes', () => {
      const consoleSpy = vi.spyOn(console, 'info').mockImplementation(() => {})
      
      performanceOptimizer.setOptimizationLevel(OptimizationLevel.HIGH)
      
      expect(consoleSpy).toHaveBeenCalledWith(
        expect.stringContaining('Applied HIGH optimizations:')
      )
      
      consoleSpy.mockRestore()
    })

    it('should log restoration to full quality', () => {
      const consoleSpy = vi.spyOn(console, 'info').mockImplementation(() => {})
      
      performanceOptimizer.setOptimizationLevel(OptimizationLevel.HIGH)
      consoleSpy.mockClear()
      
      performanceOptimizer.setOptimizationLevel(OptimizationLevel.NONE)
      
      expect(consoleSpy).toHaveBeenCalledWith(
        'Performance Optimizer: All optimizations disabled - full quality restored'
      )
      
      consoleSpy.mockRestore()
    })
  })

  describe('Edge Cases', () => {
    it('should handle undefined performance status gracefully', () => {
      expect(() => {
        performanceCallback(undefined as any)
      }).not.toThrow()
    })

    it('should handle extreme performance values', () => {
      const extremePerformance: PerformanceStatus = {
        fps: -10,
        audioLatency: 10000,
        cpuUsage: 200,
        memoryUsage: -50,
        isDegraded: true,
        recommendations: []
      }
      
      expect(() => {
        performanceCallback(extremePerformance)
      }).not.toThrow()
      
      expect(performanceOptimizer.getOptimizationLevel()).toBe(OptimizationLevel.EXTREME)
    })

    it('should handle NaN performance values', () => {
      const nanPerformance: PerformanceStatus = {
        fps: NaN,
        audioLatency: NaN,
        cpuUsage: NaN,
        memoryUsage: NaN,
        isDegraded: false,
        recommendations: []
      }
      
      expect(() => {
        performanceCallback(nanPerformance)
      }).not.toThrow()
    })
  })
})