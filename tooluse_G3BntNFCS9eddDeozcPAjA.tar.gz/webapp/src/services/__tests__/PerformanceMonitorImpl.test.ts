import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest'
import { PerformanceMonitorImpl } from '../PerformanceMonitorImpl'

// Mock performance.now()
const mockPerformanceNow = vi.fn()
Object.defineProperty(global, 'performance', {
  value: {
    now: mockPerformanceNow,
    memory: {
      usedJSHeapSize: 50 * 1024 * 1024 // 50MB
    }
  },
  writable: true
})

// Mock requestAnimationFrame
const mockRequestAnimationFrame = vi.fn()
global.requestAnimationFrame = mockRequestAnimationFrame

// Mock AudioContext
const mockAudioContext = {
  baseLatency: 0.005, // 5ms
  outputLatency: 0.010, // 10ms
} as AudioContext

describe('PerformanceMonitorImpl', () => {
  let performanceMonitor: PerformanceMonitorImpl
  let timeCounter = 0

  beforeEach(() => {
    timeCounter = 0
    mockPerformanceNow.mockImplementation(() => {
      timeCounter += 16.67 // Simulate 60 FPS (16.67ms per frame)
      return timeCounter
    })
    
    mockRequestAnimationFrame.mockImplementation((callback) => {
      setTimeout(callback, 0)
      return 1
    })

    performanceMonitor = new PerformanceMonitorImpl(mockAudioContext, false, false) // Don't auto-start, don't auto-manage
  })

  afterEach(() => {
    vi.clearAllMocks()
  })

  describe('FPS Monitoring', () => {
    it('should calculate FPS correctly', async () => {
      // Manually trigger FPS measurement by calling private method
      ;(performanceMonitor as any).measureFPS()
      ;(performanceMonitor as any).measureFPS()
      ;(performanceMonitor as any).measureFPS()
      
      const fps = performanceMonitor.getFPS()
      
      // Should be close to 60 FPS (allowing for some variance)
      expect(fps).toBeGreaterThan(50)
      expect(fps).toBeLessThan(70)
    })

    it('should return 0 FPS when no frames measured', () => {
      const newMonitor = new PerformanceMonitorImpl(undefined, false, false)
      expect(newMonitor.getFPS()).toBe(0)
    })

    it('should maintain rolling average of FPS', async () => {
      // Simulate varying frame times
      mockPerformanceNow.mockImplementation(() => {
        timeCounter += Math.random() * 20 + 10 // 10-30ms per frame
        return timeCounter
      })

      // Manually trigger FPS measurements
      for (let i = 0; i < 10; i++) {
        ;(performanceMonitor as any).measureFPS()
      }
      
      const fps = performanceMonitor.getFPS()
      expect(fps).toBeGreaterThan(0)
      expect(fps).toBeLessThan(100)
    })
  })

  describe('Audio Latency Monitoring', () => {
    it('should calculate audio latency correctly', () => {
      const latency = performanceMonitor.getAudioLatency()
      
      // Should be (5ms + 10ms) * 1000 = 15ms
      expect(latency).toBe(15)
    })

    it('should return 0 when no audio context', () => {
      const monitorWithoutAudio = new PerformanceMonitorImpl(undefined, false, false)
      expect(monitorWithoutAudio.getAudioLatency()).toBe(0)
    })

    it('should handle missing latency properties', () => {
      const contextWithoutLatency = {} as AudioContext
      performanceMonitor.setAudioContext(contextWithoutLatency)
      
      expect(performanceMonitor.getAudioLatency()).toBe(0)
    })
  })

  describe('CPU Usage Monitoring', () => {
    it('should return CPU usage as a percentage', () => {
      const cpuUsage = performanceMonitor.getCPUUsage()
      
      expect(cpuUsage).toBeGreaterThanOrEqual(0)
      expect(cpuUsage).toBeLessThanOrEqual(100)
    })

    it('should return consistent measurements', () => {
      const usage1 = performanceMonitor.getCPUUsage()
      const usage2 = performanceMonitor.getCPUUsage()
      
      // Should be within reasonable range of each other
      expect(Math.abs(usage1 - usage2)).toBeLessThan(50)
    })
  })

  describe('Memory Usage Monitoring', () => {
    it('should return memory usage in MB', () => {
      const memoryUsage = performanceMonitor.getMemoryUsage()
      
      // Should return 50MB as mocked
      expect(memoryUsage).toBe(50)
    })

    it('should handle missing performance.memory', () => {
      // Remove memory property
      delete (global.performance as any).memory
      
      const newMonitor = new PerformanceMonitorImpl(undefined, false, false)
      const memoryUsage = newMonitor.getMemoryUsage()
      
      expect(memoryUsage).toBeGreaterThanOrEqual(0)
    })
  })

  describe('Performance Status Checking', () => {
    it('should return complete performance status', () => {
      const status = performanceMonitor.checkPerformance()
      
      expect(status).toHaveProperty('fps')
      expect(status).toHaveProperty('audioLatency')
      expect(status).toHaveProperty('cpuUsage')
      expect(status).toHaveProperty('memoryUsage')
      expect(status).toHaveProperty('isDegraded')
      expect(status).toHaveProperty('recommendations')
      
      expect(Array.isArray(status.recommendations)).toBe(true)
    })

    it('should detect low FPS and recommend degradation', () => {
      // Mock very slow frame times (low FPS)
      mockPerformanceNow.mockImplementation(() => {
        timeCounter += 50 // 20 FPS
        return timeCounter
      })

      // Wait for frames to be measured
      setTimeout(() => {
        const status = performanceMonitor.checkPerformance()
        
        expect(status.fps).toBeLessThan(30)
        expect(status.recommendations.length).toBeGreaterThan(0)
        expect(status.recommendations.some(r => r.includes('Critical'))).toBe(true)
      }, 100)
    })

    it('should detect high audio latency', () => {
      // Mock high latency audio context
      const highLatencyContext = {
        baseLatency: 0.030, // 30ms
        outputLatency: 0.025, // 25ms
      } as AudioContext

      performanceMonitor.setAudioContext(highLatencyContext)
      
      const status = performanceMonitor.checkPerformance()
      
      expect(status.audioLatency).toBe(55) // 55ms total
      expect(status.recommendations.some(r => r.includes('latency'))).toBe(true)
    })
  })

  describe('Degraded Mode Management', () => {
    it('should enable degraded mode', () => {
      performanceMonitor.reset() // Reset to ensure clean state
      expect(performanceMonitor.isDegradedMode()).toBe(false)
      
      performanceMonitor.enableDegradedMode()
      
      expect(performanceMonitor.isDegradedMode()).toBe(true)
    })

    it('should disable degraded mode', () => {
      performanceMonitor.reset() // Reset to ensure clean state
      
      // Manually enable degraded mode without triggering checkPerformance
      ;(performanceMonitor as any).isDegraded = true
      expect(performanceMonitor.isDegradedMode()).toBe(true)
      
      performanceMonitor.disableDegradedMode()
      
      expect(performanceMonitor.isDegradedMode()).toBe(false)
    })

    it('should not enable degraded mode if already enabled', () => {
      const consoleSpy = vi.spyOn(console, 'warn').mockImplementation(() => {})
      
      performanceMonitor.enableDegradedMode()
      performanceMonitor.enableDegradedMode() // Second call
      
      expect(consoleSpy).toHaveBeenCalledTimes(1)
      consoleSpy.mockRestore()
    })

    it('should not disable degraded mode if already disabled', () => {
      const consoleSpy = vi.spyOn(console, 'info').mockImplementation(() => {})
      
      performanceMonitor.disableDegradedMode() // Already disabled
      
      expect(consoleSpy).not.toHaveBeenCalled()
      consoleSpy.mockRestore()
    })
  })

  describe('Performance Change Callbacks', () => {
    it('should register and call performance change callbacks', () => {
      const callback = vi.fn()
      
      performanceMonitor.onPerformanceChange(callback)
      performanceMonitor.enableDegradedMode()
      
      expect(callback).toHaveBeenCalled()
      expect(callback).toHaveBeenCalledWith(expect.objectContaining({
        isDegraded: true
      }))
    })

    it('should handle callback errors gracefully', () => {
      const errorCallback = vi.fn(() => {
        throw new Error('Callback error')
      })
      const consoleSpy = vi.spyOn(console, 'error').mockImplementation(() => {})
      
      performanceMonitor.onPerformanceChange(errorCallback)
      performanceMonitor.enableDegradedMode()
      
      expect(consoleSpy).toHaveBeenCalledWith('Error in performance callback:', expect.any(Error))
      consoleSpy.mockRestore()
    })

    it('should call multiple callbacks', () => {
      const callback1 = vi.fn()
      const callback2 = vi.fn()
      
      performanceMonitor.onPerformanceChange(callback1)
      performanceMonitor.onPerformanceChange(callback2)
      performanceMonitor.enableDegradedMode()
      
      expect(callback1).toHaveBeenCalled()
      expect(callback2).toHaveBeenCalled()
    })
  })

  describe('Threshold Detection', () => {
    it('should detect FPS warning threshold', async () => {
      // Mock FPS around warning threshold (45 FPS)
      mockPerformanceNow.mockImplementation(() => {
        timeCounter += 22 // ~45 FPS
        return timeCounter
      })

      await new Promise(resolve => setTimeout(resolve, 100))
      
      const status = performanceMonitor.checkPerformance()
      
      expect(status.recommendations.some(r => r.includes('Warning'))).toBe(true)
    })

    it('should detect FPS critical threshold', async () => {
      // Create a monitor with auto-management enabled for this test
      const autoMonitor = new PerformanceMonitorImpl(mockAudioContext, false, true)
      
      // Mock FPS below critical threshold (30 FPS)
      mockPerformanceNow.mockImplementation(() => {
        timeCounter += 40 // ~25 FPS
        return timeCounter
      })

      // Manually trigger FPS measurements
      for (let i = 0; i < 10; i++) {
        ;(autoMonitor as any).measureFPS()
      }
      
      const status = autoMonitor.checkPerformance()
      
      expect(status.recommendations.some(r => r.includes('Critical'))).toBe(true)
      expect(autoMonitor.isDegradedMode()).toBe(true)
    })

    it('should auto-recover from degraded mode', async () => {
      // Create a monitor with auto-management enabled for this test
      const autoMonitor = new PerformanceMonitorImpl(mockAudioContext, false, true)
      
      // First, trigger degraded mode with poor performance
      mockPerformanceNow.mockImplementation(() => {
        timeCounter += 40 // ~25 FPS
        return timeCounter
      })

      // Manually trigger FPS measurements to simulate poor performance
      for (let i = 0; i < 10; i++) {
        ;(autoMonitor as any).measureFPS()
      }
      
      autoMonitor.checkPerformance()
      expect(autoMonitor.isDegradedMode()).toBe(true)

      // Then improve performance - don't reset, just change the mock
      timeCounter = 1000 // Reset time counter but keep history
      mockPerformanceNow.mockImplementation(() => {
        timeCounter += 16.67 // 60 FPS
        return timeCounter
      })

      // Clear FPS history and add good measurements
      ;(autoMonitor as any).fpsHistory = []
      
      // Manually trigger FPS measurements to simulate good performance
      for (let i = 0; i < 10; i++) {
        ;(autoMonitor as any).measureFPS()
      }
      
      // Mock getCPUUsage to return low usage
      const originalGetCPUUsage = autoMonitor.getCPUUsage
      autoMonitor.getCPUUsage = vi.fn().mockReturnValue(30) // Low CPU usage
      
      autoMonitor.checkPerformance()
      
      expect(autoMonitor.isDegradedMode()).toBe(false)
      
      // Restore original method
      autoMonitor.getCPUUsage = originalGetCPUUsage
    })
  })

  describe('Utility Methods', () => {
    it('should reset performance history', () => {
      performanceMonitor.enableDegradedMode()
      
      performanceMonitor.reset()
      
      expect(performanceMonitor.getFPS()).toBe(0)
      expect(performanceMonitor.isDegradedMode()).toBe(false)
    })

    it('should update audio context', () => {
      const newContext = {
        baseLatency: 0.020,
        outputLatency: 0.015,
      } as AudioContext

      performanceMonitor.setAudioContext(newContext)
      
      expect(performanceMonitor.getAudioLatency()).toBe(35) // 35ms
    })
  })

  describe('Integration with Performance API', () => {
    it('should handle performance.now() variations', () => {
      let callCount = 0
      mockPerformanceNow.mockImplementation(() => {
        callCount++
        return callCount * 16.67 + Math.random() * 2 // Add some jitter
      })

      const fps = performanceMonitor.getFPS()
      expect(typeof fps).toBe('number')
      expect(fps).toBeGreaterThanOrEqual(0)
    })

    it('should work without performance.memory', () => {
      const originalMemory = (global.performance as any).memory
      delete (global.performance as any).memory

      const newMonitor = new PerformanceMonitorImpl(undefined, false, false)
      const memoryUsage = newMonitor.getMemoryUsage()

      expect(typeof memoryUsage).toBe('number')
      expect(memoryUsage).toBeGreaterThanOrEqual(0)

      // Restore
      ;(global.performance as any).memory = originalMemory
    })
  })
})