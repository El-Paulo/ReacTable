import { describe, it, expect, beforeEach } from 'vitest'
import { ProjectSerializer } from '../ProjectSerializer'
import { 
  AppState, 
  CubeInstance, 
  Connection, 
  CubeType, 
  ProjectSchema,
  SerializedCube,
  SerializedConnection
} from '@/types'
import { Vector3 } from 'three'

describe('ProjectSerializer', () => {
  let mockAppState: AppState
  let mockCube1: CubeInstance
  let mockCube2: CubeInstance
  let mockConnection: Connection

  beforeEach(() => {
    mockCube1 = {
      id: 'cube-1',
      type: CubeType.OSCILLATOR,
      transform: {
        position: new Vector3(1, 2, 3),
        rotation: new Vector3(0.1, 0.2, 0.3),
        scale: new Vector3(1, 1, 1)
      },
      audioNodeId: 'audio-1',
      isActive: true,
      parameters: {
        frequency: 440,
        detune: 0
      }
    }

    mockCube2 = {
      id: 'cube-2',
      type: CubeType.FILTER,
      transform: {
        position: new Vector3(4, 5, 6),
        rotation: new Vector3(0.4, 0.5, 0.6),
        scale: new Vector3(1.5, 1.5, 1.5)
      },
      audioNodeId: 'audio-2',
      isActive: false,
      parameters: {
        cutoff: 1000,
        resonance: 1
      }
    }

    mockConnection = {
      id: 'connection-1',
      fromCubeId: 'cube-1',
      toCubeId: 'cube-2',
      strength: 0.8,
      isActive: true
    }

    mockAppState = {
      isAudioStarted: true,
      cubes: new Map([
        ['cube-1', mockCube1],
        ['cube-2', mockCube2]
      ]),
      connections: [mockConnection],
      selectedCube: 'cube-1',
      isRecording: false
    }
  })

  describe('serialize', () => {
    it('should serialize app state to project schema', () => {
      const result = ProjectSerializer.serialize(mockAppState, {
        name: 'Test Project',
        author: 'Test Author'
      })

      expect(result.version).toBe('1.0.0')
      expect(result.metadata.name).toBe('Test Project')
      expect(result.metadata.author).toBe('Test Author')
      expect(result.metadata.created).toBeDefined()
      expect(result.metadata.modified).toBeDefined()
      expect(result.cubes).toHaveLength(2)
      expect(result.connections).toHaveLength(1)
      expect(result.settings).toBeDefined()
    })

    it('should use default metadata when not provided', () => {
      const result = ProjectSerializer.serialize(mockAppState)

      expect(result.metadata.name).toBe('Untitled Project')
      expect(result.metadata.author).toBeUndefined()
    })

    it('should serialize cubes correctly', () => {
      const result = ProjectSerializer.serialize(mockAppState)
      const serializedCube1 = result.cubes.find(c => c.id === 'cube-1')!

      expect(serializedCube1.type).toBe(CubeType.OSCILLATOR)
      expect(serializedCube1.position).toEqual([1, 2, 3])
      expect(serializedCube1.rotation).toEqual([0.1, 0.2, 0.3])
      expect(serializedCube1.scale).toEqual([1, 1, 1])
      expect(serializedCube1.parameters).toEqual({
        frequency: 440,
        detune: 0
      })
    })

    it('should serialize connections correctly', () => {
      const result = ProjectSerializer.serialize(mockAppState)
      const serializedConnection = result.connections[0]

      expect(serializedConnection.id).toBe('connection-1')
      expect(serializedConnection.fromCubeId).toBe('cube-1')
      expect(serializedConnection.toCubeId).toBe('cube-2')
    })

    it('should use default settings when not provided', () => {
      const result = ProjectSerializer.serialize(mockAppState)

      expect(result.settings.masterVolume).toBe(0.5)
      expect(result.settings.tempo).toBe(120)
      expect(result.settings.scale).toBe('C Major')
    })
  })

  describe('deserialize', () => {
    let mockProjectSchema: ProjectSchema

    beforeEach(() => {
      mockProjectSchema = {
        version: '1.0.0',
        metadata: {
          name: 'Test Project',
          created: '2024-01-01T00:00:00.000Z',
          modified: '2024-01-01T00:00:00.000Z',
          author: 'Test Author'
        },
        cubes: [
          {
            id: 'cube-1',
            type: CubeType.OSCILLATOR,
            position: [1, 2, 3],
            rotation: [0.1, 0.2, 0.3],
            scale: [1, 1, 1],
            parameters: { frequency: 440, detune: 0 }
          },
          {
            id: 'cube-2',
            type: CubeType.FILTER,
            position: [4, 5, 6],
            rotation: [0.4, 0.5, 0.6],
            scale: [1.5, 1.5, 1.5],
            parameters: { cutoff: 1000, resonance: 1 }
          }
        ],
        connections: [
          {
            id: 'connection-1',
            fromCubeId: 'cube-1',
            toCubeId: 'cube-2'
          }
        ],
        settings: {
          masterVolume: 0.7,
          tempo: 140,
          scale: 'A Minor'
        }
      }
    })

    it('should deserialize project schema to app state components', () => {
      const result = ProjectSerializer.deserialize(mockProjectSchema)

      expect(result.cubes.size).toBe(2)
      expect(result.connections).toHaveLength(1)
      expect(result.settings).toBeDefined()
    })

    it('should deserialize cubes correctly', () => {
      const result = ProjectSerializer.deserialize(mockProjectSchema)
      const cube1 = result.cubes.get('cube-1')!

      expect(cube1.id).toBe('cube-1')
      expect(cube1.type).toBe(CubeType.OSCILLATOR)
      expect(cube1.transform.position.toArray()).toEqual([1, 2, 3])
      expect(cube1.transform.rotation.toArray()).toEqual([0.1, 0.2, 0.3])
      expect(cube1.transform.scale.toArray()).toEqual([1, 1, 1])
      expect(cube1.parameters).toEqual({ frequency: 440, detune: 0 })
      expect(cube1.audioNodeId).toBe('') // Should be empty for regeneration
      expect(cube1.isActive).toBe(false) // Should be false initially
    })

    it('should deserialize connections correctly', () => {
      const result = ProjectSerializer.deserialize(mockProjectSchema)
      const connection = result.connections[0]

      expect(connection.id).toBe('connection-1')
      expect(connection.fromCubeId).toBe('cube-1')
      expect(connection.toCubeId).toBe('cube-2')
      expect(connection.strength).toBe(1.0) // Default value
      expect(connection.isActive).toBe(true) // Default value
    })

    it('should preserve settings', () => {
      const result = ProjectSerializer.deserialize(mockProjectSchema)

      expect(result.settings.masterVolume).toBe(0.7)
      expect(result.settings.tempo).toBe(140)
      expect(result.settings.scale).toBe('A Minor')
    })
  })

  describe('validateSchema', () => {
    it('should validate correct schema without throwing', () => {
      const validSchema: ProjectSchema = {
        version: '1.0.0',
        metadata: {
          name: 'Valid Project',
          created: '2024-01-01T00:00:00.000Z',
          modified: '2024-01-01T00:00:00.000Z'
        },
        cubes: [],
        connections: [],
        settings: {
          masterVolume: 0.5,
          tempo: 120,
          scale: 'C Major'
        }
      }

      expect(() => ProjectSerializer.validateSchema(validSchema)).not.toThrow()
    })

    it('should throw for null or undefined data', () => {
      expect(() => ProjectSerializer.validateSchema(null)).toThrow('Invalid project data: must be an object')
      expect(() => ProjectSerializer.validateSchema(undefined)).toThrow('Invalid project data: must be an object')
    })

    it('should throw for missing version', () => {
      const invalidSchema = {
        metadata: { name: 'Test' },
        cubes: [],
        connections: [],
        settings: {}
      }

      expect(() => ProjectSerializer.validateSchema(invalidSchema)).toThrow('missing or invalid version')
    })

    it('should throw for missing metadata', () => {
      const invalidSchema = {
        version: '1.0.0',
        cubes: [],
        connections: [],
        settings: {}
      }

      expect(() => ProjectSerializer.validateSchema(invalidSchema)).toThrow('missing or invalid metadata')
    })

    it('should throw for invalid cube type', () => {
      const invalidSchema = {
        version: '1.0.0',
        metadata: { name: 'Test', created: '2024-01-01', modified: '2024-01-01' },
        cubes: [{
          id: 'cube-1',
          type: 'invalid-type',
          position: [0, 0, 0],
          rotation: [0, 0, 0],
          scale: [1, 1, 1],
          parameters: {}
        }],
        connections: [],
        settings: {}
      }

      expect(() => ProjectSerializer.validateSchema(invalidSchema)).toThrow('invalid type "invalid-type"')
    })

    it('should throw for invalid position array', () => {
      const invalidSchema = {
        version: '1.0.0',
        metadata: { name: 'Test', created: '2024-01-01', modified: '2024-01-01' },
        cubes: [{
          id: 'cube-1',
          type: CubeType.OSCILLATOR,
          position: [0, 0], // Missing third element
          rotation: [0, 0, 0],
          scale: [1, 1, 1],
          parameters: {}
        }],
        connections: [],
        settings: {}
      }

      expect(() => ProjectSerializer.validateSchema(invalidSchema)).toThrow('position must be array of 3 numbers')
    })

    it('should throw for non-finite numbers in position', () => {
      const invalidSchema = {
        version: '1.0.0',
        metadata: { name: 'Test', created: '2024-01-01', modified: '2024-01-01' },
        cubes: [{
          id: 'cube-1',
          type: CubeType.OSCILLATOR,
          position: [0, NaN, 0],
          rotation: [0, 0, 0],
          scale: [1, 1, 1],
          parameters: {}
        }],
        connections: [],
        settings: {}
      }

      expect(() => ProjectSerializer.validateSchema(invalidSchema)).toThrow('position[1] must be a finite number')
    })

    it('should throw for unsupported version', () => {
      const invalidSchema = {
        version: '2.0.0', // Unsupported version
        metadata: { name: 'Test', created: '2024-01-01', modified: '2024-01-01' },
        cubes: [],
        connections: [],
        settings: {}
      }

      expect(() => ProjectSerializer.deserialize(invalidSchema as any)).toThrow('Unsupported project version: 2.0.0')
    })
  })

  describe('utility methods', () => {
    it('should clone project data correctly', () => {
      const original: ProjectSchema = {
        version: '1.0.0',
        metadata: {
          name: 'Original',
          created: '2024-01-01T00:00:00.000Z',
          modified: '2024-01-01T00:00:00.000Z'
        },
        cubes: [],
        connections: [],
        settings: {
          masterVolume: 0.5,
          tempo: 120,
          scale: 'C Major'
        }
      }

      const cloned = ProjectSerializer.cloneProjectData(original)
      
      expect(cloned).toEqual(original)
      expect(cloned).not.toBe(original) // Different object reference
      expect(cloned.metadata).not.toBe(original.metadata) // Deep clone
    })

    it('should generate unique project IDs', () => {
      const id1 = ProjectSerializer.generateProjectId()
      const id2 = ProjectSerializer.generateProjectId()

      expect(id1).toMatch(/^project-[a-z0-9]+-[a-z0-9]+$/)
      expect(id2).toMatch(/^project-[a-z0-9]+-[a-z0-9]+$/)
      expect(id1).not.toBe(id2)
    })
  })

  describe('round-trip serialization', () => {
    it('should maintain data integrity through serialize -> deserialize cycle', () => {
      // Serialize the mock state
      const serialized = ProjectSerializer.serialize(mockAppState, {
        name: 'Round Trip Test',
        author: 'Test'
      })

      // Deserialize it back
      const deserialized = ProjectSerializer.deserialize(serialized)

      // Check that cube data is preserved
      const originalCube1 = mockAppState.cubes.get('cube-1')!
      const deserializedCube1 = deserialized.cubes.get('cube-1')!

      expect(deserializedCube1.id).toBe(originalCube1.id)
      expect(deserializedCube1.type).toBe(originalCube1.type)
      expect(deserializedCube1.transform.position.toArray()).toEqual(
        originalCube1.transform.position.toArray()
      )
      expect(deserializedCube1.transform.rotation.toArray()).toEqual(
        originalCube1.transform.rotation.toArray()
      )
      expect(deserializedCube1.transform.scale.toArray()).toEqual(
        originalCube1.transform.scale.toArray()
      )
      expect(deserializedCube1.parameters).toEqual(originalCube1.parameters)

      // Check that connection data is preserved
      const originalConnection = mockAppState.connections[0]
      const deserializedConnection = deserialized.connections[0]

      expect(deserializedConnection.id).toBe(originalConnection.id)
      expect(deserializedConnection.fromCubeId).toBe(originalConnection.fromCubeId)
      expect(deserializedConnection.toCubeId).toBe(originalConnection.toCubeId)
    })
  })
})