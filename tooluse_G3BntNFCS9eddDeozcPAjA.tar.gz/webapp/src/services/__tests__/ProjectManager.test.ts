import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest'
import { ProjectManager } from '../ProjectManager'
import { AppState, CubeInstance, CubeType, ErrorType } from '@/types'
import { Vector3 } from 'three'

// Mock localStorage
const localStorageMock = (() => {
  let store: Record<string, string> = {}
  
  return {
    getItem: (key: string) => store[key] || null,
    setItem: (key: string, value: string) => {
      store[key] = value
    },
    removeItem: (key: string) => {
      delete store[key]
    },
    clear: () => {
      store = {}
    },
    get length() {
      return Object.keys(store).length
    },
    key: (index: number) => Object.keys(store)[index] || null
  }
})()

Object.defineProperty(window, 'localStorage', {
  value: localStorageMock
})

// Mock URL.createObjectURL and revokeObjectURL
Object.defineProperty(window.URL, 'createObjectURL', {
  value: vi.fn(() => 'mock-url')
})

Object.defineProperty(window.URL, 'revokeObjectURL', {
  value: vi.fn()
})

// Mock FileReader
class MockFileReader {
  onload: ((event: any) => void) | null = null
  onerror: (() => void) | null = null
  
  readAsText(file: File) {
    setTimeout(() => {
      if (file.name.includes('invalid')) {
        this.onerror?.()
      } else {
        const mockContent = JSON.stringify({
          version: '1.0.0',
          metadata: {
            name: 'Imported Project',
            created: '2024-01-01T00:00:00.000Z',
            modified: '2024-01-01T00:00:00.000Z'
          },
          cubes: [],
          connections: [],
          settings: {
            masterVolume: 0.5,
            tempo: 120,
            scale: 'C Major'
          }
        })
        
        this.onload?.({ target: { result: mockContent } })
      }
    }, 0)
  }
}

Object.defineProperty(window, 'FileReader', {
  value: MockFileReader
})

describe('ProjectManager', () => {
  let projectManager: ProjectManager
  let mockErrorHandler: ReturnType<typeof vi.fn>
  let mockAppState: AppState

  beforeEach(() => {
    localStorageMock.clear()
    mockErrorHandler = vi.fn()
    projectManager = new ProjectManager(mockErrorHandler)
    
    const mockCube: CubeInstance = {
      id: 'cube-1',
      type: CubeType.OSCILLATOR,
      transform: {
        position: new Vector3(1, 2, 3),
        rotation: new Vector3(0.1, 0.2, 0.3),
        scale: new Vector3(1, 1, 1)
      },
      audioNodeId: 'audio-1',
      isActive: true,
      parameters: { frequency: 440 }
    }

    mockAppState = {
      isAudioStarted: true,
      cubes: new Map([['cube-1', mockCube]]),
      connections: [],
      selectedCube: 'cube-1',
      isRecording: false
    }
  })

  afterEach(() => {
    projectManager.destroy()
  })

  describe('saveCurrentProject', () => {
    it('should save project to localStorage', () => {
      const projectId = projectManager.saveCurrentProject(mockAppState, {
        name: 'Test Project',
        author: 'Test Author'
      })

      expect(projectId).toBeDefined()
      expect(localStorageMock.getItem('reactable-current-project')).toBeTruthy()
      
      const savedData = JSON.parse(localStorageMock.getItem('reactable-current-project')!)
      expect(savedData.metadata.name).toBe('Test Project')
      expect(savedData.metadata.author).toBe('Test Author')
    })

    it('should update projects list', () => {
      projectManager.saveCurrentProject(mockAppState, { name: 'Test Project' })
      
      const projectsList = projectManager.getProjectsList()
      expect(projectsList).toHaveLength(1)
      expect(projectsList[0].name).toBe('Test Project')
    })

    it('should use default name if not provided', () => {
      projectManager.saveCurrentProject(mockAppState)
      
      const savedData = JSON.parse(localStorageMock.getItem('reactable-current-project')!)
      expect(savedData.metadata.name).toBe('Current Project')
    })

    it('should handle save errors', () => {
      // Mock localStorage to throw an error
      const originalSetItem = localStorageMock.setItem
      localStorageMock.setItem = vi.fn(() => {
        throw new Error('Storage quota exceeded')
      })

      expect(() => {
        projectManager.saveCurrentProject(mockAppState)
      }).toThrow('Storage quota exceeded')

      expect(mockErrorHandler).toHaveBeenCalledWith(
        ErrorType.INVALID_PROJECT_FILE,
        expect.stringContaining('Failed to save project')
      )

      // Restore original method
      localStorageMock.setItem = originalSetItem
    })
  })

  describe('loadCurrentProject', () => {
    it('should load project from localStorage', () => {
      // First save a project
      projectManager.saveCurrentProject(mockAppState, { name: 'Test Project' })
      
      // Then load it
      const loadedProject = projectManager.loadCurrentProject()
      
      expect(loadedProject).toBeTruthy()
      expect(loadedProject!.metadata.name).toBe('Test Project')
      expect(loadedProject!.cubes.size).toBe(1)
      expect(loadedProject!.cubes.get('cube-1')?.type).toBe(CubeType.OSCILLATOR)
    })

    it('should return null if no saved project exists', () => {
      const loadedProject = projectManager.loadCurrentProject()
      expect(loadedProject).toBeNull()
    })

    it('should handle load errors', () => {
      // Save invalid JSON
      localStorageMock.setItem('reactable-current-project', 'invalid json')
      
      const loadedProject = projectManager.loadCurrentProject()
      
      expect(loadedProject).toBeNull()
      expect(mockErrorHandler).toHaveBeenCalledWith(
        ErrorType.INVALID_PROJECT_FILE,
        expect.stringContaining('Failed to load project')
      )
    })
  })

  describe('exportProject', () => {
    it('should create download link for project export', () => {
      const createElementSpy = vi.spyOn(document, 'createElement')
      const appendChildSpy = vi.spyOn(document.body, 'appendChild')
      const removeChildSpy = vi.spyOn(document.body, 'removeChild')
      
      const mockLink = {
        href: '',
        download: '',
        click: vi.fn()
      } as any
      
      createElementSpy.mockReturnValue(mockLink)
      appendChildSpy.mockImplementation(() => mockLink)
      removeChildSpy.mockImplementation(() => mockLink)

      projectManager.exportProject(mockAppState, 'test-export.json', {
        name: 'Export Test'
      })

      expect(createElementSpy).toHaveBeenCalledWith('a')
      expect(mockLink.download).toBe('test-export.json')
      expect(mockLink.click).toHaveBeenCalled()
      expect(appendChildSpy).toHaveBeenCalledWith(mockLink)
      expect(removeChildSpy).toHaveBeenCalledWith(mockLink)

      createElementSpy.mockRestore()
      appendChildSpy.mockRestore()
      removeChildSpy.mockRestore()
    })

    it('should generate filename from project name if not provided', () => {
      const createElementSpy = vi.spyOn(document, 'createElement')
      const mockLink = { href: '', download: '', click: vi.fn() } as any
      createElementSpy.mockReturnValue(mockLink)
      
      vi.spyOn(document.body, 'appendChild').mockImplementation(() => mockLink)
      vi.spyOn(document.body, 'removeChild').mockImplementation(() => mockLink)

      projectManager.exportProject(mockAppState, undefined, {
        name: 'My Test Project!'
      })

      expect(mockLink.download).toBe('my_test_project_.json')

      createElementSpy.mockRestore()
    })
  })

  describe('importProject', () => {
    it('should import project from file', async () => {
      const mockFile = new File([''], 'test.json', { type: 'application/json' })
      
      const importedProject = await projectManager.importProject(mockFile)
      
      expect(importedProject).toBeTruthy()
      expect(importedProject.metadata.name).toBe('Imported Project')
      expect(localStorageMock.getItem('reactable-current-project')).toBeTruthy()
    })

    it('should handle import errors', async () => {
      const mockFile = new File([''], 'invalid.json', { type: 'application/json' })
      
      await expect(projectManager.importProject(mockFile)).rejects.toThrow()
      expect(mockErrorHandler).toHaveBeenCalledWith(
        ErrorType.INVALID_PROJECT_FILE,
        'Failed to read file'
      )
    })
  })

  describe('createNewProject', () => {
    it('should create new empty project', () => {
      const projectId = projectManager.createNewProject('New Test Project')
      
      expect(projectId).toBeDefined()
      expect(projectManager.getCurrentProjectId()).toBe(projectId)
      
      const savedData = JSON.parse(localStorageMock.getItem('reactable-current-project')!)
      expect(savedData.metadata.name).toBe('New Test Project')
      expect(savedData.cubes).toHaveLength(0)
      expect(savedData.connections).toHaveLength(0)
    })

    it('should use default name if not provided', () => {
      projectManager.createNewProject()
      
      const savedData = JSON.parse(localStorageMock.getItem('reactable-current-project')!)
      expect(savedData.metadata.name).toBe('New Project')
    })
  })

  describe('projects list management', () => {
    it('should maintain list of projects', () => {
      // Create separate project managers to avoid ID conflicts
      const pm1 = new ProjectManager()
      const pm2 = new ProjectManager()
      
      pm1.saveCurrentProject(mockAppState, { name: 'Project 1' })
      pm2.saveCurrentProject(mockAppState, { name: 'Project 2' })
      
      const projectsList = projectManager.getProjectsList()
      expect(projectsList).toHaveLength(2)
      expect(projectsList.map(p => p.name)).toContain('Project 1')
      expect(projectsList.map(p => p.name)).toContain('Project 2')
    })

    it('should limit projects list to 10 items', () => {
      // Create 12 projects with different managers to avoid ID conflicts
      for (let i = 1; i <= 12; i++) {
        const pm = new ProjectManager()
        pm.saveCurrentProject(mockAppState, { name: `Project ${i}` })
      }
      
      const projectsList = projectManager.getProjectsList()
      expect(projectsList).toHaveLength(10)
    })

    it('should delete project from list', () => {
      const projectId = projectManager.saveCurrentProject(mockAppState, { name: 'To Delete' })
      
      expect(projectManager.getProjectsList()).toHaveLength(1)
      
      projectManager.deleteProject(projectId)
      
      expect(projectManager.getProjectsList()).toHaveLength(0)
      expect(projectManager.getCurrentProjectId()).toBeNull()
    })
  })

  describe('auto-save functionality', () => {
    it('should start and stop auto-save', () => {
      const getStateMock = vi.fn(() => mockAppState)
      
      projectManager.startAutoSave(getStateMock)
      expect(projectManager['autoSaveTimer']).toBeTruthy()
      
      projectManager.stopAutoSave()
      expect(projectManager['autoSaveTimer']).toBeNull()
    })

    it('should auto-save at intervals', async () => {
      vi.useFakeTimers()
      
      const getStateMock = vi.fn(() => mockAppState)
      
      // First save to establish current project
      projectManager.saveCurrentProject(mockAppState, { name: 'Auto Save Test' })
      
      projectManager.startAutoSave(getStateMock)
      
      // Fast-forward time to trigger auto-save
      vi.advanceTimersByTime(30000)
      
      expect(getStateMock).toHaveBeenCalled()
      
      vi.useRealTimers()
    })
  })

  describe('utility methods', () => {
    it('should check if saved project exists', () => {
      expect(projectManager.hasSavedProject()).toBe(false)
      
      projectManager.saveCurrentProject(mockAppState)
      
      expect(projectManager.hasSavedProject()).toBe(true)
    })

    it('should clear all projects', () => {
      projectManager.saveCurrentProject(mockAppState, { name: 'Test' })
      
      expect(projectManager.hasSavedProject()).toBe(true)
      expect(projectManager.getProjectsList()).toHaveLength(1)
      
      projectManager.clearAllProjects()
      
      expect(projectManager.hasSavedProject()).toBe(false)
      expect(projectManager.getProjectsList()).toHaveLength(0)
      expect(projectManager.getCurrentProjectId()).toBeNull()
    })

    it('should get storage info', () => {
      const storageInfo = projectManager.getStorageInfo()
      
      expect(storageInfo).toHaveProperty('used')
      expect(storageInfo).toHaveProperty('available')
      expect(storageInfo).toHaveProperty('percentage')
      expect(typeof storageInfo.used).toBe('number')
      expect(typeof storageInfo.available).toBe('number')
      expect(typeof storageInfo.percentage).toBe('number')
    })
  })

  describe('error handling', () => {
    it('should handle localStorage errors gracefully', () => {
      // Mock localStorage to throw quota exceeded error
      const originalSetItem = localStorageMock.setItem
      localStorageMock.setItem = vi.fn(() => {
        throw new Error('QuotaExceededError')
      })

      expect(() => {
        projectManager.saveCurrentProject(mockAppState)
      }).toThrow()

      expect(mockErrorHandler).toHaveBeenCalledWith(
        ErrorType.INVALID_PROJECT_FILE,
        expect.stringContaining('Failed to save project')
      )

      // Restore
      localStorageMock.setItem = originalSetItem
    })

    it('should handle corrupted projects list', () => {
      // Save corrupted projects list
      localStorageMock.setItem('reactable-projects-list', 'invalid json')
      
      const projectsList = projectManager.getProjectsList()
      expect(projectsList).toEqual([])
    })
  })
})