import { ErrorHandler } from '@/interfaces/ErrorHandler'
import { ErrorType } from '@/types'
import { NotificationSystem } from '@/ui/NotificationSystem'

interface ErrorDetails {
  message: string
  originalError?: any
  timestamp: number
  userAgent?: string
  url?: string
}

interface RecoveryStrategy {
  canRecover: boolean
  recoveryAction?: () => Promise<boolean>
  fallbackAction?: () => void
  userGuidance?: string
}

export class ErrorHandlerImpl implements ErrorHandler {
  private errorCallbacks: ((error: ErrorType, details?: any) => void)[] = []
  private errorHistory: Map<ErrorType, ErrorDetails[]> = new Map()
  private recoveryAttempts: Map<ErrorType, number> = new Map()
  private maxRecoveryAttempts = 3
  private notificationSystem: NotificationSystem

  constructor(notificationSystem?: NotificationSystem) {
    this.notificationSystem = notificationSystem || new NotificationSystem({
      onNotificationClicked: (notification) => {
        console.log('Notification clicked:', notification.id)
      }
    })
  }

  handleError(error: ErrorType, details?: any): void {
    const errorDetails: ErrorDetails = {
      message: this.getErrorMessage(error),
      originalError: details,
      timestamp: Date.now(),
      userAgent: navigator.userAgent,
      url: window.location.href
    }

    // Store error in history
    if (!this.errorHistory.has(error)) {
      this.errorHistory.set(error, [])
    }
    this.errorHistory.get(error)!.push(errorDetails)

    // Log error for debugging
    console.error(`[ErrorHandler] ${error}:`, errorDetails)

    // Notify error callbacks
    this.errorCallbacks.forEach(callback => {
      try {
        callback(error, details)
      } catch (callbackError) {
        console.error('Error in error callback:', callbackError)
      }
    })

    // Show user message with appropriate notification
    this.showErrorNotification(error, errorDetails)

    // Attempt automatic recovery if possible
    this.attemptRecovery(error).catch(recoveryError => {
      console.error('Recovery attempt failed:', recoveryError)
    })
  }

  showUserMessage(message: string, type: 'error' | 'warning' | 'info'): void {
    // Use notification system for user messages
    switch (type) {
      case 'error':
        this.notificationSystem.error(message)
        break
      case 'warning':
        this.notificationSystem.warning(message)
        break
      case 'info':
        this.notificationSystem.info(message)
        break
    }
    
    // Also log to console for debugging
    const prefix = type.toUpperCase()
    console.log(`[${prefix}] ${message}`)
  }

  async attemptRecovery(error: ErrorType): Promise<boolean> {
    const attempts = this.recoveryAttempts.get(error) || 0
    
    if (attempts >= this.maxRecoveryAttempts) {
      console.warn(`Max recovery attempts reached for ${error}`)
      return false
    }

    this.recoveryAttempts.set(error, attempts + 1)

    const strategy = this.getRecoveryStrategy(error)
    
    if (!strategy.canRecover) {
      if (strategy.fallbackAction) {
        strategy.fallbackAction()
      }
      return false
    }

    if (strategy.recoveryAction) {
      try {
        const success = await strategy.recoveryAction()
        if (success) {
          this.recoveryAttempts.set(error, 0) // Reset attempts on success
          this.notificationSystem.success('System recovered successfully')
        }
        return success
      } catch (recoveryError) {
        console.error(`Recovery action failed for ${error}:`, recoveryError)
        return false
      }
    }

    return false
  }

  onError(callback: (error: ErrorType, details?: any) => void): void {
    this.errorCallbacks.push(callback)
  }

  // Additional methods for comprehensive error handling

  checkBrowserCompatibility(): { isCompatible: boolean; issues: string[] } {
    const issues: string[] = []

    // Check Web Audio API support
    if (!window.AudioContext && !(window as any).webkitAudioContext) {
      issues.push('Web Audio API not supported')
    }

    // Check WebGL support
    const canvas = document.createElement('canvas')
    const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl')
    if (!gl) {
      issues.push('WebGL not supported')
    }

    // Check MediaRecorder support
    if (!window.MediaRecorder) {
      issues.push('Audio recording not supported')
    }

    // Check for required ES6+ features
    try {
      eval('const test = () => {}; class Test {}; new Map(); new Set();')
    } catch (e) {
      issues.push('Modern JavaScript features not supported')
    }

    return {
      isCompatible: issues.length === 0,
      issues
    }
  }

  detectWebGLCapabilities(): { 
    hasWebGL: boolean
    hasWebGL2: boolean
    maxTextureSize: number
    extensions: string[]
  } {
    const canvas = document.createElement('canvas')
    const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl') as WebGLRenderingContext | null
    const gl2 = canvas.getContext('webgl2')

    if (!gl) {
      return {
        hasWebGL: false,
        hasWebGL2: false,
        maxTextureSize: 0,
        extensions: []
      }
    }

    const extensions = gl.getSupportedExtensions() || []
    const maxTextureSize = gl.getParameter(gl.MAX_TEXTURE_SIZE)

    return {
      hasWebGL: true,
      hasWebGL2: !!gl2,
      maxTextureSize,
      extensions
    }
  }

  async checkAudioPermissions(): Promise<{ 
    hasPermission: boolean
    canRequestPermission: boolean
    error?: string
  }> {
    try {
      // Try to create audio context
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext
      if (!AudioContextClass) {
        return {
          hasPermission: false,
          canRequestPermission: false,
          error: 'Web Audio API not supported'
        }
      }

      const audioContext = new AudioContextClass()
      
      // Check if context starts in suspended state (requires user gesture)
      if (audioContext.state === 'suspended') {
        await audioContext.close()
        return {
          hasPermission: false,
          canRequestPermission: true,
          error: 'Audio requires user interaction to start'
        }
      }

      await audioContext.close()
      return {
        hasPermission: true,
        canRequestPermission: true
      }
    } catch (error) {
      return {
        hasPermission: false,
        canRequestPermission: false,
        error: `Audio permission check failed: ${error}`
      }
    }
  }

  getErrorHistory(errorType?: ErrorType): ErrorDetails[] {
    if (errorType) {
      return this.errorHistory.get(errorType) || []
    }
    
    const allErrors: ErrorDetails[] = []
    this.errorHistory.forEach(errors => allErrors.push(...errors))
    return allErrors.sort((a, b) => b.timestamp - a.timestamp)
  }

  clearErrorHistory(errorType?: ErrorType): void {
    if (errorType) {
      this.errorHistory.delete(errorType)
      this.recoveryAttempts.delete(errorType)
    } else {
      this.errorHistory.clear()
      this.recoveryAttempts.clear()
    }
  }

  getNotificationSystem(): NotificationSystem {
    return this.notificationSystem
  }

  destroy(): void {
    this.notificationSystem.destroy()
    this.clearErrorHistory()
    this.errorCallbacks.length = 0
  }

  private getErrorMessage(error: ErrorType): string {
    const messages: Record<ErrorType, string> = {
      [ErrorType.AUDIO_CONTEXT_FAILED]: 'Audio system failed to initialize. Please check your browser audio settings.',
      [ErrorType.WEBGL_NOT_SUPPORTED]: 'Your browser does not support WebGL. 3D graphics may not work properly.',
      [ErrorType.AUDIO_PERMISSION_DENIED]: 'Audio permission denied. Please allow audio access and click the Start Audio button.',
      [ErrorType.INVALID_PROJECT_FILE]: 'The project file is invalid or corrupted. Please check the file format.',
      [ErrorType.RECORDING_NOT_SUPPORTED]: 'Audio recording is not supported in your browser. Recording features will be disabled.',
      [ErrorType.PERFORMANCE_DEGRADATION]: 'Performance issues detected. Some visual effects may be reduced to maintain smooth operation.'
    }

    return messages[error] || `Unknown error: ${error}`
  }

  private getRecoveryStrategy(error: ErrorType): RecoveryStrategy {
    switch (error) {
      case ErrorType.AUDIO_CONTEXT_FAILED:
        return {
          canRecover: true,
          recoveryAction: async () => {
            try {
              const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext
              const testContext = new AudioContextClass()
              
              if (testContext.state === 'suspended') {
                await testContext.resume()
              }
              
              const success = testContext.state === 'running'
              await testContext.close()
              return success
            } catch (e) {
              return false
            }
          },
          userGuidance: 'Try clicking the Start Audio button or refresh the page.'
        }

      case ErrorType.WEBGL_NOT_SUPPORTED:
        return {
          canRecover: false,
          fallbackAction: () => {
            // Enable fallback rendering mode
            this.showUserMessage('Switching to compatibility mode', 'warning')
          },
          userGuidance: 'Please use a modern browser with WebGL support for the best experience.'
        }

      case ErrorType.AUDIO_PERMISSION_DENIED:
        return {
          canRecover: true,
          recoveryAction: async () => {
            const result = await this.checkAudioPermissions()
            return result.hasPermission
          },
          userGuidance: 'Please allow audio access in your browser settings and click Start Audio.'
        }

      case ErrorType.INVALID_PROJECT_FILE:
        return {
          canRecover: false,
          userGuidance: 'Please check that the file is a valid ReacTable project file.'
        }

      case ErrorType.RECORDING_NOT_SUPPORTED:
        return {
          canRecover: false,
          fallbackAction: () => {
            // Disable recording UI elements
            this.showUserMessage('Recording features disabled due to browser limitations', 'warning')
          },
          userGuidance: 'Use a modern browser like Chrome or Firefox for recording support.'
        }

      case ErrorType.PERFORMANCE_DEGRADATION:
        return {
          canRecover: true,
          recoveryAction: async () => {
            // This would trigger performance optimization
            return true
          },
          userGuidance: 'Performance has been optimized. Consider reducing the number of active cubes.'
        }

      default:
        return { canRecover: false }
    }
  }

  private isCriticalError(message: string): boolean {
    const criticalKeywords = [
      'failed to initialize',
      'not supported',
      'permission denied',
      'corrupted'
    ]
    
    return criticalKeywords.some(keyword => 
      message.toLowerCase().includes(keyword)
    )
  }

  private showErrorNotification(error: ErrorType, details: ErrorDetails): void {
    switch (error) {
      case ErrorType.AUDIO_CONTEXT_FAILED:
        this.notificationSystem.error(details.message, {
          title: 'Audio System Error',
          duration: 0, // Persistent
          actions: [
            {
              label: 'Retry',
              action: () => this.attemptRecovery(error),
              style: 'primary'
            },
            {
              label: 'Help',
              action: () => this.showAudioTroubleshootingHelp(),
              style: 'secondary'
            }
          ]
        })
        break

      case ErrorType.WEBGL_NOT_SUPPORTED:
        this.notificationSystem.showWebGLFallbackWarning()
        break

      case ErrorType.AUDIO_PERMISSION_DENIED:
        this.notificationSystem.showAudioPermissionError()
        break

      case ErrorType.INVALID_PROJECT_FILE:
        this.notificationSystem.error(details.message, {
          title: 'Invalid Project File',
          actions: [
            {
              label: 'Try Another File',
              action: () => this.triggerFileSelection(),
              style: 'primary'
            }
          ]
        })
        break

      case ErrorType.RECORDING_NOT_SUPPORTED:
        this.notificationSystem.warning(details.message, {
          title: 'Recording Not Available',
          actions: [
            {
              label: 'Learn More',
              action: () => this.showRecordingHelpModal(),
              style: 'secondary'
            }
          ]
        })
        break

      case ErrorType.PERFORMANCE_DEGRADATION:
        const recommendations = this.getPerformanceRecommendations()
        this.notificationSystem.showPerformanceWarning(recommendations)
        break

      default:
        this.notificationSystem.error(details.message)
        break
    }
  }

  private showAudioTroubleshootingHelp(): void {
    const modal = document.createElement('div')
    modal.className = 'notification-modal'
    modal.innerHTML = `
      <div class="notification-modal-content">
        <h3>Audio System Troubleshooting</h3>
        <p>The audio system failed to initialize. Here are some solutions:</p>
        <h4>Common Solutions:</h4>
        <ul>
          <li><strong>User Interaction Required:</strong> Click the "Start Audio" button</li>
          <li><strong>Browser Settings:</strong> Check if audio is blocked for this site</li>
          <li><strong>Hardware Issues:</strong> Ensure audio devices are connected and working</li>
          <li><strong>Browser Support:</strong> Use Chrome, Firefox, or Edge for best compatibility</li>
        </ul>
        <h4>Advanced Troubleshooting:</h4>
        <ul>
          <li>Refresh the page and try again</li>
          <li>Check browser console for detailed error messages</li>
          <li>Try in an incognito/private browsing window</li>
          <li>Disable browser extensions that might block audio</li>
        </ul>
        <div class="notification-modal-actions">
          <button class="notification-action notification-action-primary" onclick="this.closest('.notification-modal').remove()">Got it</button>
        </div>
      </div>
    `
    document.body.appendChild(modal)
  }

  private showRecordingHelpModal(): void {
    const modal = document.createElement('div')
    modal.className = 'notification-modal'
    modal.innerHTML = `
      <div class="notification-modal-content">
        <h3>Recording Not Supported</h3>
        <p>Your browser doesn't support audio recording. This feature requires:</p>
        <ul>
          <li><strong>MediaRecorder API:</strong> Available in modern browsers</li>
          <li><strong>Secure Context:</strong> HTTPS or localhost</li>
          <li><strong>Audio Permissions:</strong> Microphone access (for some browsers)</li>
        </ul>
        <h4>Supported Browsers:</h4>
        <ul>
          <li>Chrome 47+</li>
          <li>Firefox 25+</li>
          <li>Edge 79+</li>
          <li>Safari 14.1+</li>
        </ul>
        <p><strong>Note:</strong> You can still use all other features of the ReacTable emulator.</p>
        <div class="notification-modal-actions">
          <button class="notification-action notification-action-primary" onclick="this.closest('.notification-modal').remove()">Understood</button>
        </div>
      </div>
    `
    document.body.appendChild(modal)
  }

  private triggerFileSelection(): void {
    // This would trigger the file selection dialog
    // Implementation depends on how file loading is handled in the main app
    console.log('Triggering file selection...')
  }

  private getPerformanceRecommendations(): string[] {
    return [
      'Consider reducing the number of active cubes.',
      'Close other browser tabs to free up memory.',
      'Try refreshing the page if performance doesn\'t improve.'
    ]
  }
}