import { 
  ProjectSchema, 
  SerializedCube, 
  SerializedConnection, 
  ProjectSettings,
  AppState,
  CubeInstance,
  Connection,
  CubeType
} from '@/types'
import { Vector3 } from 'three'

/**
 * ProjectSerializer handles serialization and deserialization of project data
 * Converts between runtime state and persistent JSON format
 */
export class ProjectSerializer {
  private static readonly CURRENT_VERSION = '1.0.0'
  private static readonly SUPPORTED_VERSIONS = ['1.0.0']

  /**
   * Serializes the current application state to a project schema
   */
  static serialize(
    state: AppState, 
    metadata: Partial<ProjectSchema['metadata']> = {},
    settings: Partial<ProjectSettings> = {}
  ): ProjectSchema {
    const now = new Date().toISOString()
    
    return {
      version: this.CURRENT_VERSION,
      metadata: {
        name: metadata.name || 'Untitled Project',
        created: metadata.created || now,
        modified: now,
        author: metadata.author
      },
      cubes: this.serializeCubes(state.cubes),
      connections: this.serializeConnections(state.connections),
      settings: {
        masterVolume: settings.masterVolume || 0.5,
        tempo: settings.tempo || 120,
        scale: settings.scale || 'C Major'
      }
    }
  }

  /**
   * Deserializes a project schema back to application state
   */
  static deserialize(projectData: ProjectSchema): {
    cubes: Map<string, CubeInstance>
    connections: Connection[]
    settings: ProjectSettings
  } {
    // Validate version compatibility
    this.validateVersion(projectData.version)
    
    // Validate schema structure
    this.validateSchema(projectData)
    
    return {
      cubes: this.deserializeCubes(projectData.cubes),
      connections: this.deserializeConnections(projectData.connections),
      settings: projectData.settings
    }
  }

  /**
   * Validates that the project data conforms to the expected schema
   */
  static validateSchema(projectData: any): asserts projectData is ProjectSchema {
    if (!projectData || typeof projectData !== 'object') {
      throw new Error('Invalid project data: must be an object')
    }

    if (!projectData.version || typeof projectData.version !== 'string') {
      throw new Error('Invalid project data: missing or invalid version')
    }

    if (!projectData.metadata || typeof projectData.metadata !== 'object') {
      throw new Error('Invalid project data: missing or invalid metadata')
    }

    if (!projectData.metadata.name || typeof projectData.metadata.name !== 'string') {
      throw new Error('Invalid project data: missing or invalid project name')
    }

    if (!Array.isArray(projectData.cubes)) {
      throw new Error('Invalid project data: cubes must be an array')
    }

    if (!Array.isArray(projectData.connections)) {
      throw new Error('Invalid project data: connections must be an array')
    }

    if (!projectData.settings || typeof projectData.settings !== 'object') {
      throw new Error('Invalid project data: missing or invalid settings')
    }

    // Validate each cube
    for (const cube of projectData.cubes) {
      this.validateSerializedCube(cube)
    }

    // Validate each connection
    for (const connection of projectData.connections) {
      this.validateSerializedConnection(connection)
    }
  }

  /**
   * Validates version compatibility
   */
  private static validateVersion(version: string): void {
    if (!this.SUPPORTED_VERSIONS.includes(version)) {
      throw new Error(
        `Unsupported project version: ${version}. ` +
        `Supported versions: ${this.SUPPORTED_VERSIONS.join(', ')}`
      )
    }
  }

  /**
   * Validates a serialized cube object
   */
  private static validateSerializedCube(cube: any): asserts cube is SerializedCube {
    if (!cube || typeof cube !== 'object') {
      throw new Error('Invalid cube data: must be an object')
    }

    if (!cube.id || typeof cube.id !== 'string') {
      throw new Error('Invalid cube data: missing or invalid id')
    }

    if (!Object.values(CubeType).includes(cube.type)) {
      throw new Error(`Invalid cube data: invalid type "${cube.type}"`)
    }

    if (!Array.isArray(cube.position) || cube.position.length !== 3) {
      throw new Error('Invalid cube data: position must be array of 3 numbers')
    }

    if (!Array.isArray(cube.rotation) || cube.rotation.length !== 3) {
      throw new Error('Invalid cube data: rotation must be array of 3 numbers')
    }

    if (!Array.isArray(cube.scale) || cube.scale.length !== 3) {
      throw new Error('Invalid cube data: scale must be array of 3 numbers')
    }

    if (!cube.parameters || typeof cube.parameters !== 'object') {
      throw new Error('Invalid cube data: parameters must be an object')
    }

    // Validate that position, rotation, and scale contain valid numbers
    const validateNumberArray = (arr: any[], name: string) => {
      for (let i = 0; i < arr.length; i++) {
        if (typeof arr[i] !== 'number' || !isFinite(arr[i])) {
          throw new Error(`Invalid cube data: ${name}[${i}] must be a finite number`)
        }
      }
    }

    validateNumberArray(cube.position, 'position')
    validateNumberArray(cube.rotation, 'rotation')
    validateNumberArray(cube.scale, 'scale')
  }

  /**
   * Validates a serialized connection object
   */
  private static validateSerializedConnection(connection: any): asserts connection is SerializedConnection {
    if (!connection || typeof connection !== 'object') {
      throw new Error('Invalid connection data: must be an object')
    }

    if (!connection.id || typeof connection.id !== 'string') {
      throw new Error('Invalid connection data: missing or invalid id')
    }

    if (!connection.fromCubeId || typeof connection.fromCubeId !== 'string') {
      throw new Error('Invalid connection data: missing or invalid fromCubeId')
    }

    if (!connection.toCubeId || typeof connection.toCubeId !== 'string') {
      throw new Error('Invalid connection data: missing or invalid toCubeId')
    }
  }

  /**
   * Converts runtime cubes to serialized format
   */
  private static serializeCubes(cubes: Map<string, CubeInstance>): SerializedCube[] {
    const serializedCubes: SerializedCube[] = []
    
    for (const cube of cubes.values()) {
      serializedCubes.push({
        id: cube.id,
        type: cube.type,
        position: cube.transform.position.toArray() as [number, number, number],
        rotation: cube.transform.rotation.toArray() as [number, number, number],
        scale: cube.transform.scale.toArray() as [number, number, number],
        parameters: { ...cube.parameters }
      })
    }
    
    return serializedCubes
  }

  /**
   * Converts serialized cubes back to runtime format
   */
  private static deserializeCubes(serializedCubes: SerializedCube[]): Map<string, CubeInstance> {
    const cubes = new Map<string, CubeInstance>()
    
    for (const serializedCube of serializedCubes) {
      const cube: CubeInstance = {
        id: serializedCube.id,
        type: serializedCube.type,
        transform: {
          position: new Vector3(...serializedCube.position),
          rotation: new Vector3(...serializedCube.rotation),
          scale: new Vector3(...serializedCube.scale)
        },
        audioNodeId: '', // Will be regenerated when audio system loads
        isActive: false, // Will be determined by connection system
        parameters: { ...serializedCube.parameters }
      }
      
      cubes.set(cube.id, cube)
    }
    
    return cubes
  }

  /**
   * Converts runtime connections to serialized format
   */
  private static serializeConnections(connections: Connection[]): SerializedConnection[] {
    return connections.map(connection => ({
      id: connection.id,
      fromCubeId: connection.fromCubeId,
      toCubeId: connection.toCubeId
    }))
  }

  /**
   * Converts serialized connections back to runtime format
   */
  private static deserializeConnections(serializedConnections: SerializedConnection[]): Connection[] {
    return serializedConnections.map(serializedConnection => ({
      id: serializedConnection.id,
      fromCubeId: serializedConnection.fromCubeId,
      toCubeId: serializedConnection.toCubeId,
      strength: 1.0, // Default strength, will be recalculated
      isActive: true // Will be determined by connection system
    }))
  }

  /**
   * Creates a deep copy of project data for safe manipulation
   */
  static cloneProjectData(projectData: ProjectSchema): ProjectSchema {
    return JSON.parse(JSON.stringify(projectData))
  }

  /**
   * Generates a unique project ID based on timestamp and random data
   */
  static generateProjectId(): string {
    const timestamp = Date.now().toString(36)
    const random = Math.random().toString(36).substring(2, 8)
    return `project-${timestamp}-${random}`
  }
}