import { PerformanceMonitor } from '@/interfaces/PerformanceMonitor'
import { RenderEngine } from '@/interfaces/RenderEngine'
import { AudioEngine } from '@/interfaces/AudioEngine'
import { PerformanceOptimizer, OptimizationLevel, OptimizationSettings } from '@/interfaces/PerformanceOptimizer'
import { PerformanceStatus } from '@/types'

export class PerformanceOptimizerImpl implements PerformanceOptimizer {
  private performanceMonitor: PerformanceMonitor
  private renderEngine?: RenderEngine
  private audioEngine?: AudioEngine
  
  private isEnabled = true
  private currentLevel = OptimizationLevel.NONE
  private cubeLimit = 20 // Default cube limit
  private optimizationCallbacks: ((level: OptimizationLevel) => void)[] = []
  
  // Optimization settings for each level
  private readonly optimizationSettings: Record<OptimizationLevel, OptimizationSettings> = {
    [OptimizationLevel.NONE]: {
      maxCubes: 20,
      visualQuality: 1.0,
      audioQuality: 1.0,
      shadowsEnabled: true,
      particlesEnabled: true,
      antiAliasingEnabled: true,
      audioBufferSize: 256
    },
    [OptimizationLevel.LOW]: {
      maxCubes: 18,
      visualQuality: 0.9,
      audioQuality: 0.95,
      shadowsEnabled: true,
      particlesEnabled: true,
      antiAliasingEnabled: true,
      audioBufferSize: 512
    },
    [OptimizationLevel.MEDIUM]: {
      maxCubes: 15,
      visualQuality: 0.7,
      audioQuality: 0.85,
      shadowsEnabled: false,
      particlesEnabled: true,
      antiAliasingEnabled: false,
      audioBufferSize: 1024
    },
    [OptimizationLevel.HIGH]: {
      maxCubes: 12,
      visualQuality: 0.5,
      audioQuality: 0.7,
      shadowsEnabled: false,
      particlesEnabled: false,
      antiAliasingEnabled: false,
      audioBufferSize: 2048
    },
    [OptimizationLevel.EXTREME]: {
      maxCubes: 8,
      visualQuality: 0.3,
      audioQuality: 0.5,
      shadowsEnabled: false,
      particlesEnabled: false,
      antiAliasingEnabled: false,
      audioBufferSize: 4096
    }
  }
  
  constructor(
    performanceMonitor: PerformanceMonitor,
    renderEngine?: RenderEngine,
    audioEngine?: AudioEngine
  ) {
    this.performanceMonitor = performanceMonitor
    this.renderEngine = renderEngine
    this.audioEngine = audioEngine
    
    // Listen to performance changes
    this.performanceMonitor.onPerformanceChange((status) => {
      if (this.isEnabled) {
        this.handlePerformanceChange(status)
      }
    })
  }
  
  enableOptimizations(): void {
    this.isEnabled = true
    console.info('Performance Optimizer: Optimizations enabled')
  }
  
  disableOptimizations(): void {
    this.isEnabled = false
    this.setOptimizationLevel(OptimizationLevel.NONE)
    console.info('Performance Optimizer: Optimizations disabled')
  }
  
  isOptimizationEnabled(): boolean {
    return this.isEnabled
  }
  
  setOptimizationLevel(level: OptimizationLevel): void {
    if (this.currentLevel === level) return
    
    const previousLevel = this.currentLevel
    this.currentLevel = level
    
    console.info(`Performance Optimizer: Changing optimization level from ${OptimizationLevel[previousLevel]} to ${OptimizationLevel[level]}`)
    
    this.applyOptimizations(level)
    this.notifyOptimizationChange(level)
  }
  
  getOptimizationLevel(): OptimizationLevel {
    return this.currentLevel
  }
  
  getCubeLimit(): number {
    const settings = this.optimizationSettings[this.currentLevel]
    return Math.min(this.cubeLimit, settings.maxCubes)
  }
  
  setCubeLimit(limit: number): void {
    this.cubeLimit = Math.max(1, Math.min(limit, 50)) // Clamp between 1 and 50
  }
  
  onOptimizationChange(callback: (level: OptimizationLevel) => void): void {
    this.optimizationCallbacks.push(callback)
  }
  
  private handlePerformanceChange(status: PerformanceStatus): void {
    if (!this.isEnabled || !status) return
    
    const newLevel = this.calculateOptimizationLevel(status)
    
    if (newLevel !== this.currentLevel) {
      this.setOptimizationLevel(newLevel)
    }
  }
  
  private calculateOptimizationLevel(status: PerformanceStatus): OptimizationLevel {
    if (!status) return OptimizationLevel.NONE
    
    let score = 0
    
    // FPS scoring (higher is better) - handle NaN/invalid values
    const fps = isNaN(status.fps) ? 60 : status.fps
    if (fps < 20) score += 4
    else if (fps < 30) score += 3
    else if (fps < 45) score += 2
    else if (fps < 55) score += 1
    
    // Audio latency scoring (lower is better) - handle NaN/invalid values
    const audioLatency = isNaN(status.audioLatency) ? 0 : status.audioLatency
    if (audioLatency > 100) score += 4
    else if (audioLatency > 50) score += 3
    else if (audioLatency > 30) score += 2
    else if (audioLatency > 20) score += 1
    
    // CPU usage scoring (lower is better) - handle NaN/invalid values
    const cpuUsage = isNaN(status.cpuUsage) ? 0 : status.cpuUsage
    if (cpuUsage > 95) score += 4
    else if (cpuUsage > 85) score += 3
    else if (cpuUsage > 75) score += 2
    else if (cpuUsage > 65) score += 1
    
    // Memory usage scoring (lower is better) - handle NaN/invalid values
    const memoryUsage = isNaN(status.memoryUsage) ? 0 : status.memoryUsage
    if (memoryUsage > 200) score += 2
    else if (memoryUsage > 150) score += 1
    
    // Convert score to optimization level
    if (score >= 10) return OptimizationLevel.EXTREME
    if (score >= 7) return OptimizationLevel.HIGH
    if (score >= 4) return OptimizationLevel.MEDIUM
    if (score >= 2) return OptimizationLevel.LOW
    return OptimizationLevel.NONE
  }
  
  private applyOptimizations(level: OptimizationLevel): void {
    const settings = this.optimizationSettings[level]
    
    // Apply visual optimizations
    if (this.renderEngine) {
      this.applyVisualOptimizations(settings)
    }
    
    // Apply audio optimizations
    if (this.audioEngine) {
      this.applyAudioOptimizations(settings)
    }
    
    // Log applied optimizations
    this.logOptimizations(level, settings)
  }
  
  private applyVisualOptimizations(settings: OptimizationSettings): void {
    if (!this.renderEngine) return
    
    try {
      // Apply visual quality scaling
      if ('setVisualQuality' in this.renderEngine) {
        (this.renderEngine as any).setVisualQuality(settings.visualQuality)
      }
      
      // Toggle shadows
      if ('setShadowsEnabled' in this.renderEngine) {
        (this.renderEngine as any).setShadowsEnabled(settings.shadowsEnabled)
      }
      
      // Toggle particles
      if ('setParticlesEnabled' in this.renderEngine) {
        (this.renderEngine as any).setParticlesEnabled(settings.particlesEnabled)
      }
      
      // Toggle anti-aliasing
      if ('setAntiAliasingEnabled' in this.renderEngine) {
        (this.renderEngine as any).setAntiAliasingEnabled(settings.antiAliasingEnabled)
      }
      
    } catch (error) {
      console.warn('Performance Optimizer: Error applying visual optimizations:', error)
    }
  }
  
  private applyAudioOptimizations(settings: OptimizationSettings): void {
    if (!this.audioEngine) return
    
    try {
      // Apply audio quality scaling
      if ('setAudioQuality' in this.audioEngine) {
        (this.audioEngine as any).setAudioQuality(settings.audioQuality)
      }
      
      // Adjust audio buffer size
      if ('setBufferSize' in this.audioEngine) {
        (this.audioEngine as any).setBufferSize(settings.audioBufferSize)
      }
      
    } catch (error) {
      console.warn('Performance Optimizer: Error applying audio optimizations:', error)
    }
  }
  
  private logOptimizations(level: OptimizationLevel, settings: OptimizationSettings): void {
    if (level === OptimizationLevel.NONE) {
      console.info('Performance Optimizer: All optimizations disabled - full quality restored')
      return
    }
    
    const optimizations: string[] = []
    
    if (settings.maxCubes < 20) {
      optimizations.push(`cube limit: ${settings.maxCubes}`)
    }
    
    if (settings.visualQuality < 1.0) {
      optimizations.push(`visual quality: ${Math.round(settings.visualQuality * 100)}%`)
    }
    
    if (settings.audioQuality < 1.0) {
      optimizations.push(`audio quality: ${Math.round(settings.audioQuality * 100)}%`)
    }
    
    if (!settings.shadowsEnabled) {
      optimizations.push('shadows disabled')
    }
    
    if (!settings.particlesEnabled) {
      optimizations.push('particles disabled')
    }
    
    if (!settings.antiAliasingEnabled) {
      optimizations.push('anti-aliasing disabled')
    }
    
    if (settings.audioBufferSize > 256) {
      optimizations.push(`audio buffer: ${settings.audioBufferSize}`)
    }
    
    console.info(`Performance Optimizer: Applied ${OptimizationLevel[level]} optimizations: ${optimizations.join(', ')}`)
  }
  
  private notifyOptimizationChange(level: OptimizationLevel): void {
    this.optimizationCallbacks.forEach(callback => {
      try {
        callback(level)
      } catch (error) {
        console.error('Performance Optimizer: Error in optimization callback:', error)
      }
    })
  }
  
  // Method to get current optimization settings
  getCurrentSettings(): OptimizationSettings {
    return { ...this.optimizationSettings[this.currentLevel] }
  }
  
  // Method to check if cube count exceeds limit
  isCubeCountExceeded(currentCount: number): boolean {
    return currentCount > this.getCubeLimit()
  }
  
  // Method to get warning message for cube limit
  getCubeLimitWarning(currentCount: number): string | null {
    const limit = this.getCubeLimit()
    
    if (currentCount > limit) {
      return `Performance warning: ${currentCount} cubes exceed the current limit of ${limit}. Consider removing some cubes or expect reduced performance.`
    }
    
    if (currentCount > limit - 2) {
      return `Performance notice: Approaching cube limit (${currentCount}/${limit}). Performance may degrade with additional cubes.`
    }
    
    return null
  }
  
  // Method to set render and audio engines after construction
  setRenderEngine(renderEngine: RenderEngine): void {
    this.renderEngine = renderEngine
  }
  
  setAudioEngine(audioEngine: AudioEngine): void {
    this.audioEngine = audioEngine
  }
}