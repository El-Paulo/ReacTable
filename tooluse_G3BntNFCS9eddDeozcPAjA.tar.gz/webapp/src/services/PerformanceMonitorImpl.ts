import { PerformanceMonitor } from '@/interfaces/PerformanceMonitor'
import { PerformanceStatus } from '@/types'

export class PerformanceMonitorImpl implements PerformanceMonitor {
  private fpsHistory: number[] = []
  private lastFrameTime = 0
  private frameCount = 0
  private isDegraded = false
  private performanceCallbacks: ((status: PerformanceStatus) => void)[] = []
  private autoManageDegradedMode = true
  
  // Performance thresholds
  private readonly FPS_TARGET = 60
  private readonly FPS_WARNING_THRESHOLD = 45
  private readonly FPS_CRITICAL_THRESHOLD = 30
  private readonly AUDIO_LATENCY_WARNING = 20 // ms
  private readonly AUDIO_LATENCY_CRITICAL = 50 // ms
  private readonly CPU_WARNING_THRESHOLD = 70 // %
  private readonly MEMORY_WARNING_THRESHOLD = 80 // MB
  
  // Audio latency measurement
  private audioLatency = 0
  private audioContext: AudioContext | null = null
  
  constructor(audioContext?: AudioContext, autoStart = true, autoManageDegradedMode = true) {
    this.audioContext = audioContext || null
    this.autoManageDegradedMode = autoManageDegradedMode
    if (autoStart) {
      this.startMonitoring()
    }
  }
  
  private startMonitoring(): void {
    // Start FPS monitoring
    this.measureFPS()
    
    // Monitor performance every second
    setInterval(() => {
      this.checkAndNotifyPerformance()
    }, 1000)
  }
  
  private measureFPS(): void {
    const now = performance.now()
    
    if (this.lastFrameTime > 0) {
      const deltaTime = now - this.lastFrameTime
      const fps = 1000 / deltaTime
      
      // Keep rolling average of last 60 frames
      this.fpsHistory.push(fps)
      if (this.fpsHistory.length > 60) {
        this.fpsHistory.shift()
      }
    }
    
    this.lastFrameTime = now
    this.frameCount++
    
    // Schedule next measurement
    requestAnimationFrame(() => this.measureFPS())
  }
  
  getFPS(): number {
    if (this.fpsHistory.length === 0) return 0
    
    // Return average FPS over last 60 frames
    const sum = this.fpsHistory.reduce((a, b) => a + b, 0)
    return Math.round(sum / this.fpsHistory.length)
  }
  
  getAudioLatency(): number {
    if (!this.audioContext) return 0
    
    // Calculate audio latency based on buffer size and sample rate
    const baseLatency = this.audioContext.baseLatency || 0
    const outputLatency = this.audioContext.outputLatency || 0
    
    // Total latency in milliseconds
    this.audioLatency = (baseLatency + outputLatency) * 1000
    
    return this.audioLatency
  }
  
  getCPUUsage(): number {
    // Use performance.now() timing to estimate CPU usage
    const start = performance.now()
    
    // Perform a small computational task
    let sum = 0
    for (let i = 0; i < 10000; i++) {
      sum += Math.random()
    }
    
    const end = performance.now()
    const executionTime = end - start
    
    // Estimate CPU usage based on execution time
    // This is a rough approximation
    const estimatedUsage = Math.min(executionTime * 10, 100)
    
    return Math.round(estimatedUsage)
  }
  
  getMemoryUsage(): number {
    // Use performance.memory if available (Chrome)
    if ('memory' in performance) {
      const memory = (performance as any).memory
      return Math.round(memory.usedJSHeapSize / (1024 * 1024)) // Convert to MB
    }
    
    // Fallback estimation based on frame count and FPS
    const estimatedUsage = Math.min(this.frameCount * 0.01, 100)
    return Math.round(estimatedUsage)
  }
  
  checkPerformance(): PerformanceStatus {
    const fps = this.getFPS()
    const audioLatency = this.getAudioLatency()
    const cpuUsage = this.getCPUUsage()
    const memoryUsage = this.getMemoryUsage()
    
    const recommendations: string[] = []
    let shouldDegrade = false
    
    // Check FPS performance
    if (fps < this.FPS_CRITICAL_THRESHOLD) {
      recommendations.push('Critical: Frame rate too low. Consider reducing visual effects.')
      shouldDegrade = true
    } else if (fps < this.FPS_WARNING_THRESHOLD) {
      recommendations.push('Warning: Frame rate below target. Monitor performance.')
    }
    
    // Check audio latency
    if (audioLatency > this.AUDIO_LATENCY_CRITICAL) {
      recommendations.push('Critical: Audio latency too high. Reduce audio processing.')
      shouldDegrade = true
    } else if (audioLatency > this.AUDIO_LATENCY_WARNING) {
      recommendations.push('Warning: Audio latency elevated. Monitor audio performance.')
    }
    
    // Check CPU usage
    if (cpuUsage > this.CPU_WARNING_THRESHOLD) {
      recommendations.push('Warning: High CPU usage detected. Consider reducing cube count.')
      if (cpuUsage > 90) {
        shouldDegrade = true
      }
    }
    
    // Check memory usage
    if (memoryUsage > this.MEMORY_WARNING_THRESHOLD) {
      recommendations.push('Warning: High memory usage. Consider restarting the application.')
    }
    
    // Auto-enable degraded mode if needed (only if auto-management is enabled)
    if (this.autoManageDegradedMode) {
      if (shouldDegrade && !this.isDegraded) {
        this.enableDegradedMode()
      } else if (!shouldDegrade && this.isDegraded) {
        // Auto-disable degraded mode if performance improves
        this.disableDegradedMode()
      }
    }
    
    return {
      fps,
      audioLatency,
      cpuUsage,
      memoryUsage,
      isDegraded: this.isDegraded,
      recommendations
    }
  }
  
  enableDegradedMode(): void {
    if (this.isDegraded) return
    
    this.isDegraded = true
    console.warn('Performance Monitor: Enabling degraded mode due to performance issues')
    
    // Notify listeners
    this.notifyPerformanceChange()
  }
  
  disableDegradedMode(): void {
    if (!this.isDegraded) return
    
    this.isDegraded = false
    console.info('Performance Monitor: Disabling degraded mode - performance recovered')
    
    // Notify listeners
    this.notifyPerformanceChange()
  }
  
  onPerformanceChange(callback: (status: PerformanceStatus) => void): void {
    this.performanceCallbacks.push(callback)
  }
  
  private checkAndNotifyPerformance(): void {
    const status = this.checkPerformance()
    
    // Log performance issues
    if (status.recommendations.length > 0) {
      console.warn('Performance issues detected:', status.recommendations)
    }
    
    this.notifyPerformanceChange()
  }
  
  private notifyPerformanceChange(): void {
    const status = this.checkPerformance()
    this.performanceCallbacks.forEach(callback => {
      try {
        callback(status)
      } catch (error) {
        console.error('Error in performance callback:', error)
      }
    })
  }
  
  // Method to update audio context reference
  setAudioContext(audioContext: AudioContext): void {
    this.audioContext = audioContext
  }
  
  // Method to get current degraded mode status
  isDegradedMode(): boolean {
    return this.isDegraded
  }
  
  // Method to reset performance history (useful for testing)
  reset(): void {
    this.fpsHistory = []
    this.frameCount = 0
    this.lastFrameTime = 0
    this.isDegraded = false
    // Note: Don't reset autoManageDegradedMode as it's a configuration setting
  }
}