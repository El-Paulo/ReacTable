import { ProjectSerializer } from './ProjectSerializer'
import { 
  ProjectSchema, 
  AppState, 
  ProjectSettings,
  ErrorType 
} from '@/types'

/**
 * ProjectManager handles saving and loading projects to/from localStorage and files
 * Provides automatic saving, file import/export, and project metadata management
 */
export class ProjectManager {
  private static readonly STORAGE_KEY = 'reactable-current-project'
  private static readonly PROJECTS_LIST_KEY = 'reactable-projects-list'
  private static readonly AUTO_SAVE_INTERVAL = 30000 // 30 seconds
  
  private autoSaveTimer: number | null = null
  private currentProjectId: string | null = null
  private onError?: (error: ErrorType, message: string) => void

  constructor(onError?: (error: ErrorType, message: string) => void) {
    this.onError = onError
  }

  /**
   * Starts automatic saving of the current project state
   */
  startAutoSave(getState: () => AppState): void {
    this.stopAutoSave()
    
    this.autoSaveTimer = window.setInterval(() => {
      try {
        this.autoSaveCurrentProject(getState())
      } catch (error) {
        console.error('Auto-save failed:', error)
        this.onError?.(ErrorType.INVALID_PROJECT_FILE, 'Auto-save failed')
      }
    }, ProjectManager.AUTO_SAVE_INTERVAL)
  }

  /**
   * Stops automatic saving
   */
  stopAutoSave(): void {
    if (this.autoSaveTimer !== null) {
      clearInterval(this.autoSaveTimer)
      this.autoSaveTimer = null
    }
  }

  /**
   * Saves the current project state to localStorage
   */
  saveCurrentProject(
    state: AppState, 
    metadata: Partial<ProjectSchema['metadata']> = {},
    settings: Partial<ProjectSettings> = {}
  ): string {
    try {
      const projectId = this.currentProjectId || ProjectSerializer.generateProjectId()
      const projectData = ProjectSerializer.serialize(state, {
        ...metadata,
        name: metadata.name || 'Current Project'
      }, settings)

      // Save to localStorage
      localStorage.setItem(ProjectManager.STORAGE_KEY, JSON.stringify(projectData))
      
      // Update projects list
      this.updateProjectsList(projectId, projectData.metadata)
      
      this.currentProjectId = projectId
      console.log(`Project saved: ${projectData.metadata.name}`)
      
      return projectId
    } catch (error) {
      const message = `Failed to save project: ${error instanceof Error ? error.message : 'Unknown error'}`
      console.error(message)
      this.onError?.(ErrorType.INVALID_PROJECT_FILE, message)
      throw error
    }
  }

  /**
   * Loads the current project from localStorage
   */
  loadCurrentProject(): {
    cubes: Map<string, import('@/types').CubeInstance>
    connections: import('@/types').Connection[]
    settings: ProjectSettings
    metadata: ProjectSchema['metadata']
  } | null {
    try {
      const savedData = localStorage.getItem(ProjectManager.STORAGE_KEY)
      if (!savedData) {
        return null
      }

      const projectData: ProjectSchema = JSON.parse(savedData)
      const deserializedData = ProjectSerializer.deserialize(projectData)
      
      console.log(`Project loaded: ${projectData.metadata.name}`)
      
      return {
        ...deserializedData,
        metadata: projectData.metadata
      }
    } catch (error) {
      const message = `Failed to load project: ${error instanceof Error ? error.message : 'Unknown error'}`
      console.error(message)
      this.onError?.(ErrorType.INVALID_PROJECT_FILE, message)
      return null
    }
  }

  /**
   * Exports the current project as a downloadable JSON file
   */
  exportProject(
    state: AppState, 
    filename?: string,
    metadata: Partial<ProjectSchema['metadata']> = {},
    settings: Partial<ProjectSettings> = {}
  ): void {
    try {
      const projectData = ProjectSerializer.serialize(state, metadata, settings)
      const jsonString = JSON.stringify(projectData, null, 2)
      const blob = new Blob([jsonString], { type: 'application/json' })
      
      const url = URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = url
      link.download = filename || `${projectData.metadata.name.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.json`
      
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      
      URL.revokeObjectURL(url)
      
      console.log(`Project exported: ${projectData.metadata.name}`)
    } catch (error) {
      const message = `Failed to export project: ${error instanceof Error ? error.message : 'Unknown error'}`
      console.error(message)
      this.onError?.(ErrorType.INVALID_PROJECT_FILE, message)
      throw error
    }
  }

  /**
   * Imports a project from a JSON file
   */
  importProject(file: File): Promise<{
    cubes: Map<string, import('@/types').CubeInstance>
    connections: import('@/types').Connection[]
    settings: ProjectSettings
    metadata: ProjectSchema['metadata']
  }> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader()
      
      reader.onload = (event) => {
        try {
          const jsonString = event.target?.result as string
          if (!jsonString) {
            throw new Error('File is empty or could not be read')
          }

          const projectData: ProjectSchema = JSON.parse(jsonString)
          const deserializedData = ProjectSerializer.deserialize(projectData)
          
          // Save as current project
          localStorage.setItem(ProjectManager.STORAGE_KEY, jsonString)
          
          // Update projects list
          const projectId = ProjectSerializer.generateProjectId()
          this.updateProjectsList(projectId, projectData.metadata)
          this.currentProjectId = projectId
          
          console.log(`Project imported: ${projectData.metadata.name}`)
          
          resolve({
            ...deserializedData,
            metadata: projectData.metadata
          })
        } catch (error) {
          const message = `Failed to import project: ${error instanceof Error ? error.message : 'Invalid JSON format'}`
          console.error(message)
          this.onError?.(ErrorType.INVALID_PROJECT_FILE, message)
          reject(new Error(message))
        }
      }
      
      reader.onerror = () => {
        const message = 'Failed to read file'
        console.error(message)
        this.onError?.(ErrorType.INVALID_PROJECT_FILE, message)
        reject(new Error(message))
      }
      
      reader.readAsText(file)
    })
  }

  /**
   * Creates a new empty project
   */
  createNewProject(name: string = 'New Project'): string {
    try {
      const emptyState: AppState = {
        isAudioStarted: false,
        cubes: new Map(),
        connections: [],
        selectedCube: null,
        isRecording: false
      }

      const projectId = this.saveCurrentProject(emptyState, { name })
      console.log(`New project created: ${name}`)
      
      return projectId
    } catch (error) {
      const message = `Failed to create new project: ${error instanceof Error ? error.message : 'Unknown error'}`
      console.error(message)
      this.onError?.(ErrorType.INVALID_PROJECT_FILE, message)
      throw error
    }
  }

  /**
   * Gets a list of all saved projects
   */
  getProjectsList(): Array<{
    id: string
    name: string
    created: string
    modified: string
    author?: string
  }> {
    try {
      const listData = localStorage.getItem(ProjectManager.PROJECTS_LIST_KEY)
      return listData ? JSON.parse(listData) : []
    } catch (error) {
      console.error('Failed to load projects list:', error)
      return []
    }
  }

  /**
   * Deletes a project from localStorage
   */
  deleteProject(projectId: string): void {
    try {
      // Remove from projects list
      const projectsList = this.getProjectsList()
      const updatedList = projectsList.filter(p => p.id !== projectId)
      localStorage.setItem(ProjectManager.PROJECTS_LIST_KEY, JSON.stringify(updatedList))
      
      // If this was the current project, clear it
      if (this.currentProjectId === projectId) {
        localStorage.removeItem(ProjectManager.STORAGE_KEY)
        this.currentProjectId = null
      }
      
      console.log(`Project deleted: ${projectId}`)
    } catch (error) {
      const message = `Failed to delete project: ${error instanceof Error ? error.message : 'Unknown error'}`
      console.error(message)
      this.onError?.(ErrorType.INVALID_PROJECT_FILE, message)
    }
  }

  /**
   * Gets the current project ID
   */
  getCurrentProjectId(): string | null {
    return this.currentProjectId
  }

  /**
   * Checks if there's a saved project in localStorage
   */
  hasSavedProject(): boolean {
    return localStorage.getItem(ProjectManager.STORAGE_KEY) !== null
  }

  /**
   * Clears all project data from localStorage
   */
  clearAllProjects(): void {
    try {
      localStorage.removeItem(ProjectManager.STORAGE_KEY)
      localStorage.removeItem(ProjectManager.PROJECTS_LIST_KEY)
      this.currentProjectId = null
      console.log('All projects cleared')
    } catch (error) {
      const message = `Failed to clear projects: ${error instanceof Error ? error.message : 'Unknown error'}`
      console.error(message)
      this.onError?.(ErrorType.INVALID_PROJECT_FILE, message)
    }
  }

  /**
   * Gets storage usage information
   */
  getStorageInfo(): {
    used: number
    available: number
    percentage: number
  } {
    try {
      let used = 0
      for (let key in localStorage) {
        if (localStorage.hasOwnProperty(key)) {
          used += localStorage[key].length + key.length
        }
      }
      
      // Estimate available storage (most browsers have ~5-10MB limit)
      const estimated = 5 * 1024 * 1024 // 5MB estimate
      const available = Math.max(0, estimated - used)
      const percentage = (used / estimated) * 100
      
      return {
        used,
        available,
        percentage: Math.min(100, percentage)
      }
    } catch (error) {
      console.error('Failed to get storage info:', error)
      return { used: 0, available: 0, percentage: 0 }
    }
  }

  /**
   * Auto-saves the current project state (internal method)
   */
  private autoSaveCurrentProject(state: AppState): void {
    if (this.currentProjectId) {
      const projectData = ProjectSerializer.serialize(state, {
        name: 'Auto-saved Project'
      })
      localStorage.setItem(ProjectManager.STORAGE_KEY, JSON.stringify(projectData))
    }
  }

  /**
   * Updates the projects list with a new or modified project
   */
  private updateProjectsList(projectId: string, metadata: ProjectSchema['metadata']): void {
    try {
      const projectsList = this.getProjectsList()
      const existingIndex = projectsList.findIndex(p => p.id === projectId)
      
      const projectInfo = {
        id: projectId,
        name: metadata.name,
        created: metadata.created,
        modified: metadata.modified,
        author: metadata.author
      }
      
      if (existingIndex >= 0) {
        projectsList[existingIndex] = projectInfo
      } else {
        projectsList.push(projectInfo)
      }
      
      // Keep only the most recent 10 projects to avoid storage bloat
      const sortedList = projectsList
        .sort((a, b) => new Date(b.modified).getTime() - new Date(a.modified).getTime())
        .slice(0, 10)
      
      localStorage.setItem(ProjectManager.PROJECTS_LIST_KEY, JSON.stringify(sortedList))
    } catch (error) {
      console.error('Failed to update projects list:', error)
    }
  }

  /**
   * Cleanup method to be called when the manager is no longer needed
   */
  destroy(): void {
    this.stopAutoSave()
    this.currentProjectId = null
  }
}