export interface NotificationOptions {
  id?: string
  title?: string
  message: string
  type: 'error' | 'warning' | 'info' | 'success'
  duration?: number // in milliseconds, 0 for persistent
  actions?: NotificationAction[]
  dismissible?: boolean
  position?: 'top-right' | 'top-left' | 'bottom-right' | 'bottom-left' | 'top-center' | 'bottom-center'
}

export interface NotificationAction {
  label: string
  action: () => void
  style?: 'primary' | 'secondary' | 'danger'
}

export interface Notification extends Required<Omit<NotificationOptions, 'actions'>> {
  id: string
  timestamp: number
  actions: NotificationAction[]
  isVisible: boolean
  timeoutId?: number
}

export interface NotificationSystemCallbacks {
  onNotificationAdded?: (notification: Notification) => void
  onNotificationRemoved?: (notification: Notification) => void
  onNotificationClicked?: (notification: Notification) => void
}

export class NotificationSystem {
  private notifications: Map<string, Notification> = new Map()
  private container: HTMLElement | null = null
  private callbacks: NotificationSystemCallbacks = {}
  private notificationCounter = 0

  constructor(callbacks?: NotificationSystemCallbacks) {
    this.callbacks = callbacks || {}
    this.createContainer()
  }

  show(options: NotificationOptions): string {
    const notification: Notification = {
      id: options.id || this.generateId(),
      title: options.title || '',
      message: options.message,
      type: options.type,
      duration: options.duration ?? this.getDefaultDuration(options.type),
      actions: options.actions || [],
      dismissible: options.dismissible ?? true,
      position: options.position || 'top-right',
      timestamp: Date.now(),
      isVisible: true
    }

    // Remove existing notification with same ID if it exists
    if (this.notifications.has(notification.id)) {
      this.remove(notification.id)
    }

    this.notifications.set(notification.id, notification)
    this.renderNotification(notification)

    // Set auto-dismiss timer if duration > 0
    if (notification.duration > 0) {
      notification.timeoutId = window.setTimeout(() => {
        this.remove(notification.id)
      }, notification.duration)
    }

    this.callbacks.onNotificationAdded?.(notification)
    return notification.id
  }

  remove(id: string): boolean {
    const notification = this.notifications.get(id)
    if (!notification) {
      return false
    }

    // Clear timeout if exists
    if (notification.timeoutId) {
      clearTimeout(notification.timeoutId)
    }

    // Remove from DOM
    const element = document.getElementById(`notification-${id}`)
    if (element) {
      element.classList.add('notification-exit')
      setTimeout(() => {
        element.remove()
      }, 300) // Match CSS transition duration
    }

    this.notifications.delete(id)
    this.callbacks.onNotificationRemoved?.(notification)
    return true
  }

  clear(type?: NotificationOptions['type']): void {
    const toRemove = Array.from(this.notifications.values())
      .filter(n => !type || n.type === type)
      .map(n => n.id)

    toRemove.forEach(id => this.remove(id))
  }

  getNotifications(type?: NotificationOptions['type']): Notification[] {
    const notifications = Array.from(this.notifications.values())
    return type ? notifications.filter(n => n.type === type) : notifications
  }

  // Convenience methods
  error(message: string, options?: Partial<NotificationOptions>): string {
    return this.show({ ...options, message, type: 'error' })
  }

  warning(message: string, options?: Partial<NotificationOptions>): string {
    return this.show({ ...options, message, type: 'warning' })
  }

  info(message: string, options?: Partial<NotificationOptions>): string {
    return this.show({ ...options, message, type: 'info' })
  }

  success(message: string, options?: Partial<NotificationOptions>): string {
    return this.show({ ...options, message, type: 'success' })
  }

  // Error-specific methods with contextual help
  showBrowserCompatibilityError(issues: string[]): string {
    const message = `Browser compatibility issues detected: ${issues.join(', ')}`
    const actions: NotificationAction[] = [
      {
        label: 'Learn More',
        action: () => this.showBrowserHelpModal(issues),
        style: 'primary'
      },
      {
        label: 'Continue Anyway',
        action: () => this.remove('browser-compatibility'),
        style: 'secondary'
      }
    ]

    return this.show({
      id: 'browser-compatibility',
      title: 'Browser Compatibility',
      message,
      type: 'error',
      duration: 0, // Persistent
      actions,
      position: 'top-center'
    })
  }

  showAudioPermissionError(): string {
    const actions: NotificationAction[] = [
      {
        label: 'Enable Audio',
        action: () => this.showAudioPermissionGuide(),
        style: 'primary'
      }
    ]

    return this.show({
      id: 'audio-permission',
      title: 'Audio Permission Required',
      message: 'Please allow audio access to use the ReacTable emulator.',
      type: 'warning',
      duration: 0,
      actions,
      position: 'top-center'
    })
  }

  showWebGLFallbackWarning(): string {
    const actions: NotificationAction[] = [
      {
        label: 'Learn More',
        action: () => this.showWebGLHelpModal(),
        style: 'secondary'
      }
    ]

    return this.show({
      id: 'webgl-fallback',
      title: 'Limited Graphics Support',
      message: 'Running in compatibility mode. Some visual effects may be reduced.',
      type: 'warning',
      duration: 8000,
      actions,
      position: 'top-right'
    })
  }

  showPerformanceWarning(recommendations: string[]): string {
    const message = `Performance issues detected. ${recommendations.join(' ')}`
    
    return this.show({
      id: 'performance-warning',
      title: 'Performance Alert',
      message,
      type: 'warning',
      duration: 10000,
      position: 'top-right'
    })
  }

  destroy(): void {
    // Clear all notifications
    this.clear()
    
    // Remove container
    if (this.container && this.container.parentNode) {
      this.container.parentNode.removeChild(this.container)
    }
    
    this.notifications.clear()
    this.container = null
  }

  private createContainer(): void {
    if (this.container) return

    this.container = document.createElement('div')
    this.container.id = 'notification-container'
    this.container.className = 'notification-container'
    
    // Add CSS styles
    this.injectStyles()
    
    document.body.appendChild(this.container)
  }

  private renderNotification(notification: Notification): void {
    if (!this.container) return

    const element = document.createElement('div')
    element.id = `notification-${notification.id}`
    element.className = `notification notification-${notification.type} notification-${notification.position}`
    
    // Build notification HTML
    let html = `
      <div class="notification-content">
        <div class="notification-icon">
          ${this.getIconForType(notification.type)}
        </div>
        <div class="notification-body">
          ${notification.title ? `<div class="notification-title">${this.escapeHtml(notification.title)}</div>` : ''}
          <div class="notification-message">${this.escapeHtml(notification.message)}</div>
        </div>
    `

    // Add actions if present
    if (notification.actions.length > 0) {
      html += '<div class="notification-actions">'
      notification.actions.forEach(action => {
        html += `<button class="notification-action notification-action-${action.style || 'secondary'}" data-action="${this.escapeHtml(action.label)}">${this.escapeHtml(action.label)}</button>`
      })
      html += '</div>'
    }

    // Add dismiss button if dismissible
    if (notification.dismissible) {
      html += '<button class="notification-dismiss" aria-label="Dismiss">×</button>'
    }

    html += '</div>'
    element.innerHTML = html

    // Add event listeners
    this.addNotificationEventListeners(element, notification)

    // Add to container
    this.container.appendChild(element)

    // Trigger entrance animation
    setTimeout(() => {
      element.classList.add('notification-enter')
    }, 10)
  }

  private addNotificationEventListeners(element: HTMLElement, notification: Notification): void {
    // Dismiss button
    const dismissBtn = element.querySelector('.notification-dismiss')
    if (dismissBtn) {
      dismissBtn.addEventListener('click', (e) => {
        e.stopPropagation()
        this.remove(notification.id)
      })
    }

    // Action buttons
    const actionBtns = element.querySelectorAll('.notification-action')
    actionBtns.forEach((btn, index) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation()
        const action = notification.actions[index]
        if (action) {
          action.action()
        }
      })
    })

    // Click notification
    element.addEventListener('click', () => {
      this.callbacks.onNotificationClicked?.(notification)
    })
  }

  private generateId(): string {
    return `notification-${++this.notificationCounter}-${Date.now()}`
  }

  private getDefaultDuration(type: NotificationOptions['type']): number {
    switch (type) {
      case 'error': return 8000
      case 'warning': return 6000
      case 'info': return 4000
      case 'success': return 3000
      default: return 5000
    }
  }

  private getIconForType(type: NotificationOptions['type']): string {
    switch (type) {
      case 'error': return '⚠️'
      case 'warning': return '⚠️'
      case 'info': return 'ℹ️'
      case 'success': return '✅'
      default: return 'ℹ️'
    }
  }

  private escapeHtml(text: string): string {
    const div = document.createElement('div')
    div.textContent = text
    return div.innerHTML
  }

  private showBrowserHelpModal(issues: string[]): void {
    const modal = document.createElement('div')
    modal.className = 'notification-modal'
    modal.innerHTML = `
      <div class="notification-modal-content">
        <h3>Browser Compatibility Issues</h3>
        <p>Your browser has the following compatibility issues:</p>
        <ul>
          ${issues.map(issue => `<li>${this.escapeHtml(issue)}</li>`).join('')}
        </ul>
        <h4>Recommended Solutions:</h4>
        <ul>
          <li>Update your browser to the latest version</li>
          <li>Use Chrome, Firefox, or Edge for the best experience</li>
          <li>Enable hardware acceleration in browser settings</li>
        </ul>
        <div class="notification-modal-actions">
          <button class="notification-action notification-action-primary" onclick="this.closest('.notification-modal').remove()">Got it</button>
        </div>
      </div>
    `
    document.body.appendChild(modal)
  }

  private showAudioPermissionGuide(): void {
    const modal = document.createElement('div')
    modal.className = 'notification-modal'
    modal.innerHTML = `
      <div class="notification-modal-content">
        <h3>Enable Audio Access</h3>
        <p>To use the ReacTable emulator, you need to allow audio access:</p>
        <ol>
          <li>Click the "Start Audio" button when it appears</li>
          <li>If prompted, allow audio access in your browser</li>
          <li>Check your browser's address bar for permission icons</li>
        </ol>
        <p><strong>Note:</strong> Audio requires user interaction to start due to browser security policies.</p>
        <div class="notification-modal-actions">
          <button class="notification-action notification-action-primary" onclick="this.closest('.notification-modal').remove()">Understood</button>
        </div>
      </div>
    `
    document.body.appendChild(modal)
  }

  private showWebGLHelpModal(): void {
    const modal = document.createElement('div')
    modal.className = 'notification-modal'
    modal.innerHTML = `
      <div class="notification-modal-content">
        <h3>WebGL Compatibility Mode</h3>
        <p>Your browser has limited WebGL support. The application is running in compatibility mode with:</p>
        <ul>
          <li>Reduced visual effects</li>
          <li>Lower rendering quality</li>
          <li>Disabled shadows and advanced lighting</li>
        </ul>
        <h4>To improve performance:</h4>
        <ul>
          <li>Update your graphics drivers</li>
          <li>Enable hardware acceleration</li>
          <li>Use a modern browser</li>
        </ul>
        <div class="notification-modal-actions">
          <button class="notification-action notification-action-primary" onclick="this.closest('.notification-modal').remove()">Continue</button>
        </div>
      </div>
    `
    document.body.appendChild(modal)
  }

  private injectStyles(): void {
    if (document.getElementById('notification-styles')) return

    const style = document.createElement('style')
    style.id = 'notification-styles'
    style.textContent = `
      .notification-container {
        position: fixed;
        z-index: 10000;
        pointer-events: none;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
      }

      .notification {
        position: absolute;
        min-width: 300px;
        max-width: 500px;
        background: white;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        pointer-events: auto;
        transform: translateX(100%);
        opacity: 0;
        transition: all 0.3s ease;
        margin: 8px;
        border-left: 4px solid;
      }

      .notification-enter {
        transform: translateX(0);
        opacity: 1;
      }

      .notification-exit {
        transform: translateX(100%);
        opacity: 0;
      }

      .notification-top-right {
        top: 0;
        right: 0;
      }

      .notification-top-left {
        top: 0;
        left: 0;
        transform: translateX(-100%);
      }

      .notification-top-left.notification-enter {
        transform: translateX(0);
      }

      .notification-top-left.notification-exit {
        transform: translateX(-100%);
      }

      .notification-bottom-right {
        bottom: 0;
        right: 0;
      }

      .notification-bottom-left {
        bottom: 0;
        left: 0;
        transform: translateX(-100%);
      }

      .notification-bottom-left.notification-enter {
        transform: translateX(0);
      }

      .notification-bottom-left.notification-exit {
        transform: translateX(-100%);
      }

      .notification-top-center {
        top: 0;
        left: 50%;
        transform: translateX(-50%) translateY(-100%);
      }

      .notification-top-center.notification-enter {
        transform: translateX(-50%) translateY(0);
      }

      .notification-top-center.notification-exit {
        transform: translateX(-50%) translateY(-100%);
      }

      .notification-bottom-center {
        bottom: 0;
        left: 50%;
        transform: translateX(-50%) translateY(100%);
      }

      .notification-bottom-center.notification-enter {
        transform: translateX(-50%) translateY(0);
      }

      .notification-bottom-center.notification-exit {
        transform: translateX(-50%) translateY(100%);
      }

      .notification-error {
        border-left-color: #dc3545;
      }

      .notification-warning {
        border-left-color: #ffc107;
      }

      .notification-info {
        border-left-color: #17a2b8;
      }

      .notification-success {
        border-left-color: #28a745;
      }

      .notification-content {
        display: flex;
        align-items: flex-start;
        padding: 16px;
        position: relative;
      }

      .notification-icon {
        font-size: 20px;
        margin-right: 12px;
        flex-shrink: 0;
      }

      .notification-body {
        flex: 1;
        min-width: 0;
      }

      .notification-title {
        font-weight: 600;
        font-size: 14px;
        margin-bottom: 4px;
        color: #333;
      }

      .notification-message {
        font-size: 13px;
        color: #666;
        line-height: 1.4;
      }

      .notification-actions {
        margin-top: 12px;
        display: flex;
        gap: 8px;
      }

      .notification-action {
        padding: 6px 12px;
        border: none;
        border-radius: 4px;
        font-size: 12px;
        cursor: pointer;
        transition: background-color 0.2s;
      }

      .notification-action-primary {
        background: #007bff;
        color: white;
      }

      .notification-action-primary:hover {
        background: #0056b3;
      }

      .notification-action-secondary {
        background: #6c757d;
        color: white;
      }

      .notification-action-secondary:hover {
        background: #545b62;
      }

      .notification-action-danger {
        background: #dc3545;
        color: white;
      }

      .notification-action-danger:hover {
        background: #c82333;
      }

      .notification-dismiss {
        position: absolute;
        top: 8px;
        right: 8px;
        background: none;
        border: none;
        font-size: 18px;
        cursor: pointer;
        color: #999;
        width: 24px;
        height: 24px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        transition: background-color 0.2s;
      }

      .notification-dismiss:hover {
        background: rgba(0, 0, 0, 0.1);
        color: #666;
      }

      .notification-modal {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.5);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 10001;
      }

      .notification-modal-content {
        background: white;
        border-radius: 8px;
        padding: 24px;
        max-width: 500px;
        max-height: 80vh;
        overflow-y: auto;
        margin: 20px;
      }

      .notification-modal-content h3 {
        margin: 0 0 16px 0;
        color: #333;
      }

      .notification-modal-content p {
        margin: 0 0 12px 0;
        color: #666;
        line-height: 1.5;
      }

      .notification-modal-content ul,
      .notification-modal-content ol {
        margin: 0 0 16px 0;
        padding-left: 20px;
      }

      .notification-modal-content li {
        margin-bottom: 4px;
        color: #666;
      }

      .notification-modal-actions {
        margin-top: 20px;
        display: flex;
        justify-content: flex-end;
        gap: 8px;
      }
    `
    document.head.appendChild(style)
  }
}