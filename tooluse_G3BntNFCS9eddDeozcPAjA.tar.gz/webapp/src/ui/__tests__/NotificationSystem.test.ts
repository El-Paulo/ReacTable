import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest'
import { NotificationSystem, NotificationOptions } from '../NotificationSystem'

// Mock DOM methods
const mockElement = {
  id: '',
  className: '',
  innerHTML: '',
  style: {},
  appendChild: vi.fn(),
  remove: vi.fn(),
  querySelector: vi.fn(),
  querySelectorAll: vi.fn().mockReturnValue([]),
  addEventListener: vi.fn(),
  classList: {
    add: vi.fn(),
    remove: vi.fn()
  },
  closest: vi.fn()
}

const mockDocument = {
  createElement: vi.fn().mockReturnValue(mockElement),
  getElementById: vi.fn(),
  body: {
    appendChild: vi.fn()
  },
  head: {
    appendChild: vi.fn()
  }
}

const mockWindow = {
  setTimeout: vi.fn().mockImplementation((fn, delay) => {
    // Execute immediately for tests
    if (delay === 10) fn() // Animation trigger
    return 123 // Mock timeout ID
  }),
  clearTimeout: vi.fn()
}

// Mock globals
Object.defineProperty(global, 'document', {
  value: mockDocument,
  writable: true
})

Object.defineProperty(global, 'window', {
  value: mockWindow,
  writable: true
})

describe('NotificationSystem', () => {
  let notificationSystem: NotificationSystem
  let mockCallbacks: any

  beforeEach(() => {
    mockCallbacks = {
      onNotificationAdded: vi.fn(),
      onNotificationRemoved: vi.fn(),
      onNotificationClicked: vi.fn()
    }
    
    notificationSystem = new NotificationSystem(mockCallbacks)
    vi.clearAllMocks()
  })

  afterEach(() => {
    notificationSystem.destroy()
  })

  describe('initialization', () => {
    it('should create container on initialization', () => {
      expect(mockDocument.createElement).toHaveBeenCalledWith('div')
      expect(mockDocument.body.appendChild).toHaveBeenCalled()
    })

    it('should inject CSS styles', () => {
      expect(mockDocument.head.appendChild).toHaveBeenCalled()
    })
  })

  describe('show notification', () => {
    it('should show basic notification', () => {
      const options: NotificationOptions = {
        message: 'Test message',
        type: 'info'
      }

      const id = notificationSystem.show(options)

      expect(id).toBeTruthy()
      expect(mockCallbacks.onNotificationAdded).toHaveBeenCalled()
      expect(mockDocument.createElement).toHaveBeenCalledWith('div')
    })

    it('should show notification with custom options', () => {
      const options: NotificationOptions = {
        id: 'custom-id',
        title: 'Custom Title',
        message: 'Custom message',
        type: 'error',
        duration: 5000,
        position: 'top-left',
        dismissible: false
      }

      const id = notificationSystem.show(options)

      expect(id).toBe('custom-id')
      expect(mockCallbacks.onNotificationAdded).toHaveBeenCalledWith(
        expect.objectContaining({
          id: 'custom-id',
          title: 'Custom Title',
          message: 'Custom message',
          type: 'error',
          duration: 5000,
          position: 'top-left',
          dismissible: false
        })
      )
    })

    it('should set auto-dismiss timer for non-persistent notifications', () => {
      const options: NotificationOptions = {
        message: 'Test message',
        type: 'info',
        duration: 3000
      }

      notificationSystem.show(options)

      expect(mockWindow.setTimeout).toHaveBeenCalledWith(
        expect.any(Function),
        3000
      )
    })

    it('should not set timer for persistent notifications', () => {
      const options: NotificationOptions = {
        message: 'Test message',
        type: 'error',
        duration: 0
      }

      notificationSystem.show(options)

      // Should only be called for animation trigger (delay 10)
      expect(mockWindow.setTimeout).toHaveBeenCalledTimes(1)
      expect(mockWindow.setTimeout).toHaveBeenCalledWith(expect.any(Function), 10)
    })

    it('should replace existing notification with same ID', () => {
      const options: NotificationOptions = {
        id: 'duplicate-id',
        message: 'First message',
        type: 'info'
      }

      notificationSystem.show(options)
      notificationSystem.show({ ...options, message: 'Second message' })

      // Should be called twice (once for each show)
      expect(mockCallbacks.onNotificationAdded).toHaveBeenCalledTimes(2)
    })
  })

  describe('convenience methods', () => {
    it('should show error notification', () => {
      const id = notificationSystem.error('Error message')
      
      expect(id).toBeTruthy()
      expect(mockCallbacks.onNotificationAdded).toHaveBeenCalledWith(
        expect.objectContaining({
          message: 'Error message',
          type: 'error'
        })
      )
    })

    it('should show warning notification', () => {
      const id = notificationSystem.warning('Warning message')
      
      expect(id).toBeTruthy()
      expect(mockCallbacks.onNotificationAdded).toHaveBeenCalledWith(
        expect.objectContaining({
          message: 'Warning message',
          type: 'warning'
        })
      )
    })

    it('should show info notification', () => {
      const id = notificationSystem.info('Info message')
      
      expect(id).toBeTruthy()
      expect(mockCallbacks.onNotificationAdded).toHaveBeenCalledWith(
        expect.objectContaining({
          message: 'Info message',
          type: 'info'
        })
      )
    })

    it('should show success notification', () => {
      const id = notificationSystem.success('Success message')
      
      expect(id).toBeTruthy()
      expect(mockCallbacks.onNotificationAdded).toHaveBeenCalledWith(
        expect.objectContaining({
          message: 'Success message',
          type: 'success'
        })
      )
    })
  })

  describe('specialized error notifications', () => {
    it('should show browser compatibility error', () => {
      const issues = ['WebGL not supported', 'MediaRecorder not available']
      
      const id = notificationSystem.showBrowserCompatibilityError(issues)
      
      expect(id).toBe('browser-compatibility')
      expect(mockCallbacks.onNotificationAdded).toHaveBeenCalledWith(
        expect.objectContaining({
          id: 'browser-compatibility',
          type: 'error',
          duration: 0,
          position: 'top-center'
        })
      )
    })

    it('should show audio permission error', () => {
      const id = notificationSystem.showAudioPermissionError()
      
      expect(id).toBe('audio-permission')
      expect(mockCallbacks.onNotificationAdded).toHaveBeenCalledWith(
        expect.objectContaining({
          id: 'audio-permission',
          type: 'warning',
          duration: 0,
          position: 'top-center'
        })
      )
    })

    it('should show WebGL fallback warning', () => {
      const id = notificationSystem.showWebGLFallbackWarning()
      
      expect(id).toBe('webgl-fallback')
      expect(mockCallbacks.onNotificationAdded).toHaveBeenCalledWith(
        expect.objectContaining({
          id: 'webgl-fallback',
          type: 'warning',
          duration: 8000,
          position: 'top-right'
        })
      )
    })

    it('should show performance warning', () => {
      const recommendations = ['Reduce cube count', 'Close other tabs']
      
      const id = notificationSystem.showPerformanceWarning(recommendations)
      
      expect(id).toBe('performance-warning')
      expect(mockCallbacks.onNotificationAdded).toHaveBeenCalledWith(
        expect.objectContaining({
          id: 'performance-warning',
          type: 'warning',
          duration: 10000,
          position: 'top-right'
        })
      )
    })
  })

  describe('remove notification', () => {
    it('should remove existing notification', () => {
      const id = notificationSystem.show({
        message: 'Test message',
        type: 'info'
      })

      // Mock getElementById to return a mock element
      mockDocument.getElementById.mockReturnValue(mockElement)

      const removed = notificationSystem.remove(id)

      expect(removed).toBe(true)
      expect(mockCallbacks.onNotificationRemoved).toHaveBeenCalled()
      expect(mockElement.classList.add).toHaveBeenCalledWith('notification-exit')
    })

    it('should return false for non-existent notification', () => {
      const removed = notificationSystem.remove('non-existent-id')
      
      expect(removed).toBe(false)
      expect(mockCallbacks.onNotificationRemoved).not.toHaveBeenCalled()
    })

    it('should clear timeout when removing notification', () => {
      const id = notificationSystem.show({
        message: 'Test message',
        type: 'info',
        duration: 3000
      })

      mockDocument.getElementById.mockReturnValue(mockElement)
      notificationSystem.remove(id)

      expect(mockWindow.clearTimeout).toHaveBeenCalledWith(123)
    })
  })

  describe('clear notifications', () => {
    beforeEach(() => {
      // Add some notifications
      notificationSystem.show({ message: 'Error 1', type: 'error' })
      notificationSystem.show({ message: 'Warning 1', type: 'warning' })
      notificationSystem.show({ message: 'Info 1', type: 'info' })
      
      // Mock getElementById for removal
      mockDocument.getElementById.mockReturnValue(mockElement)
    })

    it('should clear all notifications', () => {
      notificationSystem.clear()
      
      expect(mockCallbacks.onNotificationRemoved).toHaveBeenCalledTimes(3)
    })

    it('should clear notifications by type', () => {
      notificationSystem.clear('error')
      
      expect(mockCallbacks.onNotificationRemoved).toHaveBeenCalledTimes(1)
    })
  })

  describe('get notifications', () => {
    beforeEach(() => {
      notificationSystem.show({ message: 'Error 1', type: 'error' })
      notificationSystem.show({ message: 'Warning 1', type: 'warning' })
      notificationSystem.show({ message: 'Error 2', type: 'error' })
    })

    it('should get all notifications', () => {
      const notifications = notificationSystem.getNotifications()
      
      expect(notifications).toHaveLength(3)
    })

    it('should get notifications by type', () => {
      const errorNotifications = notificationSystem.getNotifications('error')
      
      expect(errorNotifications).toHaveLength(2)
      expect(errorNotifications.every(n => n.type === 'error')).toBe(true)
    })
  })

  describe('destroy', () => {
    it('should clean up all resources', () => {
      // Add some notifications
      notificationSystem.show({ message: 'Test 1', type: 'info' })
      notificationSystem.show({ message: 'Test 2', type: 'warning' })

      // Mock container and its parent
      const mockContainer = {
        parentNode: {
          removeChild: vi.fn()
        }
      }
      
      // Mock the container property (private, so we need to access it indirectly)
      mockDocument.getElementById.mockReturnValue(mockElement)

      notificationSystem.destroy()

      // Should clear all notifications
      expect(mockCallbacks.onNotificationRemoved).toHaveBeenCalledTimes(2)
    })
  })

  describe('HTML escaping', () => {
    it('should escape HTML in messages', () => {
      const maliciousMessage = '<script>alert("xss")</script>'
      
      notificationSystem.show({
        message: maliciousMessage,
        type: 'info'
      })

      // The escapeHtml method should be called internally
      // We can't directly test it, but we can verify the notification was created
      expect(mockCallbacks.onNotificationAdded).toHaveBeenCalled()
    })

    it('should escape HTML in titles', () => {
      const maliciousTitle = '<img src=x onerror=alert(1)>'
      
      notificationSystem.show({
        title: maliciousTitle,
        message: 'Safe message',
        type: 'info'
      })

      expect(mockCallbacks.onNotificationAdded).toHaveBeenCalledWith(
        expect.objectContaining({
          title: maliciousTitle // The title is stored as-is, escaping happens during rendering
        })
      )
    })
  })

  describe('default durations', () => {
    it('should use correct default duration for error', () => {
      notificationSystem.error('Error message')
      
      expect(mockCallbacks.onNotificationAdded).toHaveBeenCalledWith(
        expect.objectContaining({
          duration: 8000
        })
      )
    })

    it('should use correct default duration for warning', () => {
      notificationSystem.warning('Warning message')
      
      expect(mockCallbacks.onNotificationAdded).toHaveBeenCalledWith(
        expect.objectContaining({
          duration: 6000
        })
      )
    })

    it('should use correct default duration for info', () => {
      notificationSystem.info('Info message')
      
      expect(mockCallbacks.onNotificationAdded).toHaveBeenCalledWith(
        expect.objectContaining({
          duration: 4000
        })
      )
    })

    it('should use correct default duration for success', () => {
      notificationSystem.success('Success message')
      
      expect(mockCallbacks.onNotificationAdded).toHaveBeenCalledWith(
        expect.objectContaining({
          duration: 3000
        })
      )
    })
  })
})