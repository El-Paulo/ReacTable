import { describe, it, expect, beforeEach, vi, afterEach } from 'vitest'
import { UIManager, UIManagerEvents } from '../UIManager'
import { CubeType } from '@/types'
import { ReactableApp } from '@/interfaces/ReactableApp'

// Mock DOM elements
const mockElements = {
  cubePalette: document.createElement('div'),
  controlPanel: document.createElement('div'),
  instructions: document.createElement('div'),
  startAudioBtn: document.createElement('button'),
  stopAudioBtn: document.createElement('button'),
  clearSceneBtn: document.createElement('button'),
  generatorsList: document.createElement('div'),
  effectsList: document.createElement('div'),
  outputList: document.createElement('div')
}

// Set up IDs for mock elements
mockElements.cubePalette.id = 'cube-palette'
mockElements.controlPanel.id = 'control-panel'
mockElements.instructions.id = 'instructions'
mockElements.startAudioBtn.id = 'start-audio-btn'
mockElements.stopAudioBtn.id = 'stop-audio-btn'
mockElements.clearSceneBtn.id = 'clear-scene-btn'
mockElements.generatorsList.id = 'generators-list'
mockElements.effectsList.id = 'effects-list'
mockElements.outputList.id = 'output-list'

// Nest the category lists inside the cube palette
mockElements.cubePalette.appendChild(mockElements.generatorsList)
mockElements.cubePalette.appendChild(mockElements.effectsList)
mockElements.cubePalette.appendChild(mockElements.outputList)

// Mock ReactableApp
const mockApp: ReactableApp = {
  initialize: vi.fn(),
  startAudio: vi.fn(),
  getState: vi.fn(),
  setState: vi.fn(),
  update: vi.fn(),
  render: vi.fn(),
  destroy: vi.fn()
}

// Mock events
const mockEvents: UIManagerEvents = {
  cubeTypeSelected: vi.fn(),
  clearScene: vi.fn(),
  startAudio: vi.fn(),
  stopAudio: vi.fn(),
  saveProject: vi.fn(),
  loadProject: vi.fn(),
  exportProject: vi.fn(),
  importProject: vi.fn(),
  newProject: vi.fn()
}

describe('UIManager', () => {
  let uiManager: UIManager

  beforeEach(() => {
    // Clear all mocks
    vi.clearAllMocks()

    // Mock document.getElementById
    vi.spyOn(document, 'getElementById').mockImplementation((id: string) => {
      switch (id) {
        case 'cube-palette': return mockElements.cubePalette
        case 'control-panel': return mockElements.controlPanel
        case 'instructions': return mockElements.instructions
        case 'start-audio-btn': return mockElements.startAudioBtn
        case 'stop-audio-btn': return mockElements.stopAudioBtn
        case 'clear-scene-btn': return mockElements.clearSceneBtn
        case 'generators-list': return mockElements.generatorsList
        case 'effects-list': return mockElements.effectsList
        case 'output-list': return mockElements.outputList
        default: return null
      }
    })

    // Mock document.body
    Object.defineProperty(document, 'body', {
      value: document.createElement('body'),
      writable: true
    })

    // Create UIManager instance
    uiManager = new UIManager(mockApp, mockEvents)
  })

  afterEach(() => {
    vi.restoreAllMocks()
  })

  describe('Initialization', () => {
    it('should create cube items for all cube types', () => {
      // Check that cube items were created in each category
      expect(mockElements.generatorsList.children.length).toBeGreaterThan(0)
      expect(mockElements.effectsList.children.length).toBeGreaterThan(0)
      expect(mockElements.outputList.children.length).toBeGreaterThan(0)
    })

    it('should create cube items with correct structure', () => {
      const cubeItem = mockElements.generatorsList.children[0] as HTMLElement
      expect(cubeItem.classList.contains('cube-item')).toBe(true)
      expect(cubeItem.dataset.cubeType).toBe(CubeType.OSCILLATOR)
      
      const preview = cubeItem.querySelector('.cube-preview')
      const info = cubeItem.querySelector('.cube-info')
      const name = cubeItem.querySelector('.cube-name')
      const description = cubeItem.querySelector('.cube-description')
      
      expect(preview).toBeTruthy()
      expect(info).toBeTruthy()
      expect(name).toBeTruthy()
      expect(description).toBeTruthy()
    })
  })

  describe('Cube Selection', () => {
    it('should select cube type when clicked', () => {
      // Get the first cube item (should be oscillator)
      const cubeItem = mockElements.generatorsList.children[0] as HTMLElement
      expect(cubeItem).toBeTruthy()
      expect(cubeItem.getAttribute('data-cube-type')).toBe(CubeType.OSCILLATOR)
      
      // Test the selection functionality directly
      uiManager.selectCubeTypeForTesting(CubeType.OSCILLATOR)
      
      expect(uiManager.getSelectedCubeType()).toBe(CubeType.OSCILLATOR)
      expect(uiManager.isInPlacementMode()).toBe(true)
      expect(mockEvents.cubeTypeSelected).toHaveBeenCalledWith(CubeType.OSCILLATOR)
    })

    it('should update visual selection when cube type is selected', () => {
      const cubeItem = mockElements.generatorsList.children[0] as HTMLElement
      expect(cubeItem).toBeTruthy()
      
      // Test the selection functionality directly
      uiManager.selectCubeTypeForTesting(CubeType.OSCILLATOR)
      
      expect(cubeItem.classList.contains('selected')).toBe(true)
    })

    it('should change cursor to crosshair in placement mode', () => {
      const cubeItem = mockElements.generatorsList.children[0] as HTMLElement
      
      // Simulate click
      cubeItem.click()
      
      expect(document.body.style.cursor).toBe('crosshair')
    })
  })

  describe('Placement Mode', () => {
    beforeEach(() => {
      // Select a cube type to enter placement mode
      uiManager.selectCubeTypeForTesting(CubeType.OSCILLATOR)
    })

    it('should cancel placement on Escape key', () => {
      // Simulate Escape key press
      const event = new KeyboardEvent('keydown', { key: 'Escape' })
      document.dispatchEvent(event)
      
      expect(uiManager.isInPlacementMode()).toBe(false)
      expect(uiManager.getSelectedCubeType()).toBe(null)
      expect(document.body.style.cursor).toBe('default')
    })

    it('should confirm placement and exit placement mode', () => {
      uiManager.confirmPlacement()
      
      expect(uiManager.isInPlacementMode()).toBe(false)
      expect(uiManager.getSelectedCubeType()).toBe(null)
      expect(document.body.style.cursor).toBe('default')
    })

    it('should remove selection visual when canceling placement', () => {
      const cubeItem = mockElements.generatorsList.children[0] as HTMLElement
      
      uiManager.cancelPlacement()
      
      expect(cubeItem.classList.contains('selected')).toBe(false)
    })
  })

  describe('Audio Controls', () => {
    it('should call startAudio event when start button is clicked', () => {
      mockElements.startAudioBtn.click()
      
      expect(mockEvents.startAudio).toHaveBeenCalled()
    })

    it('should call stopAudio event when stop button is clicked', () => {
      mockElements.stopAudioBtn.click()
      
      expect(mockEvents.stopAudio).toHaveBeenCalled()
    })

    it('should update audio state correctly', () => {
      uiManager.updateAudioState(true)
      
      expect(mockElements.startAudioBtn.disabled).toBe(true)
      expect(mockElements.stopAudioBtn.disabled).toBe(false)
      expect(mockElements.startAudioBtn.textContent).toBe('Audio Active')
    })
  })

  describe('Scene Controls', () => {
    it('should call clearScene event when clear button is clicked with confirmation', () => {
      // Mock window.confirm to return true
      vi.spyOn(window, 'confirm').mockReturnValue(true)
      
      mockElements.clearSceneBtn.click()
      
      expect(mockEvents.clearScene).toHaveBeenCalled()
    })

    it('should not call clearScene event when confirmation is canceled', () => {
      // Mock window.confirm to return false
      vi.spyOn(window, 'confirm').mockReturnValue(false)
      
      mockElements.clearSceneBtn.click()
      
      expect(mockEvents.clearScene).not.toHaveBeenCalled()
    })
  })

  describe('UI Visibility', () => {
    it('should show UI elements', () => {
      uiManager.showUI()
      
      expect(mockElements.cubePalette.style.display).toBe('block')
      expect(mockElements.controlPanel.style.display).toBe('block')
      expect(mockElements.instructions.style.display).toBe('block')
    })

    it('should hide UI elements', () => {
      uiManager.hideUI()
      
      expect(mockElements.cubePalette.style.display).toBe('none')
      expect(mockElements.controlPanel.style.display).toBe('none')
      expect(mockElements.instructions.style.display).toBe('none')
    })
  })

  describe('Toast Notifications', () => {
    it('should create and display toast notification', () => {
      const message = 'Test message'
      
      uiManager.showToast(message, 'info')
      
      // Check that a toast element was added to the body
      const toasts = document.body.querySelectorAll('.toast')
      expect(toasts.length).toBe(1)
      
      const toast = toasts[0] as HTMLElement
      expect(toast.textContent).toBe(message)
      expect(toast.classList.contains('toast-info')).toBe(true)
    })

    it('should apply correct styling for different toast types', () => {
      uiManager.showToast('Error message', 'error')
      
      const toast = document.body.querySelector('.toast-error') as HTMLElement
      expect(toast).toBeTruthy()
      // Browser converts hex to rgb, so check for the rgb value
      expect(toast.style.backgroundColor).toBe('rgb(231, 76, 60)')
    })
  })
})