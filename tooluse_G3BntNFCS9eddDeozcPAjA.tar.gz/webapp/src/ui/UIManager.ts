import { CubeType, CubeTypeDefinition } from '@/types'
import { CUBE_TYPES } from '@/config/cubeTypes'
import { ReactableApp } from '@/interfaces/ReactableApp'

export interface UIManagerEvents {
  cubeTypeSelected: (cubeType: CubeType) => void
  clearScene: () => void
  startAudio: () => void
  stopAudio: () => void
  startRecording: () => void
  pauseRecording: () => void
  stopRecording: () => void
  saveProject: () => void
  loadProject: () => void
  exportProject: () => void
  importProject: (file: File) => void
  newProject: () => void
}

export class UIManager {
  private events: UIManagerEvents
  private selectedCubeType: CubeType | null = null
  private isPlacementMode = false

  // UI Elements
  private cubePalette: HTMLElement
  private controlPanel: HTMLElement
  private instructions: HTMLElement
  private startAudioBtn: HTMLButtonElement
  private stopAudioBtn: HTMLButtonElement
  private clearSceneBtn: HTMLButtonElement
  private startRecordingBtn: HTMLButtonElement
  private pauseRecordingBtn: HTMLButtonElement
  private stopRecordingBtn: HTMLButtonElement
  private recordingStatus: HTMLElement
  private recordingTimer: HTMLElement

  constructor(_app: ReactableApp, events: UIManagerEvents) {
    this.events = events
    
    // Get UI elements
    this.cubePalette = document.getElementById('cube-palette')!
    this.controlPanel = document.getElementById('control-panel')!
    this.instructions = document.getElementById('instructions')!
    this.startAudioBtn = document.getElementById('start-audio-btn') as HTMLButtonElement
    this.stopAudioBtn = document.getElementById('stop-audio-btn') as HTMLButtonElement
    this.clearSceneBtn = document.getElementById('clear-scene-btn') as HTMLButtonElement
    this.startRecordingBtn = document.getElementById('start-recording-btn') as HTMLButtonElement
    this.pauseRecordingBtn = document.getElementById('pause-recording-btn') as HTMLButtonElement
    this.stopRecordingBtn = document.getElementById('stop-recording-btn') as HTMLButtonElement
    this.recordingStatus = document.getElementById('recording-status')!
    this.recordingTimer = document.getElementById('recording-timer')!

    this.initializePalette()
    this.setupEventListeners()
  }

  private initializePalette(): void {
    const generatorsList = document.getElementById('generators-list')!
    const effectsList = document.getElementById('effects-list')!
    const outputList = document.getElementById('output-list')!

    // Categorize cube types
    const categories = {
      generators: [CubeType.OSCILLATOR],
      effects: [CubeType.FILTER, CubeType.GAIN],
      output: [CubeType.OUTPUT]
    }

    // Create cube items for each category
    this.createCubeItems(generatorsList, categories.generators)
    this.createCubeItems(effectsList, categories.effects)
    this.createCubeItems(outputList, categories.output)
  }

  private createCubeItems(container: HTMLElement, cubeTypes: CubeType[]): void {
    cubeTypes.forEach(cubeType => {
      const definition = CUBE_TYPES[cubeType]
      const cubeItem = this.createCubeItem(definition)
      container.appendChild(cubeItem)
    })
  }

  private createCubeItem(definition: CubeTypeDefinition): HTMLElement {
    const cubeItem = document.createElement('div')
    cubeItem.className = 'cube-item'
    cubeItem.setAttribute('data-cube-type', definition.type)

    // Create preview box with cube type color
    const preview = document.createElement('div')
    preview.className = 'cube-preview'
    preview.style.backgroundColor = definition.color
    preview.textContent = this.getCubeIcon(definition.type)

    // Create info section
    const info = document.createElement('div')
    info.className = 'cube-info'

    const name = document.createElement('div')
    name.className = 'cube-name'
    name.textContent = definition.name

    const description = document.createElement('div')
    description.className = 'cube-description'
    description.textContent = definition.description

    info.appendChild(name)
    info.appendChild(description)

    cubeItem.appendChild(preview)
    cubeItem.appendChild(info)

    // Add click handler
    cubeItem.addEventListener('click', () => {
      this.selectCubeType(definition.type)
    })

    return cubeItem
  }

  private getCubeIcon(cubeType: CubeType): string {
    const icons = {
      [CubeType.OSCILLATOR]: '♪',
      [CubeType.FILTER]: '⚡',
      [CubeType.GAIN]: '🔊',
      [CubeType.OUTPUT]: '📤'
    }
    return icons[cubeType] || '■'
  }

  private selectCubeType(cubeType: CubeType): void {
    // Update visual selection
    const allItems = this.cubePalette.querySelectorAll('.cube-item')
    allItems.forEach(item => item.classList.remove('selected'))

    // Find the selected item in any of the category containers
    const selectedItem = this.cubePalette.querySelector(`[data-cube-type="${cubeType}"]`)
    if (selectedItem) {
      selectedItem.classList.add('selected')
    }

    this.selectedCubeType = cubeType
    this.isPlacementMode = true
    
    // Update cursor to indicate placement mode
    document.body.style.cursor = 'crosshair'
    
    // Notify the application
    this.events.cubeTypeSelected(cubeType)
  }

  private setupEventListeners(): void {
    // Audio controls
    this.startAudioBtn.addEventListener('click', () => {
      this.events.startAudio()
    })

    this.stopAudioBtn.addEventListener('click', () => {
      this.events.stopAudio()
    })

    // Recording controls
    this.startRecordingBtn.addEventListener('click', () => {
      this.events.startRecording()
    })

    this.pauseRecordingBtn.addEventListener('click', () => {
      this.events.pauseRecording()
    })

    this.stopRecordingBtn.addEventListener('click', () => {
      this.events.stopRecording()
    })

    // Scene controls
    this.clearSceneBtn.addEventListener('click', () => {
      if (confirm('Are you sure you want to clear all cubes?')) {
        this.events.clearScene()
      }
    })

    // Escape key to cancel placement mode
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && this.isPlacementMode) {
        this.cancelPlacement()
      }
    })
  }

  public showUI(): void {
    this.cubePalette.style.display = 'block'
    this.controlPanel.style.display = 'block'
    this.instructions.style.display = 'block'
  }

  public hideUI(): void {
    this.cubePalette.style.display = 'none'
    this.controlPanel.style.display = 'none'
    this.instructions.style.display = 'none'
  }

  public updateAudioState(isStarted: boolean): void {
    this.startAudioBtn.disabled = isStarted
    this.stopAudioBtn.disabled = !isStarted
    
    if (isStarted) {
      this.startAudioBtn.textContent = 'Audio Active'
      this.startAudioBtn.style.background = 'rgba(76, 175, 80, 0.3)'
    } else {
      this.startAudioBtn.textContent = 'Start Audio'
      this.startAudioBtn.style.background = ''
    }
  }

  public getSelectedCubeType(): CubeType | null {
    return this.selectedCubeType
  }

  public isInPlacementMode(): boolean {
    return this.isPlacementMode
  }

  public cancelPlacement(): void {
    this.isPlacementMode = false
    this.selectedCubeType = null
    document.body.style.cursor = 'default'
    
    // Remove selection from all items
    const allItems = this.cubePalette.querySelectorAll('.cube-item')
    allItems.forEach(item => item.classList.remove('selected'))
  }

  public confirmPlacement(): void {
    this.cancelPlacement()
  }

  // Public method for testing
  public selectCubeTypeForTesting(cubeType: CubeType): void {
    this.selectCubeType(cubeType)
  }

  public updateRecordingState(state: { isRecording: boolean; isPaused: boolean; duration: number; maxDuration: number }): void {
    // Update button states
    this.startRecordingBtn.disabled = state.isRecording
    this.pauseRecordingBtn.disabled = !state.isRecording
    this.stopRecordingBtn.disabled = !state.isRecording

    // Update button text based on state
    if (state.isRecording) {
      this.startRecordingBtn.textContent = 'Recording...'
      this.startRecordingBtn.style.background = 'rgba(231, 76, 60, 0.3)'
      
      if (state.isPaused) {
        this.pauseRecordingBtn.textContent = 'Resume'
        this.pauseRecordingBtn.style.background = 'rgba(76, 175, 80, 0.3)'
      } else {
        this.pauseRecordingBtn.textContent = 'Pause'
        this.pauseRecordingBtn.style.background = 'rgba(243, 156, 18, 0.3)'
      }
    } else {
      this.startRecordingBtn.textContent = 'Start Recording'
      this.startRecordingBtn.style.background = ''
      this.pauseRecordingBtn.textContent = 'Pause'
      this.pauseRecordingBtn.style.background = ''
    }

    // Update recording status
    if (state.isRecording) {
      this.recordingStatus.textContent = state.isPaused ? 'PAUSED' : 'RECORDING'
      this.recordingStatus.style.color = state.isPaused ? '#f39c12' : '#e74c3c'
      this.recordingStatus.style.display = 'block'
    } else {
      this.recordingStatus.style.display = 'none'
    }

    // Update timer
    const minutes = Math.floor(state.duration / 60)
    const seconds = Math.floor(state.duration % 60)
    const maxMinutes = Math.floor(state.maxDuration / 60)
    const maxSeconds = Math.floor(state.maxDuration % 60)
    
    this.recordingTimer.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')} / ${maxMinutes.toString().padStart(2, '0')}:${maxSeconds.toString().padStart(2, '0')}`
    
    if (state.isRecording) {
      this.recordingTimer.style.display = 'block'
      // Change color as we approach max duration
      const progress = state.duration / state.maxDuration
      if (progress > 0.9) {
        this.recordingTimer.style.color = '#e74c3c'
      } else if (progress > 0.75) {
        this.recordingTimer.style.color = '#f39c12'
      } else {
        this.recordingTimer.style.color = '#4ecdc4'
      }
    } else {
      this.recordingTimer.style.display = 'none'
    }
  }

  public updateRecordingSupport(isSupported: boolean): void {
    if (!isSupported) {
      this.startRecordingBtn.disabled = true
      this.startRecordingBtn.textContent = 'Recording Not Supported'
      this.startRecordingBtn.title = 'Your browser does not support audio recording'
    }
  }

  public showToast(message: string, type: 'info' | 'warning' | 'error' = 'info'): void {
    // Create toast notification
    const toast = document.createElement('div')
    toast.className = `toast toast-${type}`
    toast.textContent = message
    
    // Style the toast
    Object.assign(toast.style, {
      position: 'fixed',
      top: '20px',
      right: '20px',
      padding: '12px 16px',
      borderRadius: '6px',
      color: 'white',
      fontSize: '14px',
      zIndex: '1000',
      opacity: '0',
      transform: 'translateY(-20px)',
      transition: 'all 0.3s ease',
      maxWidth: '300px',
      wordWrap: 'break-word'
    })

    // Set background color based on type
    const colors = {
      info: '#4ecdc4',
      warning: '#f39c12',
      error: '#e74c3c'
    }
    toast.style.backgroundColor = colors[type]

    document.body.appendChild(toast)

    // Animate in
    requestAnimationFrame(() => {
      toast.style.opacity = '1'
      toast.style.transform = 'translateY(0)'
    })

    // Remove after 3 seconds
    setTimeout(() => {
      toast.style.opacity = '0'
      toast.style.transform = 'translateY(-20px)'
      setTimeout(() => {
        if (toast.parentNode) {
          toast.parentNode.removeChild(toast)
        }
      }, 300)
    }, 3000)
  }
}