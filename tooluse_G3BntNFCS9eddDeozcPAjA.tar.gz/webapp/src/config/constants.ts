// Performance constants
export const PERFORMANCE_TARGETS = {
  TARGET_FPS: 60,
  MAX_AUDIO_LATENCY: 20, // milliseconds
  MAX_CUBES: 20,
  MAX_MEMORY_MB: 100
} as const

// Audio constants
export const AUDIO_CONFIG = {
  SAMPLE_RATE: 44100,
  BUFFER_SIZE: 256,
  MAX_GAIN: 2.0,
  SAFETY_GAIN_LIMIT: 1.0
} as const

// 3D Scene constants
export const SCENE_CONFIG = {
  TABLE_SIZE: 10,
  CUBE_SIZE: 0.5,
  CONNECTION_DISTANCE: 2.0,
  CAMERA_DISTANCE: 15,
  CAMERA_HEIGHT: 10
} as const

// UI constants
export const UI_CONFIG = {
  TOAST_DURATION: 3000,
  ANIMATION_DURATION: 300,
  DEBOUNCE_DELAY: 100
} as const

// Project constants
export const PROJECT_CONFIG = {
  VERSION: '1.0.0',
  MAX_PROJECT_SIZE_MB: 10,
  AUTO_SAVE_INTERVAL: 30000 // 30 seconds
} as const