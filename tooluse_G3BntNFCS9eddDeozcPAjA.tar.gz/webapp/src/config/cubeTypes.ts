import { CubeType, CubeTypeDefinition } from '@/types'

export const CUBE_TYPES: Record<CubeType, CubeTypeDefinition> = {
  [CubeType.OSCILLATOR]: {
    type: CubeType.OSCILLATOR,
    name: 'Oscillator',
    description: 'Generates basic waveforms',
    parameters: [
      {
        name: 'frequency',
        displayName: 'Frequency',
        min: 20,
        max: 2000,
        default: 440,
        scale: 'logarithmic',
        unit: 'Hz',
        mappedTo: '3d-transform'
      },
      {
        name: 'detune',
        displayName: 'Detune',
        min: -100,
        max: 100,
        default: 0,
        scale: 'linear',
        unit: 'cents',
        mappedTo: '3d-transform'
      }
    ],
    defaultValues: { frequency: 440, detune: 0, type: 0 },
    color: '#ff6b6b',
    canConnect: { input: false, output: true }
  },
  
  [CubeType.FILTER]: {
    type: CubeType.FILTER,
    name: 'Filter',
    description: 'Filters audio frequencies',
    parameters: [
      {
        name: 'cutoff',
        displayName: 'Cutoff',
        min: 20,
        max: 20000,
        default: 1000,
        scale: 'logarithmic',
        unit: 'Hz',
        mappedTo: '3d-transform'
      },
      {
        name: 'resonance',
        displayName: 'Resonance',
        min: 0.1,
        max: 30,
        default: 1,
        scale: 'logarithmic',
        unit: 'Q',
        mappedTo: '3d-transform'
      }
    ],
    defaultValues: { cutoff: 1000, resonance: 1, type: 0 },
    color: '#4ecdc4',
    canConnect: { input: true, output: true }
  },
  
  [CubeType.GAIN]: {
    type: CubeType.GAIN,
    name: 'Gain',
    description: 'Controls volume level',
    parameters: [
      {
        name: 'gain',
        displayName: 'Gain',
        min: 0,
        max: 2,
        default: 0.5,
        scale: 'linear',
        unit: 'x',
        mappedTo: '3d-transform'
      }
    ],
    defaultValues: { gain: 0.5 },
    color: '#45b7d1',
    canConnect: { input: true, output: true }
  },
  
  [CubeType.OUTPUT]: {
    type: CubeType.OUTPUT,
    name: 'Output',
    description: 'Audio output destination',
    parameters: [],
    defaultValues: {},
    color: '#f9ca24',
    canConnect: { input: true, output: false }
  }
}