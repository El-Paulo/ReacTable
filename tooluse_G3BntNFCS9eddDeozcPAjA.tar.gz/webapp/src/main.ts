import { ReactableAppImpl } from '@/core/ReactableAppImpl'

// Main application entry point
async function main() {
  try {
    // Initialize the ReacTable application
    const app = new ReactableAppImpl()
    
    // Set up the start button
    const startButton = document.getElementById('start-button') as HTMLButtonElement
    if (!startButton) {
      throw new Error('Start button not found')
    }
    
    // Initialize the app (without audio)
    await app.initialize()
    
    // Handle start button click
    startButton.addEventListener('click', async () => {
      try {
        startButton.disabled = true
        startButton.textContent = 'Starting...'
        
        // Start audio context (requires user gesture)
        await app.startAudio()
        
        // Hide the start button
        startButton.style.display = 'none'
        
        console.log('ReacTable 3D Emulator started successfully!')
      } catch (error) {
        console.error('Failed to start ReacTable:', error)
        startButton.disabled = false
        startButton.textContent = 'Start ReacTable'
        startButton.style.background = '#ff6b6b'
      }
    })
    
    // Start the render loop
    let lastTime = 0
    function animate(currentTime: number) {
      const deltaTime = currentTime - lastTime
      lastTime = currentTime
      
      app.update(deltaTime)
      app.render()
      
      requestAnimationFrame(animate)
    }
    
    requestAnimationFrame(animate)
    
  } catch (error) {
    console.error('Failed to initialize ReacTable:', error)
    
    // Show error message to user
    const startButton = document.getElementById('start-button') as HTMLButtonElement
    if (startButton) {
      startButton.textContent = 'Failed to Load'
      startButton.style.background = '#ff6b6b'
      startButton.disabled = true
    }
  }
}

// Start the application
main().catch(console.error)