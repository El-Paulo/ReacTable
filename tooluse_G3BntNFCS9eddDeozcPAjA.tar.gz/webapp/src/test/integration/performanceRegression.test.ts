// Performance regression and load testing
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest'
import { setupIntegrationTestEnvironment, PerformanceTestHelper } from './setup'
import { ReactableAppImpl } from '../../core/ReactableAppImpl'
import { CubeType } from '../../types'

describe('Performance Regression Tests', () => {
  let app: ReactableAppImpl
  let testEnv: ReturnType<typeof setupIntegrationTestEnvironment>
  let performanceHelper: PerformanceTestHelper
  let container: HTMLElement

  beforeEach(async () => {
    testEnv = setupIntegrationTestEnvironment()
    performanceHelper = new PerformanceTestHelper()
    
    container = document.createElement('div')
    container.style.width = '800px'
    container.style.height = '600px'
    document.body.appendChild(container)

    app = new ReactableAppImpl()
    await app.initialize(container)
  })

  afterEach(() => {
    if (container && container.parentNode) {
      container.parentNode.removeChild(container)
    }
    vi.clearAllMocks()
  })

  describe('Frame Rate Performance Tests', () => {
    it('should maintain 60 FPS with up to 20 cubes', async () => {
      testEnv.simulateUserGesture()
      await app.startAudio()

      // Create 20 cubes (requirement limit)
      const cubeIds: string[] = []
      for (let i = 0; i < 20; i++) {
        const id = await app.createCube(CubeType.OSCILLATOR, { 
          x: (i % 5) * 2, 
          y: 0, 
          z: Math.floor(i / 5) * 2 
        })
        cubeIds.push(id)
      }

      // Measure FPS over 2 seconds
      performanceHelper.startFPSMeasurement()
      const frameCount = 120 // 2 seconds at 60 FPS
      
      for (let frame = 0; frame < frameCount; frame++) {
        const deltaTime = 16.67 // 60 FPS
        app.update(deltaTime)
        app.render()
        performanceHelper.recordFrame()
        
        // Simulate some cube movement to stress test
        if (frame % 10 === 0) {
          const cubeIndex = frame % cubeIds.length
          await app.rotateCube(cubeIds[cubeIndex], { 
            x: 0, 
            y: (frame * 0.01) % (Math.PI * 2), 
            z: 0 
          })
        }
        
        await new Promise(resolve => setTimeout(resolve, 16))
      }

      const fps = performanceHelper.getFPS()
      expect(fps).toBeGreaterThanOrEqual(50) // Allow 10 FPS tolerance for test environment
    })

    it('should detect performance degradation with excessive cubes', async () => {
      testEnv.simulateUserGesture()
      await app.startAudio()

      // Create more cubes than recommended
      const cubeIds: string[] = []
      for (let i = 0; i < 30; i++) {
        const id = await app.createCube(CubeType.OSCILLATOR, { 
          x: (i % 6) * 2, 
          y: 0, 
          z: Math.floor(i / 6) * 2 
        })
        cubeIds.push(id)
      }

      // Measure performance with heavy load
      performanceHelper.startFPSMeasurement()
      
      for (let frame = 0; frame < 60; frame++) {
        app.update(16.67)
        app.render()
        performanceHelper.recordFrame()
        
        // Heavy manipulation to stress test
        for (let i = 0; i < 5; i++) {
          const cubeIndex = (frame + i) % cubeIds.length
          await app.rotateCube(cubeIds[cubeIndex], { 
            x: Math.sin(frame * 0.1), 
            y: Math.cos(frame * 0.1), 
            z: 0 
          })
        }
        
        await new Promise(resolve => setTimeout(resolve, 16))
      }

      const fps = performanceHelper.getFPS()
      // Should detect performance issues with excessive load
      expect(fps).toBeLessThan(60)
    })

    it('should recover performance after cube cleanup', async () => {
      testEnv.simulateUserGesture()
      await app.startAudio()

      // Create many cubes
      const cubeIds: string[] = []
      for (let i = 0; i < 25; i++) {
        const id = await app.createCube(CubeType.OSCILLATOR, { x: i, y: 0, z: 0 })
        cubeIds.push(id)
      }

      // Measure degraded performance
      performanceHelper.startFPSMeasurement()
      for (let frame = 0; frame < 30; frame++) {
        app.update(16.67)
        app.render()
        performanceHelper.recordFrame()
        await new Promise(resolve => setTimeout(resolve, 16))
      }
      const degradedFPS = performanceHelper.getFPS()

      // Clean up cubes
      for (const id of cubeIds.slice(15)) { // Remove 10 cubes
        await app.deleteCube(id)
      }

      // Measure recovered performance
      performanceHelper.startFPSMeasurement()
      for (let frame = 0; frame < 30; frame++) {
        app.update(16.67)
        app.render()
        performanceHelper.recordFrame()
        await new Promise(resolve => setTimeout(resolve, 16))
      }
      const recoveredFPS = performanceHelper.getFPS()

      expect(recoveredFPS).toBeGreaterThan(degradedFPS)
    })
  })

  describe('Audio Latency Performance Tests', () => {
    it('should maintain audio latency under 20ms', async () => {
      testEnv.simulateUserGesture()
      await app.startAudio()

      const cubeId = await app.createCube(CubeType.OSCILLATOR, { x: 0, y: 0, z: 0 })

      // Test parameter update latency
      const latencyTests = []
      for (let i = 0; i < 10; i++) {
        const { duration } = await performanceHelper.measureAsyncOperation(async () => {
          await app.rotateCube(cubeId, { x: 0, y: i * 0.1, z: 0 })
        })
        latencyTests.push(duration)
      }

      const averageLatency = latencyTests.reduce((a, b) => a + b, 0) / latencyTests.length
      expect(averageLatency).toBeLessThan(20) // Requirement: < 20ms
    })

    it('should handle rapid parameter changes without audio dropouts', async () => {
      testEnv.simulateUserGesture()
      await app.startAudio()

      const cubeId = await app.createCube(CubeType.FILTER, { x: 0, y: 0, z: 0 })

      // Rapid parameter changes
      const startTime = performance.now()
      for (let i = 0; i < 100; i++) {
        await app.rotateCube(cubeId, { 
          x: 0, 
          y: Math.sin(i * 0.1) * Math.PI, 
          z: 0 
        })
      }
      const endTime = performance.now()

      const totalTime = endTime - startTime
      const averageTimePerUpdate = totalTime / 100
      
      expect(averageTimePerUpdate).toBeLessThan(10) // Should be very fast
    })

    it('should maintain audio performance with multiple active cubes', async () => {
      testEnv.simulateUserGesture()
      await app.startAudio()

      // Create audio chain
      const oscillatorIds: string[] = []
      for (let i = 0; i < 5; i++) {
        const id = await app.createCube(CubeType.OSCILLATOR, { x: i * 2, y: 0, z: 0 })
        oscillatorIds.push(id)
      }

      const filterId = await app.createCube(CubeType.FILTER, { x: 10, y: 0, z: 0 })
      const outputId = await app.createCube(CubeType.OUTPUT, { x: 12, y: 0, z: 0 })

      // Wait for connections
      await new Promise(resolve => setTimeout(resolve, 200))

      // Test simultaneous parameter updates
      const { duration } = await performanceHelper.measureAsyncOperation(async () => {
        const updatePromises = oscillatorIds.map((id, index) =>
          app.rotateCube(id, { x: 0, y: index * Math.PI / 4, z: 0 })
        )
        await Promise.all(updatePromises)
      })

      expect(duration).toBeLessThan(50) // Should handle multiple updates efficiently
    })
  })

  describe('Memory Performance Tests', () => {
    it('should not leak memory during cube lifecycle', async () => {
      testEnv.simulateUserGesture()
      await app.startAudio()

      const initialMemory = (performance as any).memory?.usedJSHeapSize || 0

      // Create and destroy cubes multiple times
      for (let cycle = 0; cycle < 5; cycle++) {
        const cubeIds: string[] = []
        
        // Create cubes
        for (let i = 0; i < 10; i++) {
          const id = await app.createCube(CubeType.OSCILLATOR, { x: i, y: 0, z: 0 })
          cubeIds.push(id)
        }

        // Use cubes
        for (const id of cubeIds) {
          await app.rotateCube(id, { x: 0, y: Math.PI / 4, z: 0 })
        }

        // Destroy cubes
        for (const id of cubeIds) {
          await app.deleteCube(id)
        }

        // Force garbage collection if available
        if ((global as any).gc) {
          (global as any).gc()
        }
        
        await new Promise(resolve => setTimeout(resolve, 100))
      }

      const finalMemory = (performance as any).memory?.usedJSHeapSize || 0

      if (initialMemory > 0 && finalMemory > 0) {
        const memoryGrowth = finalMemory - initialMemory
        expect(memoryGrowth).toBeLessThan(10 * 1024 * 1024) // Less than 10MB growth
      }
    })

    it('should handle memory efficiently with complex connections', async () => {
      testEnv.simulateUserGesture()
      await app.startAudio()

      const initialMemory = (performance as any).memory?.usedJSHeapSize || 0

      // Create complex connection network
      const cubeIds: string[] = []
      for (let i = 0; i < 15; i++) {
        const type = [CubeType.OSCILLATOR, CubeType.FILTER, CubeType.GAIN][i % 3]
        const id = await app.createCube(type, { 
          x: (i % 5) * 1.8, 
          y: 0, 
          z: Math.floor(i / 5) * 1.8 
        })
        cubeIds.push(id)
      }

      // Add output cube
      const outputId = await app.createCube(CubeType.OUTPUT, { x: 10, y: 0, z: 10 })

      // Wait for automatic connections
      await new Promise(resolve => setTimeout(resolve, 500))

      const peakMemory = (performance as any).memory?.usedJSHeapSize || 0

      // Clean up
      for (const id of cubeIds) {
        await app.deleteCube(id)
      }
      await app.deleteCube(outputId)

      if ((global as any).gc) {
        (global as any).gc()
      }
      
      await new Promise(resolve => setTimeout(resolve, 200))

      const finalMemory = (performance as any).memory?.usedJSHeapSize || 0

      if (initialMemory > 0 && peakMemory > 0 && finalMemory > 0) {
        const memoryGrowth = finalMemory - initialMemory
        expect(memoryGrowth).toBeLessThan(20 * 1024 * 1024) // Less than 20MB growth
      }
    })
  })

  describe('Load Testing Scenarios', () => {
    it('should handle maximum cube count scenario', async () => {
      testEnv.simulateUserGesture()
      await app.startAudio()

      // Test with maximum recommended cubes
      const maxCubes = 20
      const cubeIds: string[] = []

      const { duration: creationTime } = await performanceHelper.measureAsyncOperation(async () => {
        for (let i = 0; i < maxCubes; i++) {
          const id = await app.createCube(CubeType.OSCILLATOR, { 
            x: (i % 5) * 2, 
            y: 0, 
            z: Math.floor(i / 5) * 2 
          })
          cubeIds.push(id)
        }
      })

      expect(creationTime).toBeLessThan(5000) // Should create all cubes within 5 seconds
      expect(app.getState().cubes.size).toBe(maxCubes)

      // Test manipulation performance with max cubes
      const { duration: manipulationTime } = await performanceHelper.measureAsyncOperation(async () => {
        for (const id of cubeIds) {
          await app.rotateCube(id, { x: 0, y: Math.PI / 4, z: 0 })
        }
      })

      expect(manipulationTime).toBeLessThan(2000) // Should manipulate all cubes within 2 seconds
    })

    it('should handle maximum connection scenario', async () => {
      testEnv.simulateUserGesture()
      await app.startAudio()

      // Create cubes in a pattern that maximizes connections
      const cubeIds: string[] = []
      
      // Create oscillators
      for (let i = 0; i < 5; i++) {
        const id = await app.createCube(CubeType.OSCILLATOR, { x: i * 1.5, y: 0, z: 0 })
        cubeIds.push(id)
      }

      // Create filters
      for (let i = 0; i < 5; i++) {
        const id = await app.createCube(CubeType.FILTER, { x: i * 1.5, y: 0, z: 1.5 })
        cubeIds.push(id)
      }

      // Create gains
      for (let i = 0; i < 5; i++) {
        const id = await app.createCube(CubeType.GAIN, { x: i * 1.5, y: 0, z: 3 })
        cubeIds.push(id)
      }

      // Create output
      const outputId = await app.createCube(CubeType.OUTPUT, { x: 2, y: 0, z: 4.5 })

      // Wait for all connections to establish
      await new Promise(resolve => setTimeout(resolve, 1000))

      const connections = app.getState().connections
      expect(connections.length).toBeGreaterThan(10) // Should have many connections

      // Test performance with many connections
      performanceHelper.startFPSMeasurement()
      for (let frame = 0; frame < 60; frame++) {
        app.update(16.67)
        app.render()
        performanceHelper.recordFrame()
        await new Promise(resolve => setTimeout(resolve, 16))
      }

      const fps = performanceHelper.getFPS()
      expect(fps).toBeGreaterThanOrEqual(30) // Should maintain reasonable performance
    })

    it('should handle stress test with rapid operations', async () => {
      testEnv.simulateUserGesture()
      await app.startAudio()

      const cubeId = await app.createCube(CubeType.OSCILLATOR, { x: 0, y: 0, z: 0 })

      // Rapid operations stress test
      const operations = []
      const startTime = performance.now()

      for (let i = 0; i < 200; i++) {
        operations.push(
          app.rotateCube(cubeId, { 
            x: Math.sin(i * 0.1), 
            y: Math.cos(i * 0.1), 
            z: 0 
          })
        )
      }

      await Promise.all(operations)
      const endTime = performance.now()

      const totalTime = endTime - startTime
      expect(totalTime).toBeLessThan(2000) // Should handle 200 operations within 2 seconds

      // Verify cube is still functional
      const cube = app.getState().cubes.get(cubeId)
      expect(cube).toBeDefined()
      expect(cube?.isActive).toBe(true)
    })
  })

  describe('Performance Monitoring Integration', () => {
    it('should accurately report performance metrics', async () => {
      testEnv.simulateUserGesture()
      await app.startAudio()

      // Create some cubes to generate load
      for (let i = 0; i < 10; i++) {
        await app.createCube(CubeType.OSCILLATOR, { x: i, y: 0, z: 0 })
      }

      // Get performance metrics from the app
      const performanceMonitor = (app as any).performanceMonitor
      if (performanceMonitor) {
        const metrics = performanceMonitor.getMetrics()
        
        expect(metrics).toHaveProperty('fps')
        expect(metrics).toHaveProperty('audioLatency')
        expect(metrics).toHaveProperty('memoryUsage')
        
        expect(typeof metrics.fps).toBe('number')
        expect(metrics.fps).toBeGreaterThan(0)
        expect(metrics.fps).toBeLessThanOrEqual(60)
      }
    })

    it('should trigger performance warnings appropriately', async () => {
      testEnv.simulateUserGesture()
      await app.startAudio()

      // Create excessive cubes to trigger warnings
      for (let i = 0; i < 25; i++) {
        await app.createCube(CubeType.OSCILLATOR, { x: i, y: 0, z: 0 })
      }

      // Simulate poor performance
      performanceHelper.startFPSMeasurement()
      for (let frame = 0; frame < 30; frame++) {
        performanceHelper.recordFrame()
        await new Promise(resolve => setTimeout(resolve, 50)) // Simulate slow frames
      }

      const fps = performanceHelper.getFPS()
      expect(fps).toBeLessThan(30) // Should detect performance issues

      // Performance monitor should detect this
      const performanceMonitor = (app as any).performanceMonitor
      if (performanceMonitor) {
        const status = performanceMonitor.checkPerformance()
        expect(status.isDegraded).toBe(true)
      }
    })
  })
})