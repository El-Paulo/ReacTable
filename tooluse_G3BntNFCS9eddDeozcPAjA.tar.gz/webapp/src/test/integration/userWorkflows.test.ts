// End-to-end user workflow integration tests
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest'
import { setupIntegrationTestEnvironment, PerformanceTestHelper } from './setup'
import { ReactableAppImpl } from '../../core/ReactableAppImpl'
import { RenderEngineImpl } from '../../rendering/RenderEngineImpl'
import { AudioEngineImpl } from '../../audio/AudioEngineImpl'
import { CubeManagerImpl } from '../../core/CubeManagerImpl'
import { ConnectionManagerImpl } from '../../core/ConnectionManagerImpl'
import { InteractionManagerImpl } from '../../core/InteractionManagerImpl'
import { ProjectManager } from '../../services/ProjectManager'
import { CubeType } from '../../types'

describe('User Workflow Integration Tests', () => {
  let app: ReactableAppImpl
  let testEnv: ReturnType<typeof setupIntegrationTestEnvironment>
  let performanceHelper: PerformanceTestHelper
  let container: HTMLElement

  beforeEach(async () => {
    // Setup test environment
    testEnv = setupIntegrationTestEnvironment()
    performanceHelper = new PerformanceTestHelper()

    // Create DOM container
    container = document.createElement('div')
    container.style.width = '800px'
    container.style.height = '600px'
    document.body.appendChild(container)

    // Initialize application
    app = new ReactableAppImpl()
    await app.initialize(container)
  })

  afterEach(() => {
    if (container && container.parentNode) {
      container.parentNode.removeChild(container)
    }
    vi.clearAllMocks()
  })

  describe('Complete User Workflow: Create → Connect → Play → Save', () => {
    it('should complete full workflow successfully', async () => {
      // Step 1: Start audio (simulate user gesture)
      testEnv.simulateUserGesture()
      await app.startAudio()
      expect(app.getState().isAudioStarted).toBe(true)

      // Step 2: Create oscillator cube
      testEnv.simulateMouseEvent('click', 200, 300, container)
      const oscillatorId = await app.createCube(CubeType.OSCILLATOR, { x: 0, y: 0, z: 0 })
      expect(oscillatorId).toBeDefined()
      expect(app.getState().cubes.has(oscillatorId)).toBe(true)

      // Step 3: Create filter cube nearby
      const filterId = await app.createCube(CubeType.FILTER, { x: 1.5, y: 0, z: 0 })
      expect(filterId).toBeDefined()

      // Step 4: Create output cube
      const outputId = await app.createCube(CubeType.OUTPUT, { x: 3, y: 0, z: 0 })
      expect(outputId).toBeDefined()

      // Step 5: Verify automatic connections
      await new Promise(resolve => setTimeout(resolve, 100)) // Allow connection detection
      const connections = app.getState().connections
      expect(connections.length).toBeGreaterThan(0)

      // Step 6: Manipulate cube parameters
      await app.rotateCube(oscillatorId, { x: 0, y: Math.PI / 4, z: 0 })
      await app.rotateCube(filterId, { x: 0, y: Math.PI / 6, z: 0 })

      // Step 7: Save project
      const projectData = await app.saveProject('test-workflow')
      expect(projectData).toBeDefined()
      expect(projectData.cubes).toHaveLength(3)
      expect(projectData.connections.length).toBeGreaterThan(0)

      // Step 8: Clear and load project
      await app.clearProject()
      expect(app.getState().cubes.size).toBe(0)

      await app.loadProject(projectData)
      expect(app.getState().cubes.size).toBe(3)
      expect(app.getState().connections.length).toBeGreaterThan(0)
    })

    it('should handle cube manipulation workflow', async () => {
      testEnv.simulateUserGesture()
      await app.startAudio()

      // Create cube
      const cubeId = await app.createCube(CubeType.OSCILLATOR, { x: 0, y: 0, z: 0 })
      
      // Test selection
      await app.selectCube(cubeId)
      expect(app.getState().selectedCube).toBe(cubeId)

      // Test movement
      const newPosition = { x: 2, y: 0, z: 1 }
      await app.moveCube(cubeId, newPosition)
      const cube = app.getState().cubes.get(cubeId)
      expect(cube?.transform.position).toEqual(newPosition)

      // Test rotation
      const newRotation = { x: 0, y: Math.PI / 2, z: 0 }
      await app.rotateCube(cubeId, newRotation)
      expect(cube?.transform.rotation).toEqual(newRotation)

      // Test deletion
      await app.deleteCube(cubeId)
      expect(app.getState().cubes.has(cubeId)).toBe(false)
    })

    it('should handle recording workflow', async () => {
      testEnv.simulateUserGesture()
      await app.startAudio()

      // Create audio setup
      const oscillatorId = await app.createCube(CubeType.OSCILLATOR, { x: 0, y: 0, z: 0 })
      const outputId = await app.createCube(CubeType.OUTPUT, { x: 2, y: 0, z: 0 })

      // Wait for connections
      await new Promise(resolve => setTimeout(resolve, 100))

      // Start recording
      await app.startRecording()
      expect(app.getState().isRecording).toBe(true)

      // Simulate some interaction
      await app.rotateCube(oscillatorId, { x: 0, y: Math.PI / 4, z: 0 })
      await new Promise(resolve => setTimeout(resolve, 500))

      // Stop recording
      const recordingBlob = await app.stopRecording()
      expect(recordingBlob).toBeInstanceOf(Blob)
      expect(app.getState().isRecording).toBe(false)
    })
  })

  describe('Error Handling Workflows', () => {
    it('should handle audio context failures gracefully', async () => {
      // Mock audio context failure
      testEnv.mockAudioContext.resume = vi.fn().mockRejectedValue(new Error('Audio context failed'))

      testEnv.simulateUserGesture()
      
      // Should handle error gracefully
      await expect(app.startAudio()).rejects.toThrow('Audio context failed')
      expect(app.getState().isAudioStarted).toBe(false)
    })

    it('should handle invalid project data', async () => {
      const invalidProject = {
        version: '1.0.0',
        cubes: [
          {
            id: 'invalid',
            type: 'invalid-type' as CubeType,
            position: [0, 0, 0],
            rotation: [0, 0, 0],
            scale: [1, 1, 1],
            parameters: {},
          },
        ],
        connections: [],
        metadata: {
          name: 'invalid',
          created: new Date().toISOString(),
          modified: new Date().toISOString(),
        },
        settings: {
          masterVolume: 1,
          tempo: 120,
          scale: 'chromatic',
        },
      }

      await expect(app.loadProject(invalidProject)).rejects.toThrow()
    })

    it('should handle performance degradation', async () => {
      testEnv.simulateUserGesture()
      await app.startAudio()

      // Create many cubes to trigger performance monitoring
      const cubeIds: string[] = []
      for (let i = 0; i < 25; i++) {
        const id = await app.createCube(CubeType.OSCILLATOR, { x: i, y: 0, z: 0 })
        cubeIds.push(id)
      }

      // Simulate performance degradation
      performanceHelper.startFPSMeasurement()
      for (let i = 0; i < 30; i++) {
        performanceHelper.recordFrame()
        await new Promise(resolve => setTimeout(resolve, 50)) // Simulate slow frames
      }

      const fps = performanceHelper.getFPS()
      expect(fps).toBeLessThan(60) // Should detect performance issues
    })
  })

  describe('Complex Interaction Workflows', () => {
    it('should handle multi-cube connection chains', async () => {
      testEnv.simulateUserGesture()
      await app.startAudio()

      // Create a chain: Oscillator → Filter → Gain → Output
      const oscillatorId = await app.createCube(CubeType.OSCILLATOR, { x: 0, y: 0, z: 0 })
      const filterId = await app.createCube(CubeType.FILTER, { x: 2, y: 0, z: 0 })
      const gainId = await app.createCube(CubeType.GAIN, { x: 4, y: 0, z: 0 })
      const outputId = await app.createCube(CubeType.OUTPUT, { x: 6, y: 0, z: 0 })

      // Wait for automatic connections
      await new Promise(resolve => setTimeout(resolve, 200))

      const connections = app.getState().connections
      expect(connections.length).toBeGreaterThanOrEqual(3) // Should have chain connections

      // Test parameter changes propagate through chain
      await app.rotateCube(oscillatorId, { x: 0, y: Math.PI / 3, z: 0 })
      await app.rotateCube(filterId, { x: 0, y: Math.PI / 6, z: 0 })
      await app.rotateCube(gainId, { x: 0, y: Math.PI / 4, z: 0 })

      // Verify cubes maintain their parameters
      const oscillator = app.getState().cubes.get(oscillatorId)
      const filter = app.getState().cubes.get(filterId)
      const gain = app.getState().cubes.get(gainId)

      expect(oscillator?.transform.rotation.y).toBeCloseTo(Math.PI / 3)
      expect(filter?.transform.rotation.y).toBeCloseTo(Math.PI / 6)
      expect(gain?.transform.rotation.y).toBeCloseTo(Math.PI / 4)
    })

    it('should handle rapid cube creation and deletion', async () => {
      testEnv.simulateUserGesture()
      await app.startAudio()

      const cubeIds: string[] = []

      // Rapidly create cubes
      for (let i = 0; i < 10; i++) {
        const id = await app.createCube(CubeType.OSCILLATOR, { x: i, y: 0, z: 0 })
        cubeIds.push(id)
      }

      expect(app.getState().cubes.size).toBe(10)

      // Rapidly delete cubes
      for (const id of cubeIds) {
        await app.deleteCube(id)
      }

      expect(app.getState().cubes.size).toBe(0)
      expect(app.getState().connections.length).toBe(0)
    })

    it('should handle simultaneous parameter changes', async () => {
      testEnv.simulateUserGesture()
      await app.startAudio()

      const cubeIds: string[] = []
      for (let i = 0; i < 5; i++) {
        const id = await app.createCube(CubeType.OSCILLATOR, { x: i * 2, y: 0, z: 0 })
        cubeIds.push(id)
      }

      // Simultaneously change parameters on all cubes
      const rotationPromises = cubeIds.map((id, index) =>
        app.rotateCube(id, { x: 0, y: (index + 1) * Math.PI / 6, z: 0 })
      )

      await Promise.all(rotationPromises)

      // Verify all changes were applied
      cubeIds.forEach((id, index) => {
        const cube = app.getState().cubes.get(id)
        expect(cube?.transform.rotation.y).toBeCloseTo((index + 1) * Math.PI / 6)
      })
    })
  })

  describe('Performance Regression Tests', () => {
    it('should maintain 60 FPS with moderate cube count', async () => {
      testEnv.simulateUserGesture()
      await app.startAudio()

      // Create moderate number of cubes
      for (let i = 0; i < 15; i++) {
        await app.createCube(CubeType.OSCILLATOR, { x: i, y: 0, z: 0 })
      }

      // Measure performance over multiple frames
      performanceHelper.startFPSMeasurement()
      
      for (let frame = 0; frame < 60; frame++) {
        app.update(16.67) // 60 FPS = 16.67ms per frame
        app.render()
        performanceHelper.recordFrame()
        await new Promise(resolve => setTimeout(resolve, 16))
      }

      const fps = performanceHelper.getFPS()
      expect(fps).toBeGreaterThanOrEqual(50) // Allow some tolerance
    })

    it('should handle audio latency requirements', async () => {
      testEnv.simulateUserGesture()
      await app.startAudio()

      const cubeId = await app.createCube(CubeType.OSCILLATOR, { x: 0, y: 0, z: 0 })

      // Measure parameter update latency
      const { duration } = await performanceHelper.measureAsyncOperation(async () => {
        await app.rotateCube(cubeId, { x: 0, y: Math.PI / 4, z: 0 })
      })

      expect(duration).toBeLessThan(20) // Should be under 20ms as per requirements
    })

    it('should handle memory usage with many cubes', async () => {
      testEnv.simulateUserGesture()
      await app.startAudio()

      const initialMemory = (performance as any).memory?.usedJSHeapSize || 0

      // Create many cubes
      const cubeIds: string[] = []
      for (let i = 0; i < 50; i++) {
        const id = await app.createCube(CubeType.OSCILLATOR, { x: i, y: 0, z: 0 })
        cubeIds.push(id)
      }

      const peakMemory = (performance as any).memory?.usedJSHeapSize || 0

      // Clean up cubes
      for (const id of cubeIds) {
        await app.deleteCube(id)
      }

      // Force garbage collection if available
      if ((global as any).gc) {
        (global as any).gc()
      }

      await new Promise(resolve => setTimeout(resolve, 100))

      const finalMemory = (performance as any).memory?.usedJSHeapSize || 0

      // Memory should not grow excessively
      if (initialMemory > 0 && peakMemory > 0 && finalMemory > 0) {
        const memoryGrowth = finalMemory - initialMemory
        expect(memoryGrowth).toBeLessThan(50 * 1024 * 1024) // Less than 50MB growth
      }
    })
  })
})