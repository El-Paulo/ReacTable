// Cross-browser compatibility integration tests
import { describe, it, expect, beforeEach, vi } from 'vitest'
import { setupIntegrationTestEnvironment, BrowserCompatibilityHelper } from './setup'
import { ReactableAppImpl } from '../../core/ReactableAppImpl'
import { CubeType } from '../../types'

describe('Browser Compatibility Integration Tests', () => {
  let app: ReactableAppImpl
  let testEnv: ReturnType<typeof setupIntegrationTestEnvironment>
  let container: HTMLElement

  beforeEach(async () => {
    testEnv = setupIntegrationTestEnvironment()
    
    container = document.createElement('div')
    container.style.width = '800px'
    container.style.height = '600px'
    document.body.appendChild(container)

    app = new ReactableAppImpl()
  })

  afterEach(() => {
    if (container && container.parentNode) {
      container.parentNode.removeChild(container)
    }
    vi.clearAllMocks()
  })

  describe('Chrome Browser Compatibility', () => {
    beforeEach(() => {
      // Mock Chrome-specific behavior
      Object.defineProperty(navigator, 'userAgent', {
        value: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        configurable: true,
      })
    })

    it('should initialize successfully in Chrome', async () => {
      await expect(app.initialize(container)).resolves.not.toThrow()
      expect(app.getState()).toBeDefined()
    })

    it('should support Web Audio API in Chrome', async () => {
      expect(BrowserCompatibilityHelper.checkWebAudioSupport()).toBe(true)
      
      testEnv.simulateUserGesture()
      await expect(app.startAudio()).resolves.not.toThrow()
      expect(app.getState().isAudioStarted).toBe(true)
    })

    it('should support WebGL in Chrome', async () => {
      expect(BrowserCompatibilityHelper.checkWebGLSupport()).toBe(true)
      
      await app.initialize(container)
      const cubeId = await app.createCube(CubeType.OSCILLATOR, { x: 0, y: 0, z: 0 })
      expect(cubeId).toBeDefined()
    })

    it('should support MediaRecorder in Chrome', async () => {
      expect(BrowserCompatibilityHelper.checkMediaRecorderSupport()).toBe(true)
      
      await app.initialize(container)
      testEnv.simulateUserGesture()
      await app.startAudio()
      
      await expect(app.startRecording()).resolves.not.toThrow()
      expect(app.getState().isRecording).toBe(true)
    })
  })

  describe('Edge Browser Compatibility', () => {
    beforeEach(() => {
      // Mock Edge-specific behavior
      Object.defineProperty(navigator, 'userAgent', {
        value: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0',
        configurable: true,
      })
    })

    it('should initialize successfully in Edge', async () => {
      await expect(app.initialize(container)).resolves.not.toThrow()
      expect(app.getState()).toBeDefined()
    })

    it('should handle Edge-specific audio context behavior', async () => {
      // Edge sometimes requires different audio context handling
      testEnv.mockAudioContext.state = 'suspended'
      
      testEnv.simulateUserGesture()
      await app.startAudio()
      
      expect(testEnv.mockAudioContext.resume).toHaveBeenCalled()
      expect(app.getState().isAudioStarted).toBe(true)
    })

    it('should support cube manipulation in Edge', async () => {
      await app.initialize(container)
      testEnv.simulateUserGesture()
      await app.startAudio()

      const cubeId = await app.createCube(CubeType.FILTER, { x: 0, y: 0, z: 0 })
      await app.rotateCube(cubeId, { x: 0, y: Math.PI / 4, z: 0 })
      
      const cube = app.getState().cubes.get(cubeId)
      expect(cube?.transform.rotation.y).toBeCloseTo(Math.PI / 4)
    })
  })

  describe('Firefox Browser Compatibility', () => {
    beforeEach(() => {
      // Mock Firefox-specific behavior
      Object.defineProperty(navigator, 'userAgent', {
        value: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:120.0) Gecko/20100101 Firefox/120.0',
        configurable: true,
      })

      // Firefox sometimes uses webkitAudioContext
      ;(global as any).webkitAudioContext = testEnv.mockAudioContext.constructor
    })

    it('should initialize successfully in Firefox', async () => {
      await expect(app.initialize(container)).resolves.not.toThrow()
      expect(app.getState()).toBeDefined()
    })

    it('should handle Firefox audio context differences', async () => {
      // Firefox might use webkitAudioContext fallback
      delete (global as any).AudioContext
      
      testEnv.simulateUserGesture()
      await app.startAudio()
      
      expect(app.getState().isAudioStarted).toBe(true)
    })

    it('should support WebGL with Firefox-specific extensions', async () => {
      // Mock Firefox WebGL extensions
      testEnv.mockWebGLContext.getExtension = vi.fn((name) => {
        if (name === 'MOZ_WEBGL_lose_context') return {}
        return null
      })

      await app.initialize(container)
      const cubeId = await app.createCube(CubeType.GAIN, { x: 0, y: 0, z: 0 })
      expect(cubeId).toBeDefined()
    })

    it('should handle Firefox MediaRecorder format differences', async () => {
      // Firefox might use different MIME types
      testEnv.mockMediaRecorder.start = vi.fn(function(this: any) {
        this.state = 'recording'
        // Firefox might emit different data format
        setTimeout(() => {
          if (this.ondataavailable) {
            this.ondataavailable({ 
              data: new Blob(['firefox-audio-data'], { type: 'audio/ogg' })
            })
          }
        }, 100)
      })

      await app.initialize(container)
      testEnv.simulateUserGesture()
      await app.startAudio()
      
      await app.startRecording()
      const recording = await app.stopRecording()
      
      expect(recording).toBeInstanceOf(Blob)
    })
  })

  describe('Feature Detection and Fallbacks', () => {
    it('should detect Web Audio API support correctly', () => {
      expect(BrowserCompatibilityHelper.checkWebAudioSupport()).toBe(true)
      
      // Test fallback detection
      delete (global as any).AudioContext
      delete (global as any).webkitAudioContext
      
      expect(BrowserCompatibilityHelper.checkWebAudioSupport()).toBe(false)
    })

    it('should detect WebGL support correctly', () => {
      expect(BrowserCompatibilityHelper.checkWebGLSupport()).toBe(true)
      
      // Mock WebGL not supported
      HTMLCanvasElement.prototype.getContext = vi.fn(() => null) as any
      
      expect(BrowserCompatibilityHelper.checkWebGLSupport()).toBe(false)
    })

    it('should detect MediaRecorder support correctly', () => {
      expect(BrowserCompatibilityHelper.checkMediaRecorderSupport()).toBe(true)
      
      delete (global as any).MediaRecorder
      
      expect(BrowserCompatibilityHelper.checkMediaRecorderSupport()).toBe(false)
    })

    it('should provide WebGL information', () => {
      const info = BrowserCompatibilityHelper.getWebGLInfo()
      expect(info).toHaveProperty('vendor')
      expect(info).toHaveProperty('renderer')
      expect(info).toHaveProperty('version')
    })

    it('should handle graceful degradation when features are missing', async () => {
      // Remove MediaRecorder support
      delete (global as any).MediaRecorder
      
      await app.initialize(container)
      testEnv.simulateUserGesture()
      await app.startAudio()
      
      // Recording should fail gracefully
      await expect(app.startRecording()).rejects.toThrow()
      expect(app.getState().isRecording).toBe(false)
    })
  })

  describe('Performance Across Browsers', () => {
    it('should maintain consistent performance in Chrome', async () => {
      Object.defineProperty(navigator, 'userAgent', {
        value: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        configurable: true,
      })

      await app.initialize(container)
      testEnv.simulateUserGesture()
      await app.startAudio()

      const startTime = performance.now()
      
      // Create multiple cubes
      for (let i = 0; i < 10; i++) {
        await app.createCube(CubeType.OSCILLATOR, { x: i, y: 0, z: 0 })
      }
      
      const endTime = performance.now()
      const duration = endTime - startTime
      
      expect(duration).toBeLessThan(1000) // Should complete within 1 second
    })

    it('should maintain consistent performance in Edge', async () => {
      Object.defineProperty(navigator, 'userAgent', {
        value: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0',
        configurable: true,
      })

      await app.initialize(container)
      testEnv.simulateUserGesture()
      await app.startAudio()

      const startTime = performance.now()
      
      // Test parameter updates
      const cubeId = await app.createCube(CubeType.FILTER, { x: 0, y: 0, z: 0 })
      for (let i = 0; i < 50; i++) {
        await app.rotateCube(cubeId, { x: 0, y: i * 0.1, z: 0 })
      }
      
      const endTime = performance.now()
      const duration = endTime - startTime
      
      expect(duration).toBeLessThan(500) // Should be responsive
    })

    it('should maintain consistent performance in Firefox', async () => {
      Object.defineProperty(navigator, 'userAgent', {
        value: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:120.0) Gecko/20100101 Firefox/120.0',
        configurable: true,
      })

      await app.initialize(container)
      testEnv.simulateUserGesture()
      await app.startAudio()

      const startTime = performance.now()
      
      // Test connection system
      const osc = await app.createCube(CubeType.OSCILLATOR, { x: 0, y: 0, z: 0 })
      const filter = await app.createCube(CubeType.FILTER, { x: 1.5, y: 0, z: 0 })
      const output = await app.createCube(CubeType.OUTPUT, { x: 3, y: 0, z: 0 })
      
      // Wait for connections
      await new Promise(resolve => setTimeout(resolve, 200))
      
      const endTime = performance.now()
      const duration = endTime - startTime
      
      expect(duration).toBeLessThan(1000)
      expect(app.getState().connections.length).toBeGreaterThan(0)
    })
  })

  describe('Error Handling Across Browsers', () => {
    it('should handle Chrome-specific errors', async () => {
      Object.defineProperty(navigator, 'userAgent', {
        value: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        configurable: true,
      })

      // Mock Chrome autoplay policy error
      testEnv.mockAudioContext.resume = vi.fn().mockRejectedValue(
        new Error('The AudioContext was not allowed to start')
      )

      await app.initialize(container)
      
      await expect(app.startAudio()).rejects.toThrow('The AudioContext was not allowed to start')
    })

    it('should handle Edge-specific errors', async () => {
      Object.defineProperty(navigator, 'userAgent', {
        value: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0',
        configurable: true,
      })

      // Mock Edge WebGL context loss
      testEnv.mockWebGLContext.isContextLost = vi.fn(() => true)

      await app.initialize(container)
      
      // Should handle context loss gracefully
      const cubeId = await app.createCube(CubeType.OSCILLATOR, { x: 0, y: 0, z: 0 })
      expect(cubeId).toBeDefined()
    })

    it('should handle Firefox-specific errors', async () => {
      Object.defineProperty(navigator, 'userAgent', {
        value: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:120.0) Gecko/20100101 Firefox/120.0',
        configurable: true,
      })

      // Mock Firefox security error
      testEnv.mockMediaRecorder.start = vi.fn(() => {
        throw new Error('SecurityError: The operation is insecure')
      })

      await app.initialize(container)
      testEnv.simulateUserGesture()
      await app.startAudio()
      
      await expect(app.startRecording()).rejects.toThrow('SecurityError')
    })
  })
})