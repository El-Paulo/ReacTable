// Integration test setup
import { vi } from 'vitest'

// Enhanced mocks for integration testing
export class MockAudioContext {
  public state = 'suspended'
  public sampleRate = 44100
  public destination = { connect: vi.fn(), disconnect: vi.fn() }
  private nodes: any[] = []

  createOscillator() {
    const node = {
      type: 'sine',
      frequency: { value: 440, setValueAtTime: vi.fn() },
      detune: { value: 0, setValueAtTime: vi.fn() },
      connect: vi.fn(),
      disconnect: vi.fn(),
      start: vi.fn(),
      stop: vi.fn(),
    }
    this.nodes.push(node)
    return node
  }

  createGain() {
    const node = {
      gain: { value: 1, setValueAtTime: vi.fn() },
      connect: vi.fn(),
      disconnect: vi.fn(),
    }
    this.nodes.push(node)
    return node
  }

  createBiquadFilter() {
    const node = {
      type: 'lowpass',
      frequency: { value: 350, setValueAtTime: vi.fn() },
      Q: { value: 1, setValueAtTime: vi.fn() },
      connect: vi.fn(),
      disconnect: vi.fn(),
    }
    this.nodes.push(node)
    return node
  }

  resume() {
    this.state = 'running'
    return Promise.resolve()
  }

  suspend() {
    this.state = 'suspended'
    return Promise.resolve()
  }

  close() {
    this.state = 'closed'
    return Promise.resolve()
  }

  getNodes() {
    return this.nodes
  }

  clearNodes() {
    this.nodes = []
  }
}

export class MockMediaRecorder {
  public state = 'inactive'
  public ondataavailable: ((event: any) => void) | null = null
  public onstop: ((event: any) => void) | null = null
  private chunks: Blob[] = []

  start() {
    this.state = 'recording'
  }

  stop() {
    this.state = 'inactive'
    if (this.onstop) {
      this.onstop({ data: new Blob(this.chunks, { type: 'audio/webm' }) })
    }
  }

  pause() {
    this.state = 'paused'
  }

  resume() {
    this.state = 'recording'
  }

  simulateDataAvailable(data: Blob) {
    this.chunks.push(data)
    if (this.ondataavailable) {
      this.ondataavailable({ data })
    }
  }
}

// Enhanced WebGL mock for integration testing
export class MockWebGLContext {
  public canvas = { width: 800, height: 600 }
  public drawingBufferWidth = 800
  public drawingBufferHeight = 600
  
  // Mock WebGL methods that Three.js uses
  getParameter = vi.fn(() => 'WebGL 1.0')
  getExtension = vi.fn(() => null)
  createShader = vi.fn(() => ({}))
  createProgram = vi.fn(() => ({}))
  createBuffer = vi.fn(() => ({}))
  createTexture = vi.fn(() => ({}))
  bindBuffer = vi.fn()
  bufferData = vi.fn()
  useProgram = vi.fn()
  enableVertexAttribArray = vi.fn()
  vertexAttribPointer = vi.fn()
  drawElements = vi.fn()
  drawArrays = vi.fn()
  viewport = vi.fn()
  clear = vi.fn()
  clearColor = vi.fn()
  enable = vi.fn()
  disable = vi.fn()
  depthFunc = vi.fn()
  blendFunc = vi.fn()
}

// Setup integration test environment
export function setupIntegrationTestEnvironment() {
  const mockAudioContext = new MockAudioContext()
  const mockMediaRecorder = new MockMediaRecorder()
  const mockWebGLContext = new MockWebGLContext()

  // Global mocks
  ;(global as any).AudioContext = vi.fn(() => mockAudioContext)
  ;(global as any).MediaRecorder = vi.fn(() => mockMediaRecorder)
  
  // Canvas context mock
  HTMLCanvasElement.prototype.getContext = vi.fn((type) => {
    if (type === 'webgl' || type === 'experimental-webgl') {
      return mockWebGLContext
    }
    return null
  }) as any

  // Performance API mock
  global.performance = {
    now: vi.fn(() => Date.now()),
    mark: vi.fn(),
    measure: vi.fn(),
    getEntriesByType: vi.fn(() => []),
  } as any

  // User interaction simulation helpers
  const simulateUserGesture = () => {
    // Simulate user interaction for audio context
    document.dispatchEvent(new Event('click'))
  }

  const simulateMouseEvent = (type: string, x: number, y: number, element?: Element) => {
    const event = new MouseEvent(type, {
      clientX: x,
      clientY: y,
      bubbles: true,
    })
    ;(element || document).dispatchEvent(event)
  }

  const simulateKeyboardEvent = (type: string, key: string, element?: Element) => {
    const event = new KeyboardEvent(type, {
      key,
      bubbles: true,
    })
    ;(element || document).dispatchEvent(event)
  }

  return {
    mockAudioContext,
    mockMediaRecorder,
    mockWebGLContext,
    simulateUserGesture,
    simulateMouseEvent,
    simulateKeyboardEvent,
  }
}

// Performance testing utilities
export class PerformanceTestHelper {
  private startTime = 0
  private frameCount = 0
  private lastFrameTime = 0

  startFPSMeasurement() {
    this.startTime = performance.now()
    this.frameCount = 0
    this.lastFrameTime = this.startTime
  }

  recordFrame() {
    this.frameCount++
    this.lastFrameTime = performance.now()
  }

  getFPS(): number {
    const elapsed = this.lastFrameTime - this.startTime
    return elapsed > 0 ? (this.frameCount * 1000) / elapsed : 0
  }

  async measureAsyncOperation<T>(operation: () => Promise<T>): Promise<{ result: T; duration: number }> {
    const start = performance.now()
    const result = await operation()
    const duration = performance.now() - start
    return { result, duration }
  }
}

// Browser compatibility testing utilities
export class BrowserCompatibilityHelper {
  static checkWebAudioSupport(): boolean {
    return typeof AudioContext !== 'undefined' || typeof (window as any).webkitAudioContext !== 'undefined'
  }

  static checkWebGLSupport(): boolean {
    const canvas = document.createElement('canvas')
    const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl')
    return gl !== null
  }

  static checkMediaRecorderSupport(): boolean {
    return typeof MediaRecorder !== 'undefined'
  }

  static getWebGLInfo(): { vendor: string; renderer: string; version: string } {
    const canvas = document.createElement('canvas')
    const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl')
    
    if (!gl) {
      return { vendor: 'unknown', renderer: 'unknown', version: 'unknown' }
    }

    return {
      vendor: gl.getParameter(gl.VENDOR) || 'unknown',
      renderer: gl.getParameter(gl.RENDERER) || 'unknown',
      version: gl.getParameter(gl.VERSION) || 'unknown',
    }
  }
}