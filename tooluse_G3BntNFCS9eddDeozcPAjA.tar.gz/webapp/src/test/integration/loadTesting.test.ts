// Load testing for maximum cube count and connection scenarios
import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest'
import { setupIntegrationTestEnvironment, PerformanceTestHelper } from './setup'
import { ReactableAppImpl } from '../../core/ReactableAppImpl'
import { CubeType } from '../../types'

describe('Load Testing Integration Tests', () => {
  let app: ReactableAppImpl
  let testEnv: ReturnType<typeof setupIntegrationTestEnvironment>
  let performanceHelper: PerformanceTestHelper
  let container: HTMLElement

  beforeEach(async () => {
    testEnv = setupIntegrationTestEnvironment()
    performanceHelper = new PerformanceTestHelper()
    
    container = document.createElement('div')
    container.style.width = '800px'
    container.style.height = '600px'
    document.body.appendChild(container)

    app = new ReactableAppImpl()
    await app.initialize(container)
  })

  afterEach(() => {
    if (container && container.parentNode) {
      container.parentNode.removeChild(container)
    }
    vi.clearAllMocks()
  })

  describe('Maximum Cube Count Load Tests', () => {
    it('should handle 20 cubes (requirement limit) efficiently', async () => {
      testEnv.simulateUserGesture()
      await app.startAudio()

      const maxCubes = 20
      const cubeIds: string[] = []

      // Measure cube creation performance
      const { duration: creationTime } = await performanceHelper.measureAsyncOperation(async () => {
        for (let i = 0; i < maxCubes; i++) {
          const type = [CubeType.OSCILLATOR, CubeType.FILTER, CubeType.GAIN][i % 3]
          const id = await app.createCube(type, { 
            x: (i % 5) * 2.5, 
            y: 0, 
            z: Math.floor(i / 5) * 2.5 
          })
          cubeIds.push(id)
        }
      })

      expect(creationTime).toBeLessThan(3000) // Should create 20 cubes within 3 seconds
      expect(app.getState().cubes.size).toBe(maxCubes)

      // Test rendering performance with max cubes
      performanceHelper.startFPSMeasurement()
      for (let frame = 0; frame < 120; frame++) { // 2 seconds at 60 FPS
        app.update(16.67)
        app.render()
        performanceHelper.recordFrame()
        await new Promise(resolve => setTimeout(resolve, 16))
      }

      const fps = performanceHelper.getFPS()
      expect(fps).toBeGreaterThanOrEqual(45) // Should maintain reasonable FPS
    })

    it('should detect performance degradation beyond limit', async () => {
      testEnv.simulateUserGesture()
      await app.startAudio()

      const excessiveCubes = 35
      const cubeIds: string[] = []

      // Create excessive number of cubes
      for (let i = 0; i < excessiveCubes; i++) {
        const id = await app.createCube(CubeType.OSCILLATOR, { 
          x: (i % 7) * 2, 
          y: 0, 
          z: Math.floor(i / 7) * 2 
        })
        cubeIds.push(id)
      }

      // Measure performance with excessive load
      performanceHelper.startFPSMeasurement()
      for (let frame = 0; frame < 60; frame++) {
        app.update(16.67)
        app.render()
        performanceHelper.recordFrame()
        
        // Add some manipulation to stress test
        if (frame % 5 === 0) {
          const cubeIndex = frame % cubeIds.length
          await app.rotateCube(cubeIds[cubeIndex], { 
            x: 0, 
            y: frame * 0.1, 
            z: 0 
          })
        }
        
        await new Promise(resolve => setTimeout(resolve, 16))
      }

      const fps = performanceHelper.getFPS()
      expect(fps).toBeLessThan(50) // Should show performance degradation

      // Performance monitor should detect issues
      const performanceMonitor = (app as any).performanceMonitor
      if (performanceMonitor) {
        const status = performanceMonitor.checkPerformance()
        expect(status.isDegraded).toBe(true)
      }
    })

    it('should handle cube cleanup efficiently', async () => {
      testEnv.simulateUserGesture()
      await app.startAudio()

      // Create many cubes
      const cubeIds: string[] = []
      for (let i = 0; i < 30; i++) {
        const id = await app.createCube(CubeType.OSCILLATOR, { x: i, y: 0, z: 0 })
        cubeIds.push(id)
      }

      expect(app.getState().cubes.size).toBe(30)

      // Measure cleanup performance
      const { duration: cleanupTime } = await performanceHelper.measureAsyncOperation(async () => {
        for (const id of cubeIds) {
          await app.deleteCube(id)
        }
      })

      expect(cleanupTime).toBeLessThan(2000) // Should clean up within 2 seconds
      expect(app.getState().cubes.size).toBe(0)
      expect(app.getState().connections.length).toBe(0)
    })
  })

  describe('Maximum Connection Scenarios', () => {
    it('should handle complex connection networks', async () => {
      testEnv.simulateUserGesture()
      await app.startAudio()

      // Create a complex network: multiple oscillators → filters → gains → output
      const oscillatorIds: string[] = []
      const filterIds: string[] = []
      const gainIds: string[] = []

      // Create oscillators in a line
      for (let i = 0; i < 4; i++) {
        const id = await app.createCube(CubeType.OSCILLATOR, { x: i * 1.8, y: 0, z: 0 })
        oscillatorIds.push(id)
      }

      // Create filters in a line (close to oscillators for auto-connection)
      for (let i = 0; i < 4; i++) {
        const id = await app.createCube(CubeType.FILTER, { x: i * 1.8, y: 0, z: 1.8 })
        filterIds.push(id)
      }

      // Create gains in a line (close to filters)
      for (let i = 0; i < 4; i++) {
        const id = await app.createCube(CubeType.GAIN, { x: i * 1.8, y: 0, z: 3.6 })
        gainIds.push(id)
      }

      // Create output cube (close to gains)
      const outputId = await app.createCube(CubeType.OUTPUT, { x: 1.5, y: 0, z: 5.4 })

      // Wait for all automatic connections to establish
      await new Promise(resolve => setTimeout(resolve, 1000))

      const connections = app.getState().connections
      expect(connections.length).toBeGreaterThan(8) // Should have many connections

      // Test performance with complex network
      performanceHelper.startFPSMeasurement()
      for (let frame = 0; frame < 60; frame++) {
        app.update(16.67)
        app.render()
        performanceHelper.recordFrame()
        
        // Manipulate parameters to test audio processing load
        if (frame % 10 === 0) {
          const oscIndex = frame % oscillatorIds.length
          await app.rotateCube(oscillatorIds[oscIndex], { 
            x: 0, 
            y: Math.sin(frame * 0.1) * Math.PI, 
            z: 0 
          })
        }
        
        await new Promise(resolve => setTimeout(resolve, 16))
      }

      const fps = performanceHelper.getFPS()
      expect(fps).toBeGreaterThanOrEqual(30) // Should maintain reasonable performance
    })

    it('should prevent connection cycles efficiently', async () => {
      testEnv.simulateUserGesture()
      await app.startAudio()

      // Create cubes in a pattern that could create cycles
      const cube1 = await app.createCube(CubeType.FILTER, { x: 0, y: 0, z: 0 })
      const cube2 = await app.createCube(CubeType.FILTER, { x: 1.5, y: 0, z: 0 })
      const cube3 = await app.createCube(CubeType.FILTER, { x: 0.75, y: 0, z: 1.5 })

      // Wait for connections
      await new Promise(resolve => setTimeout(resolve, 200))

      // Move cubes to potentially create cycles
      await app.moveCube(cube1, { x: 0, y: 0, z: 3 })
      await app.moveCube(cube2, { x: 1.5, y: 0, z: 3 })
      await app.moveCube(cube3, { x: 0.75, y: 0, z: 1.5 })

      await new Promise(resolve => setTimeout(resolve, 200))

      // Should not have created any cycles
      const connections = app.getState().connections
      const connectionManager = (app as any).connectionManager
      if (connectionManager) {
        const hasCycles = connectionManager.detectCycles(connections)
        expect(hasCycles).toBe(false)
      }
    })

    it('should handle rapid connection changes', async () => {
      testEnv.simulateUserGesture()
      await app.startAudio()

      const cubeIds: string[] = []
      
      // Create cubes
      for (let i = 0; i < 6; i++) {
        const type = i < 3 ? CubeType.OSCILLATOR : CubeType.FILTER
        const id = await app.createCube(type, { x: i * 3, y: 0, z: 0 })
        cubeIds.push(id)
      }

      // Rapidly move cubes to create/break connections
      const { duration } = await performanceHelper.measureAsyncOperation(async () => {
        for (let iteration = 0; iteration < 20; iteration++) {
          for (let i = 0; i < cubeIds.length; i++) {
            const newX = (i * 3) + Math.sin(iteration * 0.5) * 2
            await app.moveCube(cubeIds[i], { x: newX, y: 0, z: 0 })
          }
          await new Promise(resolve => setTimeout(resolve, 50))
        }
      })

      expect(duration).toBeLessThan(5000) // Should handle rapid changes efficiently
      
      // System should still be stable
      expect(app.getState().cubes.size).toBe(6)
    })
  })

  describe('Audio Processing Load Tests', () => {
    it('should handle multiple simultaneous audio streams', async () => {
      testEnv.simulateUserGesture()
      await app.startAudio()

      // Create multiple independent audio chains
      const chains: string[][] = []
      
      for (let chain = 0; chain < 4; chain++) {
        const chainCubes: string[] = []
        
        // Each chain: Oscillator → Filter → Gain → Output
        const osc = await app.createCube(CubeType.OSCILLATOR, { 
          x: chain * 6, 
          y: 0, 
          z: 0 
        })
        chainCubes.push(osc)
        
        const filter = await app.createCube(CubeType.FILTER, { 
          x: chain * 6 + 1.5, 
          y: 0, 
          z: 0 
        })
        chainCubes.push(filter)
        
        const gain = await app.createCube(CubeType.GAIN, { 
          x: chain * 6 + 3, 
          y: 0, 
          z: 0 
        })
        chainCubes.push(gain)
        
        const output = await app.createCube(CubeType.OUTPUT, { 
          x: chain * 6 + 4.5, 
          y: 0, 
          z: 0 
        })
        chainCubes.push(output)
        
        chains.push(chainCubes)
      }

      // Wait for all connections
      await new Promise(resolve => setTimeout(resolve, 500))

      // Test simultaneous parameter changes across all chains
      const { duration } = await performanceHelper.measureAsyncOperation(async () => {
        const updatePromises: Promise<void>[] = []
        
        for (let chain = 0; chain < chains.length; chain++) {
          const [osc, filter, gain] = chains[chain]
          
          updatePromises.push(
            app.rotateCube(osc, { x: 0, y: chain * Math.PI / 4, z: 0 })
          )
          updatePromises.push(
            app.rotateCube(filter, { x: 0, y: (chain + 1) * Math.PI / 6, z: 0 })
          )
          updatePromises.push(
            app.rotateCube(gain, { x: 0, y: (chain + 2) * Math.PI / 8, z: 0 })
          )
        }
        
        await Promise.all(updatePromises)
      })

      expect(duration).toBeLessThan(100) // Should handle simultaneous updates efficiently
    })

    it('should maintain audio quality under load', async () => {
      testEnv.simulateUserGesture()
      await app.startAudio()

      // Create complex audio setup
      const cubeIds: string[] = []
      
      // Multiple oscillators
      for (let i = 0; i < 8; i++) {
        const id = await app.createCube(CubeType.OSCILLATOR, { 
          x: i * 1.5, 
          y: 0, 
          z: 0 
        })
        cubeIds.push(id)
      }

      // Multiple filters
      for (let i = 0; i < 4; i++) {
        const id = await app.createCube(CubeType.FILTER, { 
          x: i * 3, 
          y: 0, 
          z: 1.5 
        })
        cubeIds.push(id)
      }

      // Output
      const outputId = await app.createCube(CubeType.OUTPUT, { x: 6, y: 0, z: 3 })

      // Wait for connections
      await new Promise(resolve => setTimeout(resolve, 500))

      // Continuously manipulate parameters to stress audio system
      const manipulationPromises: Promise<void>[] = []
      
      for (let i = 0; i < 50; i++) {
        manipulationPromises.push(
          (async () => {
            await new Promise(resolve => setTimeout(resolve, i * 20))
            const cubeIndex = i % cubeIds.length
            await app.rotateCube(cubeIds[cubeIndex], { 
              x: 0, 
              y: Math.sin(i * 0.2) * Math.PI, 
              z: 0 
            })
          })()
        )
      }

      const { duration } = await performanceHelper.measureAsyncOperation(async () => {
        await Promise.all(manipulationPromises)
      })

      expect(duration).toBeLessThan(3000) // Should complete within reasonable time

      // Audio system should still be responsive
      const testCube = cubeIds[0]
      const { duration: responseTime } = await performanceHelper.measureAsyncOperation(async () => {
        await app.rotateCube(testCube, { x: 0, y: Math.PI / 2, z: 0 })
      })

      expect(responseTime).toBeLessThan(20) // Should maintain low latency
    })
  })

  describe('Memory Load Tests', () => {
    it('should handle memory efficiently with maximum load', async () => {
      testEnv.simulateUserGesture()
      await app.startAudio()

      const initialMemory = (performance as any).memory?.usedJSHeapSize || 0

      // Create maximum recommended setup
      const cubeIds: string[] = []
      for (let i = 0; i < 20; i++) {
        const type = [CubeType.OSCILLATOR, CubeType.FILTER, CubeType.GAIN][i % 3]
        const id = await app.createCube(type, { 
          x: (i % 5) * 2, 
          y: 0, 
          z: Math.floor(i / 5) * 2 
        })
        cubeIds.push(id)
      }

      const outputId = await app.createCube(CubeType.OUTPUT, { x: 10, y: 0, z: 10 })

      // Wait for all connections
      await new Promise(resolve => setTimeout(resolve, 1000))

      const peakMemory = (performance as any).memory?.usedJSHeapSize || 0

      // Perform intensive operations
      for (let cycle = 0; cycle < 10; cycle++) {
        for (const id of cubeIds) {
          await app.rotateCube(id, { 
            x: Math.sin(cycle * 0.5), 
            y: Math.cos(cycle * 0.5), 
            z: 0 
          })
        }
        await new Promise(resolve => setTimeout(resolve, 100))
      }

      // Clean up
      for (const id of cubeIds) {
        await app.deleteCube(id)
      }
      await app.deleteCube(outputId)

      // Force garbage collection
      if ((global as any).gc) {
        (global as any).gc()
      }
      
      await new Promise(resolve => setTimeout(resolve, 200))

      const finalMemory = (performance as any).memory?.usedJSHeapSize || 0

      if (initialMemory > 0 && peakMemory > 0 && finalMemory > 0) {
        const memoryGrowth = finalMemory - initialMemory
        expect(memoryGrowth).toBeLessThan(50 * 1024 * 1024) // Less than 50MB permanent growth
      }
    })

    it('should handle repeated load cycles without memory leaks', async () => {
      testEnv.simulateUserGesture()
      await app.startAudio()

      const initialMemory = (performance as any).memory?.usedJSHeapSize || 0

      // Perform multiple load cycles
      for (let cycle = 0; cycle < 3; cycle++) {
        const cubeIds: string[] = []
        
        // Create cubes
        for (let i = 0; i < 15; i++) {
          const id = await app.createCube(CubeType.OSCILLATOR, { x: i, y: 0, z: 0 })
          cubeIds.push(id)
        }

        // Use cubes intensively
        for (let operation = 0; operation < 20; operation++) {
          const cubeIndex = operation % cubeIds.length
          await app.rotateCube(cubeIds[cubeIndex], { 
            x: 0, 
            y: operation * 0.1, 
            z: 0 
          })
        }

        // Clean up
        for (const id of cubeIds) {
          await app.deleteCube(id)
        }

        // Force garbage collection
        if ((global as any).gc) {
          (global as any).gc()
        }
        
        await new Promise(resolve => setTimeout(resolve, 100))
      }

      const finalMemory = (performance as any).memory?.usedJSHeapSize || 0

      if (initialMemory > 0 && finalMemory > 0) {
        const memoryGrowth = finalMemory - initialMemory
        expect(memoryGrowth).toBeLessThan(20 * 1024 * 1024) // Less than 20MB growth after cycles
      }
    })
  })

  describe('Stress Testing Edge Cases', () => {
    it('should handle rapid cube creation and deletion', async () => {
      testEnv.simulateUserGesture()
      await app.startAudio()

      // Rapid creation and deletion cycles
      for (let cycle = 0; cycle < 5; cycle++) {
        const cubeIds: string[] = []
        
        // Rapid creation
        const creationPromises: Promise<string>[] = []
        for (let i = 0; i < 10; i++) {
          creationPromises.push(
            app.createCube(CubeType.OSCILLATOR, { x: i, y: 0, z: 0 })
          )
        }
        
        const ids = await Promise.all(creationPromises)
        cubeIds.push(...ids)

        expect(app.getState().cubes.size).toBe(10)

        // Rapid deletion
        const deletionPromises = cubeIds.map(id => app.deleteCube(id))
        await Promise.all(deletionPromises)

        expect(app.getState().cubes.size).toBe(0)
      }

      // System should still be stable
      const testCube = await app.createCube(CubeType.OSCILLATOR, { x: 0, y: 0, z: 0 })
      expect(testCube).toBeDefined()
    })

    it('should handle extreme parameter changes', async () => {
      testEnv.simulateUserGesture()
      await app.startAudio()

      const cubeId = await app.createCube(CubeType.FILTER, { x: 0, y: 0, z: 0 })

      // Extreme parameter changes
      const extremeValues = [
        { x: 0, y: -Math.PI, z: 0 },
        { x: 0, y: Math.PI, z: 0 },
        { x: Math.PI, y: 0, z: 0 },
        { x: -Math.PI, y: 0, z: 0 },
        { x: 0, y: 0, z: Math.PI },
        { x: 0, y: 0, z: -Math.PI },
      ]

      for (const rotation of extremeValues) {
        await app.rotateCube(cubeId, rotation)
        
        // Verify cube is still functional
        const cube = app.getState().cubes.get(cubeId)
        expect(cube).toBeDefined()
        expect(cube?.isActive).toBe(true)
      }
    })

    it('should recover from temporary overload conditions', async () => {
      testEnv.simulateUserGesture()
      await app.startAudio()

      // Create overload condition
      const cubeIds: string[] = []
      for (let i = 0; i < 40; i++) {
        const id = await app.createCube(CubeType.OSCILLATOR, { x: i, y: 0, z: 0 })
        cubeIds.push(id)
      }

      // Measure degraded performance
      performanceHelper.startFPSMeasurement()
      for (let frame = 0; frame < 30; frame++) {
        app.update(16.67)
        app.render()
        performanceHelper.recordFrame()
        await new Promise(resolve => setTimeout(resolve, 16))
      }
      const degradedFPS = performanceHelper.getFPS()

      // Remove excess cubes to recover
      for (let i = 20; i < cubeIds.length; i++) {
        await app.deleteCube(cubeIds[i])
      }

      // Measure recovered performance
      performanceHelper.startFPSMeasurement()
      for (let frame = 0; frame < 30; frame++) {
        app.update(16.67)
        app.render()
        performanceHelper.recordFrame()
        await new Promise(resolve => setTimeout(resolve, 16))
      }
      const recoveredFPS = performanceHelper.getFPS()

      expect(recoveredFPS).toBeGreaterThan(degradedFPS)
      expect(app.getState().cubes.size).toBe(20)
    })
  })
})