// Test setup file
import { vi } from 'vitest'

// Mock Web Audio API
;(global as any).AudioContext = vi.fn(() => ({
  createOscillator: vi.fn(),
  createGain: vi.fn(),
  createBiquadFilter: vi.fn(),
  destination: {},
  resume: vi.fn(),
  suspend: vi.fn(),
  close: vi.fn(),
  state: 'suspended',
  sampleRate: 44100,
}))

// Mock MediaRecorder
;(global as any).MediaRecorder = vi.fn(() => ({
  start: vi.fn(),
  stop: vi.fn(),
  pause: vi.fn(),
  resume: vi.fn(),
  state: 'inactive',
  ondataavailable: null,
  onstop: null,
}))

// Mock requestAnimationFrame
global.requestAnimationFrame = vi.fn((cb) => setTimeout(cb, 16))
global.cancelAnimationFrame = vi.fn()

// Mock WebGL context
HTMLCanvasElement.prototype.getContext = vi.fn(() => ({
  canvas: {},
  drawingBufferWidth: 800,
  drawingBufferHeight: 600,
})) as any

console.log('Test environment setup complete')