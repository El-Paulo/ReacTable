import { defineConfig } from 'vitest/config'
import { resolve } from 'path'

export default defineConfig({
  test: {
    environment: 'jsdom',
    globals: true,
    setupFiles: [resolve(__dirname, 'src/test/integration/setup.ts')],
    include: ['src/test/integration/**/*.test.ts'],
    testTimeout: 60000, // Longer timeout for integration tests
    hookTimeout: 15000,
    maxConcurrency: 1, // Run integration tests sequentially to avoid resource conflicts
    pool: 'forks', // Use separate processes for better isolation
  },
  resolve: {
    alias: {
      '@': resolve(__dirname, 'src'),
    },
  },
})